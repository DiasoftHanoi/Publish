/*DSMETA version = "5.10.01-23081501" hash = "699ef6933801cbba45bda226f287d896be74dc37"*/
function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);
var gRB = service.gRB;
var convertDate = service.convertDate;
var getTableContent = service.getTableContent;
var nvl = service.nvl;

var inputParams = form.inputParams;
var outputParams = form.outputParams || {};
form.params = inputParams.formParams || {};
outputParams.formParams = form.params;
form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.isFormEditModeMain = form.inputParams.EDITMODE;
service.lgr(form.params);
form.params.cbChooseSMSNumber = inputParams.cbChooseSMSNumber || "";
form.params.cbChooseEmail = inputParams.cbChooseEmail || "";
var contactTypeList = form.inputParams.contactTypeList || [];
form.inputMask = (form.params.cbChooseSMSNumber && contactTypeList && contactTypeList.length > 0) ? form.inputParams.contactTypeList[0]['MobilePhone'] : "";
form.params.checkProductPolicyText = "No";
if(form.params.checkProductPolicy + "" == "true") form.params.checkProductPolicyText = "Yes";

form.MarketingChanne = {
    ReferenceGroupName: "General",
    ReferenceSysName: "marketingChannelTypeLOS"
};
form.credibilityComment_item = [{
        value: "high",
        text: gRB("High")
    }, {
        value: "medium",
        text: gRB("Medium")
    }, {
        value: "others",
        text: gRB("Others")
    }
];

form.relatedInfo_item = [{
         value: "yes",
         text: gRB("Yes")
  }, {
         value: "no",
         text: gRB("No")
  }
];

form.creditProposal_item = [{
         value: 'yes',
         text: gRB('Yes')
  }, {
         value: 'no',
         text: gRB('No')
  }
];

 form.creditProposalResult_item = [{
         value: 'approve',
         text: gRB('Approve')
     }, {
         value: 'reject',
         text: gRB('Reject')
     }, {
         value: 'others',
         text: gRB('Others')
     }
 ];

 form.blacklist_items = [{
          value: 'Yes',
          text: gRB('Yes')
   }, {
          value: 'No',
          text: gRB('No')
   }
 ];

 form.fraudlist_items = [{
           value: 'Yes',
           text: gRB('Yes')
    }, {
           value: 'No',
           text: gRB('No')
    }
  ];
form.customerGroupInfo=form.params.customerGroupInfo || {};
form.blacklistTable=form.params.blacklistTable || {};
form.salesHistory=form.params.salesHistory || {};

form.onChangeCbChooseSMSNumber = function () {
    if (form.params.cbChooseSMSNumber == '' || form.params.cbChooseSMSNumber == undefined) form.params.selectedNumber = '';
    else if (form.params.cbChooseSMSNumber == 'MobilePhone') form.params.selectedNumber = form.params.selectedNumberForMobilePhone;
    else if (form.params.cbChooseSMSNumber == 'Other') form.params.selectedNumber = form.params.selectedNumberForOther;
    form.inputMask = form.inputParams.contactTypeList[0]['MobilePhone'];
};

form.onChangeCbChooseMobilePhoneNumber = function () {
    form.params.selectedNumberForMobilePhone = form.params.selectedNumber;
    form.inputMask = form.inputParams.contactTypeList[0]['MobilePhone'];
};

form.onChangeCbChooseEmail = function () {
    if (form.params.cbChooseEmail == '' || form.params.cbChooseEmail == undefined) form.params.selectedAddress = '';
    else if (form.params.cbChooseEmail == 'PersonalEmail') form.params.selectedAddress = form.params.selectedAddressForPersonalEmail;
    else if (form.params.cbChooseEmail == 'Other') form.params.selectedAddress = form.params.selectedAddressForOther;
};

form.onChangeCbChoosePersonalEmail = function () {
    form.params.selectedAddressForPersonalEmail = form.params.selectedAddress;
};

form.getMarketingChannel = function () {
    form.salesHistory.marketingChannelText = (form.cmbMarketingChannel) ? form.cmbMarketingChannel.getText() : "";
    form.salesHistory.marketingChannelDetail = "";
};

form.getCredibilityComment = function () {
    form.salesHistory.credibilityCommentText = (form.cbCredibilityComment) ? form.cbCredibilityComment.getText() : "";
    form.salesHistory.credibilityCommentDetail =  "";
};

form.getRelatedInfo = function () {
    form.salesHistory.relatedInfoText = (form.cbRelatedInfo) ? form.cbRelatedInfo.getText() : "";
    form.salesHistory.relatedInfoDetail = "";
};

form.getCreditProposal = function () {
    form.salesHistory.creditProposalText = (form.cbCreditProposal) ? form.cbCreditProposal.getText() : "";
    form.salesHistory.proceededProposal = "";
    form.salesHistory.creditProposalResultText = "";
    form.salesHistory.creditProposalResult = "";
    form.salesHistory.creditProposalDetails = "";
};

form.getCreditProposalResult = function () {
    form.salesHistory.creditProposalResultText = (form.cbCreditProposalResult) ? form.cbCreditProposalResult.getText() : "";
};


if(form.params.serviceInfo){
    form.isUpdatesCreditLimitFeeText = "No"
    if(form.params.serviceInfo.isUpdatesCreditLimitFee + "" == 'true') form.isUpdatesCreditLimitFeeText = "Yes";
    form.isUpdatedCardTypeFeeText = "No"
    if(form.params.serviceInfo.isUpdatedCardTypeFee + "" == 'true') form.isUpdatedCardTypeFeeText = "Yes";
}
form.serviceInfo=form.params.serviceInfo || {};



form.customerTypeComboBoxParams={ReferenceSysName: 'promotionCustomerType', ReferenceItemCode:inputParams.DOCTYPESYSNAME, ORDERBY: 'ReferenceItemID'};
form.promotionProgramComboBoxParams={ReferenceSysName: 'promotionProgramCode', ReferenceItemCode:form.serviceInfo.customerType, ORDERBY: 'ReferenceItemID'};
form.feeTypeComboBoxParams={ReferenceSysName: 'feesOfCreditCard', ORDERBY: 'ReferenceItemID'};


form.onShow = function () {
    for (var i = 0; i < form.inputParams.contactNumberListForComboBox.length; i++) {
        var contactType = form.inputParams.contactNumberListForComboBox[i].contactType;
        if (form.inputParams.contactTypeList.length > 0) {
		   if (form.inputParams.contactTypeList[0][contactType] != undefined) {
               form.inputParams.contactNumberListForComboBox[i].contactText = service.setMask(form.inputParams.contactNumberListForComboBox[i].contactValue, form.inputParams.contactTypeList[0]['MobilePhone'], true);
           }
		}   
    }
	form.changeCustomerType();
    if(form.params.smsInformingSysName == 'Other') 
        form.params.selectedNumberForOther = form.params.selectedNumber;
    else if (form.params.smsInformingSysName == 'MobilePhone') {
        form.params.selectedNumberForMobilePhone = form.params.selectedNumber;
        if (form.inputParams.contactNumberListForComboBox.length > 1)
            form.cbChooseMobilePhoneNumber.setValue(form.params.selectedNumber);
    }
    if(form.params.emailInformingSysName == 'Other') 
        form.params.selectedAddressForOther = form.params.selectedAddress;
    else if (form.params.emailInformingSysName == 'PersonalEmail') 
        form.params.selectedAddressForPersonalEmail = form.params.selectedAddress;

    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
};

form.executeCommand = function(msg){
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
    if (msg.event === 'GO_TO_PAGEFLOW'){
        form.startNewPageFlowProcess(msg.caption, msg.params.PAGEFLOW, {
            APPLICATIONID: msg.params.APPLICATIONID,
            EDITMODE: false
        });
    }
};

form.verifyForm = function (showFlag, tag) {
    var verified = true;
    try {
        var btnNext =  form['btnNext'] ? 'btnNext' : 'btnSave';
        if (tag === 'CLOSE') {
            btnNext = 'btnCancel';
        }
        if (form.validateControlsByIds('*', showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    outputParams.VERIFIED = verified;
    return verified;
};

form.saveNewSelectedContact = function(selectedContact, selectedName, selectedSysName, text, type) {
    if (selectedContact != '' && selectedContact != undefined) {
        outputParams.formParams[selectedName] = text;
        outputParams.formParams[selectedSysName] = type;
    } else {
        outputParams.formParams[selectedName] = '';
        outputParams.formParams[selectedSysName] = '';
    }
};

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    if (form.isFormEditModeMain) {
        outputParams.formParams.selectedNumber = form.params.selectedNumber;
        form.saveNewSelectedContact(form.params.selectedNumber, "smsInforming", "smsInformingSysName", form.cbChooseSMSNumber.getText(), form.cbChooseSMSNumber.getValue());
        outputParams.formParams.selectedAddress = form.params.selectedAddress;
        form.saveNewSelectedContact(form.params.selectedAddress, "emailInforming", "emailInformingSysName", form.cbChooseEmail.getText(), form.cbChooseEmail.getValue());
        outputParams.formParams.checkProductPolicy = form.params.checkProductPolicy;
        outputParams.formParams.promotionProgramCode = form.params.promotionProgramCode;
        outputParams.formParams.comment = form.params.comment;
        outputParams.formParams.DETAILS = form.params.comment;
        outputParams.formParams.serviceInfo = form.serviceInfo;
        outputParams.formParams.checkProductPolicy = form.params.checkProductPolicy;
        outputParams.formParams.MISCode = form.params.MISCode;
        outputParams.formParams.salesHistory = form.salesHistory;
        outputParams.formParams.blacklistTable = form.blacklistTable;
        outputParams.formParams.customerGroupInfo = form.customerGroupInfo;
        outputParams.VERIFIED = true;
        service.lgr(outputParams);
    }
    if (tagName === 'CLOSE') {
        if(form.inputParams.EDITMODE === false){
            form.sendForm('GO',false);
        }else {
            form.verifyForm(true, tagName);
            service.showDialogCancelConfirm(
                form,
                function () {
                    form.saveNewSelectedContact(form.params.selectedNumber, "smsInforming", "smsInformingSysName", inputParams.clientPhoneNumbers[0].contactText, inputParams.clientPhoneNumbers[0].contactType);
                    form.saveNewSelectedContact(form.params.selectedAddress, "emailInforming", "emailInformingSysName", inputParams.clientEmails[0].contactText, inputParams.clientEmails[0].contactType);
                    outputParams.TRANSTYPE = 'SAVEDRAFT';
                    form.sendForm('GO', false);
                }
            )
        }
    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};

form.changePromotionProgram = function(item){
  form.serviceInfo.promotionProgramCode='';
  if(item){
      form.serviceInfo.promotionProgramCode=item.ReferenceItemName;
      if(form.cmbpromotionProgram) form.serviceInfo.promotionProgramName=form.cmbpromotionProgram.getText(); 
  }
};

form.changeCustomerType = function(flag){
    if(form.cmbcustomerType) form.serviceInfo.customerTypeName=form.cmbcustomerType.getText(); 
    if(flag){
        delete form.serviceInfo.promotionProgram;
        delete form.serviceInfo.promotionProgramCode;
    }
    if(form.cmbpromotionProgram) {
      form.promotionProgramComboBoxParams.ReferenceItemCode=form.serviceInfo.customerType;
      form.cmbpromotionProgram.refresh();
    }  
};

form.changeFeeType = function(item){
  form.serviceInfo.feeCode='';
  if(item){
      form.serviceInfo.feeCode=item.ReferenceItemCode;
      if(form.cmbfeeType) form.serviceInfo.feeTypeName=form.cmbfeeType.getText(); 
  }
};