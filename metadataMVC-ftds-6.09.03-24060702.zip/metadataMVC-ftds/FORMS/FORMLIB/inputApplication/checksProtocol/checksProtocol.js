function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var gRB = service.gRB;
var nvl = service.nvl;
var inputParams = form.inputParams;
var outputParams = form.outputParams;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.isFormEditMode = form.inputParams.EDITMODE || false;

form.checkScriptExecuted = inputParams.checkScriptExecuted;
var appId = inputParams.APPLICATIONID;
var globalProtocolId = inputParams.GLOBALPROTOCOLID;
var item = form.item;

form.params = inputParams;
form.methodParams = inputParams.methodParams;

var globalInterval;

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
    form.getScriptStatus();
    globalInterval = setInterval(form.getScriptStatus, 2000);
};

form.getScriptStatus = function () {
    var params = {"DOCUMENTID": appId, "ReturnAsHashMap": "TRUE"};
    form.dsCall('[frontws2]', 'documentGetByIdOld', params).then(function (response) {
        var result = response.data || {};
        if (result && result.length) {
            return response.data["checkScriptExecuted"];
        }
    });
};

form.repeatCheck = function () {
    var selRows = form.verGrid.getSelectedRow();
    var selRow = null;
    if (selRows.length > 0) {
        selRow = selRows[0];
    }
    if (selRow != null) {
        outputParams.CHECKPROTOCOLID = selRow["CHECKPROTOCOLID"];
    }
    form.sendForm("REPEATCHECK", false);
};

form.showDetails = function () {
    var selRows = form.verGrid.getSelectedRow();
    var selRow = null;
    if (selRows.length > 0) {
        selRow = selRows[0];
    }

    var chkDetails = selRow["CHECKDETAILS"];
    if (nvl(chkDetails, '') == '') {
        chkDetails = '${noDetail}';
    }
    form.showModalDialog("large", "${checkDetail}", chkDetails, null, [{caption: gRB('dialog.ok')}], function () {
    });
};

form.checkObj = (function (grId) {
    var gridId = grId;

    var obj = {
        gridId: grId,

        cols: [
            {
                value: 'CHECKID',
                type: 'text',
                caption: '${check}',
                width: 15
            },
            {
                value: 'CHECKRESULT',
                type: 'text',
                caption: '${status}',
                width: 15
            },
            {
                value: 'targetName',
                type: 'text',
                caption: '${customerName}',
                width: 15
            },
            {
                value: 'OBJECTTYPEID',
                type: 'text',
                caption: '${subject}',
                width: 15
            },
            {
                value: 'STARTCHECKDATE',
                type: 'datetime',
                caption: '${checkDateIns}',
                width: 15
            }
        ],

        remoteMethod: {
            method: 'checkProtocolGetListByParams',
            service: '[dmsws]',
            filterParams: inputParams.methodParams
        },

        options: {
            'items': [
                {
                    caption: '${repeatCheck}',
                    click: form.repeatCheck
                },
                {
                    caption: '${showDetail}',
                    click: form.showDetails
                }
            ]
        },

        refresh: function () {
            form[gridId].refresh();
        },

        onChangeItems: function () {
            obj.totalCount = form[gridId].getTotalCount();
        }
    };

    return obj;
})("verGrid");

form.executeCommand = function(msg){
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var btnNext =  form['btnNext'] ? 'btnNext' : 'btnSave';
        if (form.validateControlsByIds('*', showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {lgr(e);
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;

    if (tagName === 'CLOSE') {
        if (!form.isFormEditMode){
            clearInterval(globalInterval);
            form.sendForm('GO',false);
        }else {
            service.showDialogCancelConfirm(
                form,
                function (){
                    form.outputParams.TRANSTYPE = 'SAVEDRAFT';
                    form.verifyForm(false);
                    clearInterval(globalInterval);
                    form.sendForm('GO', false);
                }
            )
        }
    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        clearInterval(globalInterval);
        form.sendForm('GO', false);
    }
};