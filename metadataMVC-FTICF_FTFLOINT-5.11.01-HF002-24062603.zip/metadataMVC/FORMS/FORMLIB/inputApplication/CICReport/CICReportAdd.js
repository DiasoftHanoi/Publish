/*DSMETA version = "5.11.01-HF002-24062603" hash = "43fa6cf8a232d458f45fcad3878437a61e1f9d88"*/
/* global form */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var convertDate = service.convertDate;
var getTableContent = service.getTableContent;
var gRB = service.gRB;

var EDITMODE = form.inputParams.EDITMODE || "";
form.isFormEditMode = (EDITMODE == 'view') ? false : true;


var inputParams = form.inputParams;
var outputParams = form.outputParams;

form.formParams = inputParams.newRow || {};
outputParams.newRow = form.formParams;
form.CreditCardMask = function(){
    var str = "";
    if(!form.isFormEditMode && form.formParams.cardNumber) {
        for (var i = 0; i < form.formParams.cardNumber.toString().length; i++) {
            var item = form.formParams.cardNumber[i];
            if (i % 4 == 0 && i != 0) {
                str = str + ' ';
            }
            str = str + item;
        }
    }
    form.formParams.cardNumberText = str;
};
form.CreditCardMask();


form.settings = {
        cmbOverdueGroupParams : {
        ReferenceSysName: 'overdueGroupLOS',
        ReferenceGroupName: 'General'
    },
    cmbCardTypeComboBoxParams : {
        ReferenceSysName: 'cardTypeLOS',
        ORDERBY: 'ReferenceItemID'
    },
    addPanel : form.inputParams.addPanel.toLowerCase().replace(' ', ''),
    lbTimeOverdueDebt : (form.inputParams.timeOfOverdueDebt == 'In Group 3') ? "${lbTimeOverdueDebt.help}" : ""
};

form.PAIDOFF_LIST = [
    {value: false, text: form.getResourceBundle('dialog.no')},
    {value: true, text: form.getResourceBundle('dialog.yes')}
];

form.requiredElements = [
    "edBankNameLoan",
    "cmbOverdueGroup",
    "edoverdueNumber",
    "rgdebtPaidOff",
    "edReasonOverdue",
    "edBankNameCreditCard",
    "edCardNumber",
    "cmbCardType",
    "edTotalCreditLimit",
    "clExpiredDate",
    "edTotalCurrentDebt",
    "edOverdueNumber",
    "edDelayedAmount",
    "edOverdueDays",
    "edMinimumPaymentAmount",
    "edPaymentWithinLast12Months",
	"edCreditLimitIncludingUnderApproving"

];

form.onShow = function () {

};

form.curDate = service.convertDate(new Date());

form.action = function (tag) {
    if (tag == 'save') {
        if (!form.verifyForm()) {
            return;
        }
        var newRowTemp = {};
        if (form.settings.addPanel == 'loan') {
            newRowTemp = {
                "loanType"                 : (form.cmbLoanType) ? form.cmbLoanType.getText() : "",
                "principalRepaymentMethod" : (form.cmbPrincipalRepaymentMethod) ? form.cmbPrincipalRepaymentMethod.getText() : "",
                "overdueGroup"             : (form.cmbOverdueGroup) ? form.cmbOverdueGroup.getText() : ""

            }
        } else if (form.settings.addPanel == 'creditcard') {
            newRowTemp = {
                "cardType"        : (form.cmbCardType) ? form.cmbCardType.getText() : ""
            }
        }
        form.formParams.loanType = (form.cmbLoanType) ? form.cmbLoanType.getText() : "";
        angular.extend(form.formParams, newRowTemp); // закидываем текстовые значения для комбобоксов
    }
    else {
        outputParams.newRow = {};
    }
    form.sendForm('GO', false);
};

form.verifyForm = function () {
    var valid = form.validateControlsByIds(form.requiredElements.join(','));
    if (valid && valid.isShowFormErrors == false) {
        return true;
    }
    return false;
};

form.clearFields = function () {
    for (var keyParam in form.formParams) {
        if (keyParam != 'id') {
            delete form.formParams[keyParam];
        }
    }
};

form.foldAmountIncome = function () {
    form.formParams.principalPaymentAmount = (parseFloat(form.formParams.currentDebt || 0) * parseFloat(form.formParams.interestRate || 0)) /12;
};