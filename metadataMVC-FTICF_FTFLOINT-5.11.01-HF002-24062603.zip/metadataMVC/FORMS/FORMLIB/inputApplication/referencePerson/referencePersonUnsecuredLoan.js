/*DSMETA version = "5.11.01-HF002-24062603" hash = "06939e6e1c60ac624beed2f5bdf8a609aa26acbe"*/
function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
var service = registerMethod(service);

var lgr = service.lgr;
var nvl = service.nvl;
var gRB = service.gRB;
var inputParams = form.inputParams;
var outputParams = form.outputParams || {};
form.formParams = inputParams.formParams || {};
outputParams.formParams = form.formParams;
form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.isFormEditMode = form.inputParams.EDITMODE;
form.MobilePhoneNumberMask = form.inputParams.MobilePhoneNumberMask;
form.FixLineMask = form.inputParams.FixLineMask;

var referencePersonList =  form.formParams.referencePersonList || [];
form.templateData={
    address:form.formParams.parentPermanentAddress || {},
    addressText:form.formParams.parentPermanentAddressText || "",
};

form.checkReferencePerson = function(){
    if(form.isFormEditMode && form['tblContactPerson'].getRowsCount() == 0){
        form.contactPersonRequiredItems = [
            {
                caption: "${obligatoryContactItem}"
            }
        ];
    } else{
        form.contactPersonRequiredItems = [];
    }
};

form.settings = {
    tooYoung: inputParams.tooYoung || false,
    cmbRelationshipWithBorrowerParams: {
        ReferenceGroupName: 'Unsecured Loan Application',
        ReferenceSysName: 'RelationshipWithBorrowerConsLOS',
        ReferenceItemName: "Parent"
    }
};

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
    form['tblContactPerson'] ? form['tblContactPerson'].setItems(referencePersonList) : undefined;
    if (form.isFormEditMode){
        //form['addressBlock'] ? form['addressBlock'].setValue(form.formParams.parentPermanentAddress) : form['addressBlock'].setValue(undefined);
        form.checkReferencePerson();
    }
};

form.executeCommand = function(msg){
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
    if (msg.event === 'GO_TO_PAGEFLOW'){
        form.startNewPageFlowProcess(msg.caption, msg.params.PAGEFLOW, {
            APPLICATIONID: msg.params.APPLICATIONID,
            EDITMODE: false
        });
    }
};

form.verifyForm = function (showFlag, tag) {
    var verified = true;
    var buttonNextSave = (form.isLastWizForm) ? "btnSave" : "btnNext";
    if (tag === 'CLOSE') {
        buttonNextSave = "btnCancel";
    }
    try {
        if ((form.validateControlsByIds("*", showFlag === true ? buttonNextSave : undefined).isShowFormErrors)) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    if (form.isFormEditMode){
        form['tblContactPerson'] ? form.formParams.referencePersonList = form['tblContactPerson'].getItems() : form.formParams.referencePersonList = undefined;
        form['cmbRelationshipWithBorrower'] ? form.formParams.parentRelationshipWithBorrowerText = form['cmbRelationshipWithBorrower'].getText() : form.formParams.parentRelationshipWithBorrowerText = undefined;
        //form['addressBlock'] ? form.formParams.parentPermanentAddress = form['addressBlock'].getValue() : form.formParams.parentPermanentAddress = undefined;
        //form['addressBlock'] ? form.formParams.parentPermanentAddressText = form['addressBlock'].getText() : form.formParams.parentPermanentAddressText = undefined;
        form.formParams.parentPermanentAddress = form.addressBlock ? form.addressBlock.data.address : {};
        form.formParams.parentPermanentAddressText  = form.addressBlock ? form.addressBlock.data.address.addressText: "";
        form['edMobilePhoneNumber'] ? form.formParams.parentMobilePhoneText = form['edMobilePhoneNumber'].getText() : form.formParams.parentMobilePhoneText = undefined;
        form['edFixLine'] ? form.formParams.parentFixLineText = form['edFixLine'].getText() : form.formParams.parentFixLineText = undefined;
    }
    if (tagName === 'CLOSE') {
        if (!form.isFormEditMode){
            form.sendForm('GO',false);
        }else {
            form.verifyForm(true, tagName);
            service.showDialogCancelConfirm(
                form,
                function () {
                    outputParams.TRANSTYPE = 'SAVEDRAFT';
                    form.sendForm('GO', false);
                }
            )
        }
    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};

form.tblContactPersonObj = (function (grId) {
    var gridId = grId;
    var options = {
        data: {},
        settings: {
            cmbRelationshipWithBorrowerGridParams: {
                ReferenceGroupName: 'Unsecured Loan Application',
                ReferenceSysName: 'RelationshipWithBorrowerConsLOS',
                ReferenceItemName: "ContactPerson"
            },
            edPhoneNumberGrid: {
                mask: form.inputParams.MobilePhoneNumberMask
            }
        },

        requiredElements: [
            "cmbRelationshipWithBorrowerGrid",
            "edFullNameGrid",
            "edPhoneNumberGrid"
        ],

        cancel: function () {
            form[gridId].hideEditor();
            form.btnContactAdd.enable();
        },
        save: function () {
            var selectedRow = form[gridId].getSelectedRow()[0];
            var newRow = {
                relationshiWithBorrower     : form.cmbRelationshipWithBorrowerGrid.getValue(),
                relationshiWithBorrowerText : form.cmbRelationshipWithBorrowerGrid.getText(),
                fullName                    : form.edFullNameGrid.getValue(),
                phoneNumber                 : form.edPhoneNumberGrid.getValue(),
                phoneNumberText             : form.edPhoneNumberGrid.getText()
            };

            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['id'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.checkReferencePerson();
            form.btnContactAdd.enable();
        },
        clearFields: function () {
            delete options.data.relationshiWithBorrower;
            delete options.data.relationshiWithBorrowerText;
            delete options.data.fullName;
            delete options.data.phoneNumber;
            delete options.data.phoneNumberText;
        },
        edit: function () {
            form.addAddrMode = 'edit';
            form[gridId].showEditor('edit');
            options.clearFields();
            var selectedRow = form[gridId].getSelectedRow()[0];
            form[gridId].options.data = {
                relationshiWithBorrower   : selectedRow["relationshiWithBorrower"],
                fullName                  : selectedRow["fullName"],
                phoneNumber               : selectedRow['phoneNumber']
            };
            form.btnContactAdd.disable();
        },
        delete: function () {
            var row = form[gridId].getSelectedRow()[0];
            if (row) {
                form[gridId].deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
            options.clearFields();
            form.checkReferencePerson();
            form.btnContactAdd.enable();
        }
    };

    var obj = {
        gridId: grId,
        refresh: function () {
            form[gridId].refresh();
        },
        addNewRow: function () {
            form.addAddrMode = 'add';
            form[gridId].showEditor('add');
            options.clearFields();
            form.btnContactAdd.disable();
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (form.isFormEditMode){
                var selRow = form[gridId].getSelectedRow()[0] || {};
                options.items = [
                    {caption: gRB('edit'),   click: form[gridId].options.edit},
                    {caption: gRB('delete'), click: form[gridId].options.delete}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblContactPerson');