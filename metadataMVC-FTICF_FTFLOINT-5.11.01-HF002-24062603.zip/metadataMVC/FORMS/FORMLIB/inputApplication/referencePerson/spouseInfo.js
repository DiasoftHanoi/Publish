/*DSMETA version = "5.11.01-HF002-24062603" hash = "c8d04f9ffe2694191366144239f47929a2029102"*/
function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var lgr = service.lgr;
var nvl = service.nvl;
var gRB = service.gRB;
var inputParams = form.inputParams;
var outputParams = form.outputParams || {};
form.formParams = inputParams.formParams || {};
outputParams.formParams = form.formParams;
form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.isFormEditMode = form.inputParams.EDITMODE;
form.MobilePhoneNumberMask = form.inputParams.MobilePhoneNumberMask;
form.OfficePhoneNumberMask = form.inputParams.OfficePhoneNumberMask;

form.person = {};
form.personDocMask = {
    number: form.person.IdentityCardNumberMask || undefined
};
form.docTypeNewList = form.inputParams.docTypeNewList || [];

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
    if(form['cmbDocumentType'] && form['cmbDocumentType'].getValue()){
        form.onChangeDocType(form.formParams.spouseDocumentType);
    }
    if (form.isFormEditMode){
        form['addressBlock'] ? form['addressBlock'].setValue(form.formParams.spousePermanentAddress) : form['addressBlock'].setValue(undefined);
        form['companyAddressBlock'] ? form['companyAddressBlock'].setValue(form.formParams.spouseJobLegalAddress) : form['companyAddressBlock'].setValue(undefined);
    }
    form['edFullName'].setFocus();
};

form.getMapFromList = function (list, key, val) {
    for (var i = 0; i < list.length; i++) {
        if (list[i][key] + '' === val + '') {
            return list[i];
        }
    }
};

form.setDocMasks = function (docTypeSysName, docTypeList, maskObj) {
    var docType = undefined;
    if (!docTypeSysName || !(docType = form.getMapFromList(docTypeList, 'IdentityCardTypeBrief', docTypeSysName))) {
        maskObj.number = undefined;
        return;
    }
    maskObj.number = docType.NumberMask;
    return maskObj;
};

form.onChangeDocType = function (value) {
    form.personMaskObj = form.setDocMasks(value, form.inputParams.docTypeNewList, form.personDocMask);
};

form.executeCommand = function(msg){
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
    if (msg.event === 'GO_TO_PAGEFLOW'){
        form.startNewPageFlowProcess(msg.caption, msg.params.PAGEFLOW, {
            APPLICATIONID: msg.params.APPLICATIONID,
            EDITMODE: false
        });
    }
};

form.verifyForm = function (showFlag, tag) {
    var verified = true;
    var buttonNextSave = (form.isLastWizForm) ? "btnSave" : "btnNext";
    if (tag === 'CLOSE') {
        buttonNextSave = "btnCancel";
    }
    try {
        if ((form.validateControlsByIds("*", showFlag === true ? buttonNextSave : undefined).isShowFormErrors)) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    if (form.isFormEditMode){
        form['addressBlock'] ? form.formParams.spousePermanentAddress = form['addressBlock'].getValue() : form.formParams.spousePermanentAddress = undefined;
        form['addressBlock'] ? form.formParams.spousePermanentAddressText = form['addressBlock'].getText() : form.formParams.spousePermanentAddressText = '';
        form['companyAddressBlock'] ? form.formParams.spouseJobLegalAddress = form['companyAddressBlock'].getValue() : form.formParams.spouseJobLegalAddress = undefined;
        form['companyAddressBlock'] ? form.formParams.spouseJobLegalAddressText = form['companyAddressBlock'].getText() : form.formParams.spouseJobLegalAddressText = '';
        form['edPhoneNumber'] ? form.formParams.spousePhoneNumberText = form['edPhoneNumber'].getText() : form.formParams.spousePhoneNumberText = undefined;
        form['edOfficePhoneNumber'] ? form.formParams.spouseJobPhoneNumberText = form['edOfficePhoneNumber'].getText() : form.formParams.spouseJobPhoneNumberText = undefined;
        form['cmbDocumentType'] ? form.formParams.spouseDocumentTypeName = form['cmbDocumentType'].getText() : form.formParams.spouseDocumentTypeName = undefined;
    }
    
    if (tagName === 'CLOSE') {
        if(form.inputParams.EDITMODE === false){
            form.sendForm('GO',false);
        }else {
            form.verifyForm(true, tagName);
            service.showDialogCancelConfirm(
                form,
                function () {
                    outputParams.TRANSTYPE = 'SAVEDRAFT';
                    form.sendForm('GO', false);
                }
            )
        }
    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};