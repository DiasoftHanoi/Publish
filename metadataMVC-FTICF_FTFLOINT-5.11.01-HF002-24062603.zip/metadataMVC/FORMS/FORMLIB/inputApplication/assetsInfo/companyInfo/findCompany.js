/*DSMETA version = "5.11.01-HF002-24062603" hash = "3a6472554a5b0650ec57d82c117b4e2ee0e18a1d"*/
function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var gRB = service.gRB;
var log = service.lgr;
var nvl = service.nvl;

var inputParams = form.inputParams;
var outputParams = form.outputParams;
form.params = form.inputParams.rowData;

form.docType_items = [
    {value: "TaxCode", text: "${edTaxCode}"},
    {value: "BusinessRegistrationCertificate", text: "${edTaxCodeBR}"}
];

form.onChangeDocType = function () {
    if (form.params.docType == "BusinessRegistrationCertificate") {
        form.edTaxCode.caption = "${edTaxCodeBR}";
    } else if(form.params.docType == "TaxCode") {
        form.edTaxCode.caption = "${edTaxCode}";
    }
};

form.participantObj = (function (grId) {
    var gridId = grId;
    var obj = {
        gridId: grId,
        remoteMethod: {
            service: 'crmws',
            method: 'dsLegalBrowseListByParam',
            filterParams: {
                //LicenseTypeBrief : form.params.docType || "TaxCode",
                LicenseTypeBrief : (form.params.docType == "" || form.params.docType == undefined) ? "" : form.params.docType,
                Number : (form.params.edTaxCode == undefined || form.params.edTaxCode == "") ? null : form.params.edTaxCode,
                LegalBrief : (form.params.edCompanyName == "" || form.params.edCompanyName === "") ? null : form.params.edCompanyName
            }
        },
        cols : [
            {
                value: 'LegalID',
                type: 'text',
                width: 10
            },
            {
                value: 'LegalBrief',
                type: 'text',
                width: 10
            },
            {
                value: 'INN',
                type: 'text',
                width: 10
            },

        ],
        options : {
        },
        refresh : function (){
            form[gridId].refresh();
        },

        onChangeItems: function () {
        }
    };
    

    return obj;
})();

if (nvl(form.params.docType, "") == "")
    form.params.docType = "TaxCode";

form.find = function () {
    form.participantObj.remoteMethod.filterParams = {
        LicenseTypeBrief :(form.params.edTaxCode === undefined || form.params.edTaxCode === "") ? null : form.params.docType || "TaxCode",
        Number : (form.params.edTaxCode == undefined || form.params.edTaxCode === "") ? null : form.params.edTaxCode,
        LegalBrief : (form.params.edCompanyName == undefined || form.params.edCompanyName === "")? null : form.params.edCompanyName
    };
    log(form.participantObj.remoteMethod.filterParams);
    form.tbParticipant.refresh();
};

form.action = function(transtype, item) {
    if (transtype === "SELECT") {
       var selRow = item ? item : form.tbParticipant.getSelectedRow()[0];
       outputParams.LegalID = selRow.LegalID; 
    }
    if (transtype === "NoInRef") {
       outputParams.noValInRef = true; 
       outputParams.LegalID    = ""; 
    };
form.sendForm("GO",false);
}
