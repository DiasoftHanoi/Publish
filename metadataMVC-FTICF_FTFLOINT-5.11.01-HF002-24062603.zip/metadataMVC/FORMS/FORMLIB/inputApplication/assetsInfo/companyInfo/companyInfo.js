/*DSMETA version = "5.11.01-HF002-24062603" hash = "0074286128ccb55ac52473648061470fbd0ac18d"*/
/* global form, service */


/*function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
var service = registerMethod(service);*/


form.params = form.inputParams.formParams || {};
var convertDate = service.convertDate;
var getTableContent = service.getTableContent;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.isFormEditMode = form.inputParams.EDITMODE || false;
form.isLastWizForm = service.isLastWizForm(form);

var inputParams = form.inputParams;
var outputParams = form.outputParams;

form.formParams = inputParams.formParams || {};
outputParams.formParams = form.formParams;
form.params.legalAddressList = form.params.legalAddressList || [];
form.params.legalAddress = form.params.legalAddressList[0] || {};
form.params.noValInRef = false;
// зависит от того форма в мастере или нет
form.params.actionNext = (inputParams.isMasterFormFlag) ? 'NEXT' : 'NEXT2';
form.templateData={
    address:form.params.legalAddress || {},
    addressText:form.params.legalAddressListText || "",
    addressType : "JuridicalAddress"
    
};
if (!form.isFormEditMode) {
    form.params.dateOfEstablishment = utils.convertDate(form.params.dateOfEstablishment);
    form.params.LegalLicenseDateOfIssue = utils.convertDate(form.params.LegalLicenseDateOfIssue);
}

form.requiredElements = [
    "edCompanyName",
    "edTaxCode",
    "clDateOfEstablishment",
    "edBusinessLine",
    "edProducts",
    "edEmployeesNumber",
    "edQualifiedEmployees",
    "edRepresentativeBusiness",
    "edRelationshipWithCustomer",
    "edDescriptionBusinessOperation"
];
var lgr = service.lgr;
var nvl = service.nvl;
service.lgr(form.params);

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });

};

form.getLegalAddress = function() {
return form.formParams.legalAddressList[0]
};

form.executeCommand = function(msg){
    service.lgr(msg.event);
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
     service.lgr(msg.params.step);   
    }
};
form.getCurDate= function () {
    var now = new Date();
    return service.convertDate(now);
};

form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var save =  form['btnSave'];

        if (form.validateControlsByIds('*', showFlag === true ? save : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.formatAddress = function(AddressMap) {
var blockAddress = {};
    if (AddressMap) {
        blockAddress["City"] = AddressMap["CityBrief"] || "";
        blockAddress["CityId"] = AddressMap["CityCode"] || "";
        blockAddress["Country"] = AddressMap["CountryBrief"] || "";
        blockAddress["District"] = AddressMap["AreaBrief"] || "";
        blockAddress["DistrictId"] = AddressMap["AreaCode"] || "";
        //blockAddress["Flat"] = AddressMap["Flat"] || "";
        //blockAddress["House"] = AddressMap["House"] || "";
        blockAddress["Region"] = AddressMap["RegionBrief"] || "";
        blockAddress["RegionId"] = AddressMap["RegionCode"] || "";
        //blockAddress["Street"] = AddressMap["StreetBrief"] || "";
        //blockAddress["StreetId"] = AddressMap["StreetCode"] || "";
        blockAddress["Town"] = AddressMap["TownBrief"] || "";
        blockAddress["TownId"] = AddressMap["TownCode"] || "";
        //blockAddress["PostalCode"] = AddressMap["PostIndex"] || "";
    }
    return blockAddress;
};

form.findCompany = function () {
    var projectSysname = form.getCurrentProjectSysname();
    var pfd = '/FORMLIB/inputApplication/assetsInfo/companyInfo/findCompany';
    form.startModalPageFlowProcess(projectSysname+pfd, {
        rowData: {}
    }).then(
    function(response) {
        if (response.legalResult) {
            var legalResult = response.legalResult;
            var LegalAddressList = legalResult.LegalAddressList || [];
            for (var i=0;i<LegalAddressList.length;i++) {
                var ActiveFlag = LegalAddressList[i]["ActiveFlag"];
                if(ActiveFlag) {
                    //form.params.legalAddress = form.formatAddress(LegalAddressList[i]);
                    if(form.edLegalAddressBlock) {
                        var AddressMap = LegalAddressList[i];
                        form.edLegalAddressBlock.data.address.RegionId=AddressMap["RegionCode"] || "";
                        setTimeout(
                            function(){
                                form.edLegalAddressBlock.data.address.DistrictId=AddressMap["AreaCode"] || "";
                                setTimeout(function(){form.edLegalAddressBlock.data.address.CityId=AddressMap["CityCode"] || "";},400);
                            
                            },300);
                        //form.edLegalAddressBlock.data.address.TownId=AddressMap["TownCode"] || "";
                    }
                    //form.edLegalAddress.setValue(form.formatAddress(LegalAddressList[i]));
                    break;
                }
            }
            var LegalLicenseList = legalResult.LegalLicenseList || [];
            for (var i=0;i<LegalLicenseList.length;i++) {
                var ActiveFlag = LegalLicenseList[i]["ActiveFlag"];
                var licenseType = LegalLicenseList[i]["LicenseTypeBrief"];
                if(ActiveFlag) {
                    if (licenseType === "TaxCode") {
                        form.params.Number = LegalLicenseList[i]["Number"];
                    }
                    if (licenseType === "BusinessRegistrationCertificate") {
                        form.params.busRegNumber = LegalLicenseList[i]["Number"];
                        form.params.LegalLicenseIssuer = LegalLicenseList[i]["Issuer"];
                        form.params.LegalLicenseDateOfIssue = LegalLicenseList[i]["DateOfIssue"];
                    }
                }
            }
            form.params.companyName = legalResult.BRIEFNAME;
            form.params.LEGALID = legalResult.LegalID;
        }
        form.params.noValInRef = response.noValInRef;
    });
};

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    outputParams.formParams.LegalExtendedAttList = [];
    //outputParams.formParams.LegalLicenseList = [];
    outputParams.formParams.LinkID = form.formParams.LinkID ? form.formParams.LinkID : new Date().getTime();
    if (form.isFormEditMode) {
        outputParams.formParams.fabIndex = form.params.fabIndex;
        if (!form.formParams.sysnameTypeAssets && inputParams.COLLATERALMODE != 'ADD')
            outputParams.formParams.sysnameTypeAssets = "ValuablePaper";
        outputParams.formParams.legalName                = form.params.companyName;
        outputParams.formParams.LegalBrief                      = form.params.companyName;
        outputParams.formParams.LicenseTypeBrief                      = "TaxCode";
        outputParams.formParams.Number             = form.params.Number;
        outputParams.ClientFlag = false;
        outputParams.formParams.LegalExtendedAttList = [{SysName:"dateFormation",
                                                         DateValue:form.params.dateOfEstablishment,
                                                         //LinkID : outputParams.formParams.LinkID
                                                        }];
        outputParams.formParams.dateFormation = form.params.dateOfEstablishment;                                                
        outputParams.formParams.legalAddressList        = [form.edLegalAddressBlock.data.address];
        outputParams.formParams.legalAddressListText        = form.edLegalAddressBlock.data.address.addressText;
        outputParams.formParams.BusinessLine            = form.params.BusinessLine;
        outputParams.formParams.Products         = form.params.Products;
        outputParams.formParams.StaffNumber  = form.params.StaffNumber;
        outputParams.formParams.QualifiedEmployees   = form.params.QualifiedEmployees;
        outputParams.formParams.RegisteredCapital       = form.params.RegisteredCapital;
        outputParams.formParams.AverageIncome                  = form.params.AverageIncome;
        outputParams.formParams.RepresentativeBusiness       = form.params.RepresentativeBusiness;
        outputParams.formParams.DescriptionBusinessOperation        = form.params.DescriptionBusinessOperation;

        outputParams.formParams.legalLicenseList = [{LicenseTypeBrief:"BusinessRegistrationCertificate",
                                                     Number:form.params.busRegNumber,
                                                     Issuer:form.params.LegalLicenseIssuer,
                                                     DateOfIssue:form.params.LegalLicenseDateOfIssue,
                                                     StatusBrief:"valid"}
                                                    ];
        if (nvl(form.params.Number, '') != '')
            outputParams.formParams.legalLicenseList.push({LicenseTypeBrief:"TaxCode",
                                                           Number:form.params.Number,
                                                           StatusBrief:"valid"
                                                          });
        outputParams.LEGALID = form.params.LEGALID;
       

    }
    if (tagName === 'CLOSE') {
        if (form.isFormEditMode) {
            form.CancelValuableForm(form);
        } else {
            form.outputParams.TRANSTYPE = 'CLOSE';
            form.sendForm('GO',false);
        }
    } else {

        if (tagName === 'EXIT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
			if (tagName === 'COMPLETE') { 
               form.commandAll({event: "COMPANY_LIST", params: outputParams.formParams}); 
			}
        }
        form.sendForm('GO', false);
    }
   
};
// изменяет признак Основной документ при добавлении второго основного документа
form.CancelValuableForm = function (BaseIdentityCardFlag, gridId) {
    form.mainDocFlag = true;
    form.showInformationDialog(gRB("dialog.confirmCancelValuable"), function(response){
        switch (response.buttonIndex){
            case 0:
                form.outputParams.TRANSTYPE = 'CLOSE';
                form.sendForm('GO',false);
                break;
        }
    }, [{caption: gRB("dialog.yes"), kind:"info small"}, {caption: gRB("dialog.cancel"), kind:"info small"}]);
};

form.noValInRefChange = function () {
    if (form.params.noValInRef)
        form.params.LEGALID = "";
};