/*DSMETA version = "5.11.01-HF002-24062603" hash = "3b68c9ea8462dedaec244fea0bd52adb45ec619d"*/
/* global form, service */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams  || {};

var outputParams = form.outputParams || {};
outputParams.formParams = form.formParams;

var lgr = service.lgr;
var nvl = service.nvl;
var gRB = service.gRB;

form.isFormEditMode = form.inputParams.EDITMODE || false;

form.settings = {
    rgTypeOwner_ITEMS : [
        {value : "individualHousehold", text : "${individualHousehold}"},
        {value : "company", text : "${company}"}
    ],
    cmbTypePropertyComboBoxParams: {
        ReferenceSysName: 'typePropertyLOS',
        ORDERBY: 'ReferenceItemID'
    },
    requiredElements : [
        "cmbCollateralOwner",
        "cmbTypeProperty",
        "rgTypeOwner",
        "cmbAssets"
    ],
    cmbCollateralOwnerEnableFlag : true,
    cmbCollateralOwnerRequiredFlag : true
};

form.onShow = function () {

};

form.action = function (tagName) {
    outputParams.COLLATERALMODE = tagName;
    if (!form.formParams.cmbAssets) {
        form.formParams.cmbAssets = new Date().getTime();
    }
    form.sendForm('GO', false);
};

form.fillAssetsCombo = function () {
    form.settings.cmbAssets_ITEMS = undefined;
    if (form.cmbAssets) {     // временно, пока не починят очистку через двунаправленную связь
        form.cmbAssets.clearItems();
        form.cmbAssets.items = null;
        form.cmbAssets.value = null;
    }
    var cmbCollateralOwner = (form.cmbCollateralOwner) ? form.cmbCollateralOwner.getValue() : "";
    if (cmbCollateralOwner && form.cmbAssets && !form.formParams.cbThirdParty) {
        form.dsCall("[frontws2]", "documentGetByIdOld", {
            DOCUMENTID: cmbCollateralOwner
        }).then(function (p) {
            p = nvl(p['data']['Result'], []);
            var assetsList = p.assetsList;
            var cmbAssetsTemp_ITEMS = [];
            for (var i = 0, count = assetsList.length; i < count; i++) {
                var assetsMap = assetsList[i];
                var assetTemp =  assetsMap.typeAssets;
                var typeProperty = (form.formParams.cmbTypeProperty) ? form.formParams.cmbTypeProperty.toLowerCase() : "";
                var isCollateral = "" + assetsMap.isCollateral;
                if (isCollateral == "true") {
                    continue;
                }
                if (assetsMap.sysnameTypeAssets) {
                    if (assetsMap.sysnameTypeAssets.toLowerCase() == "realestate" && typeProperty == "realestate") {
                        assetTemp += (assetsMap.addressString) ? ", " + assetsMap.addressString : "";
                        cmbAssetsTemp_ITEMS.push({value: assetsMap.LinkID, text: assetTemp});
                    } else if (assetsMap.sysnameTypeAssets.toLowerCase() == "vehicle" && typeProperty == "vehicle") {
                        assetTemp += (assetsMap.brandCar) ? ", " + assetsMap.brandCar : "";
                        assetTemp += (assetsMap.noChassis) ? ", " + assetsMap.noChassis : "";
                        assetTemp += (assetsMap.engineNumber) ? ", " + assetsMap.engineNumber : "";
                        cmbAssetsTemp_ITEMS.push({value: assetsMap.LinkID, text: assetTemp});
                    }
                }
            }
            form.settings.cmbAssets_ITEMS = cmbAssetsTemp_ITEMS;
        })
    }
};

form.changeThirdParty = function() {
    var cmbCollateralOwnerEnableFlag = true;
    if (form.formParams.cbThirdParty) {
        cmbCollateralOwnerEnableFlag = false;
        form.formParams.cmbCollateralOwner = null;
    }
    form.settings.cmbCollateralOwnerEnableFlag = cmbCollateralOwnerEnableFlag;
    form.settings.cmbCollateralOwnerRequiredFlag = cmbCollateralOwnerEnableFlag;
    form.formParams.cbNewObject = !cmbCollateralOwnerEnableFlag;
};

form.changeNewObject = function() {
    if (form.formParams.cbNewObject) {
        form.formParams.cmbAssets = null;
    }
};