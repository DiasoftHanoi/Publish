template.inputParams = template.data.parentForm.inputParams || {};
template.isFormEditMode = (template.data.parentForm.inputParams.EDITMODE==true || template.data.parentForm.inputParams.EDITMODE=='true') ? 'true' : 'false';

