function registerMethod(initService){
    var service={};
    for (var ar in initService){
        if (initService.hasOwnProperty(ar)){
            if (ar.indexOf('Service')>-1 || typeof (initService[ar]) != 'function'){
                service[ar]=initService[ar];
            }else{
                var fn=initService[ar].toString();
                if (fn && fn.length) {
                    var sIdx=fn.search(/\(/)+1;
                    var eIdx=fn.search(/\)\{/);
                    var args=fn.substring(sIdx,eIdx)
                    eval("service."+ar+"=function("+args+")"+fn.substring(eIdx+1,fn.length));
                }
            }
        }
    }
    return service;
}
service=registerMethod(service);

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;

var outputParams = form.outputParams || {}
outputParams.formParams = form.formParams;

var lgr = service.lgr;
var nvl = service.nvl;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.isMrtg_OfficerOD = inputParams.isMrtg_OfficerOD;

/*form.addPledge = function(){
    form.startNewPageFlowProcess("Добавление информации по объекту залога",  form.getCurrentProjectSysname() + '/' + inputParams.PAGEFLOWNAME, {
        EDITMODE:true,
        MAINAPPLICATIONID: inputParams.APPLICATIONID
    }, true, null, function(p){
        form['pledgeTable'].refresh();

    });
}*/

form.pledgeObj = (function (grId) {
    var gridId = grId;
    var obj = {
        gridId: grId,
        options : {
            gRB:service.gRB,
            checkStateType:function(state){
                state+="";
                var res="process";
                if (state.search(/оформлен/gi)>-1){
                    res="done";
                }else
                if (state.search(/annul/gi)>-1 ||
                    state.search(/аннул/gi)>-1 ||
                    state.search(/отказ/gi)>-1){
                    res="error";
                }
                return res;
            },
            getCurrentProjectSysname:form.getCurrentProjectSysname,
            getPledgeName: function(item){
              return item.pledgeType=='mainPledgeApp' ? 'Основное' : 'Дополнительное' ; // переделать
            },
            checkType: function(item){
                if(item.pledgeType == "mainPledgeApp"){
                    return true;
                }else{
                    return false;
                }
            },
            checkState: function(item){
                if(item.STATE == "Одобрено" || item.STATE == "Отказано"){ //решение принято
                    return true;
                }else{
                    return false;
                }
            },
            items : [{
                caption: "Просмотр",
                click: form.editPledge
                }
            ]
        },
        filterParams : {
            PACKAGEID: inputParams.PACKAGEID || 0,
            LINKTYPENAMES: ["PledgeApp"],
            STATETYPE_NOT_EQUAL: 2
        }

    };

    return obj;
})('pledgeTable');

form.onSelectApplication=function(item){
    lgr('onSelectApplication', arguments);
    var params = {
        APPLICATIONID : item.DOCUMENTID,
        application : {executeSource:'applicationList'}
    };
    form.pledgeObj.options['ID' + item.DOCUMENTID+item.STATE] = undefined;
        form.startProcess(
            form.getCurrentProjectSysname()+'/COMMON/APPLICATION/getTransferList',
            params,
            function (p) {
                lgr('fillTransfers', p);
                var transfersList = nvl(p['transfersList'],{});
                var resActions=[];
                if (transfersList && transfersList.length) {
                    for (var i=0;i<transfersList.length;i++){
                        resActions.push({
                            caption:transfersList[i]["NAME"],
                            click:function(){form.onApplicationAction(this,item)},
                            TRANSITIONID:transfersList[i]["TRANSITIONID"]
                        })
                    }
                }
                form.pledgeObj.options['ID' + item.DOCUMENTID+item.STATE] = resActions;
            });
};

form.onApplicationAction=function(data,item){
    form.pledgeTable.setSelectedRow(undefined);
    form.pledgeObj.options['ID' + item.DOCUMENTID+item.STATE] = null;


    form.startNewPageFlowProcess(
        data.caption+'. Заявка №'+nvl(inputParams.DOCUMENTNUMBER,''),
        form.getCurrentProjectSysname() + '/' + 'COMMON/STATEMACHINE/callPageflowByTransfer', {
        APPLICATIONID:item.DOCUMENTID,
        MAINAPPLICATIONID: inputParams.APPLICATIONID,
        TRANSITIONID:data.TRANSITIONID,
        isMrtg_OfficerOD:form.isMrtg_OfficerOD
    }, true, null, function(p){
        form['pledgeTable'].refresh();
        setTimeout(form.refreshPledgeTable,1000);
     });
};

form.checkedStatus = function() {
    var validate = true;

    return validate;
};

form.verifyForm = function (showFlag) {
    var verified = form.checkedStatus();
    if (!verified) {
        return;
    }
    outputParams.VERIFIED = verified;
    return verified;
};


form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    outputParams.VERIFIED = true;
    if (tagName === 'NEXT') {
        form['pledgeTable'].refresh();
        if (!form.verifyForm(true) || !form.getAllPledgeDecisions()) {
            return;
        };
        form.sendForm('NEXT', false);
    };
    if (tagName === 'CLOSE') {
        form.sendForm('GO', false);
    }
};

form.getAllPledgeDecisions = function() {
        var list = form.pledgeTable.listGrid;
        for (var i=0; i<list.length; i++) {
            if (form.pledgeObj.options.checkState(list[i]) != true) {
                form.showErrorDialog("Не по всем залогам принято решение", function () {});
                return false;
            }
        };
        return true;
 };

function checkTable() {
    form['pledgeTable'].refresh();
    var list = form.pledgeTable.listGrid;
    var stopFlag = true;
    for (var i = 0; i < list.length; i++) {
        var map = list[i];
        if (map.STATE == 'Ожидание' || map.STATE == 'Принятие решения') {
            stopFlag = false;
            break;
        }
    }
    if (!stopFlag)
        form.refreshPledgeTable();
};

form.refreshPledgeTable = function () {
    var list = form.pledgeTable.listGrid;
    var stopFlag = true;
    for (var i = 0; i < list.length; i++) {
        var map = list[i];
        if (map.STATE == 'Ожидание' || map.STATE == 'Принятие решения') {
            stopFlag = false;
            break;
        }
    }
    if (!stopFlag)
        setTimeout(checkTable, 5000);
};

