/* global form, service */
function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;

var outputParams = form.outputParams || {}
outputParams.formParams = form.formParams;

var lgr = service.lgr;
var nvl = service.nvl;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.isFormEditMode = form.inputParams.EDITMODE || false;


form.onShow = function () {

    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
    form.tblRoomTypeObj.setItems(form.inputParams.SelectedRow.RoomTypeList || []);

};
var RoomTypeLis = form.inputParams.SelectedRow.RoomTypeList ||[];
form.pnlRoomTypeIsCollapsed=RoomTypeLis.length>0 ?false :true ;
form.executeCommand = function (msg) {
    switch (msg.event) {
        case 'FAB_NAVIGATOR_NAVIGATE':
            outputParams.NEXTPAGE = msg.params.step;
            form.action('DIRECT');
        break;
        default:
            break;
    }
};
inputParams.incomeList_ITEMS = [{
    value: 'yes',
    text: gRB('fieldCheck.yes')
}, {
    value: 'no',
    text: gRB('fieldCheck.no')
}, {
    value: 'notConfirmed',
    text: gRB('fieldCheck.notConfirmed')
}
];
form.inputParams.PaymentTerm_ITEMS=[
    {
        value: 'monthly',
        text: gRB('paymentTerm.monthly')
    },
    {
        value: 'quarterly',
        text: gRB('paymentTerm.quarterly')
    },{
        value: 'annually',
        text: gRB('paymentTerm.annually')
    }
];
form.GetIncomeListText=function(value){
    var str="fieldCheck."+value;
    return form.getResourceBundle(str);
};

form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var save =  form['save'];

        if (form.validateControlsByIds('*', showFlag === true ? save : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.yesFunc = function() {

    outputParams.TRANSTYPE = 'SAVEDRAFT';
    if (form.verifyForm()) {
        form.sendForm('GO', false);
    }
};
form.GetIncomeListText=function(value){
    var str="fieldCheck."+value;
    return form.getResourceBundle(str);
};
form.templateData = {
    inputParams: form.inputParams,
    parentForm: form,
    tabIndex:190,
    noRecords:form.getResourceBundle('noRecords')
};

form.tblRoomTypeObj = (function(grId){

    var gridId = grId;
    var options = {
        requiredElements : [
            "edRoomType",
            "edRentAmount",
            "edQuantity"
        ],
        RoomTypeList: form.inputParams.SelectedRow.RoomTypeList,
        data: {},
        clearFields: function () {
            delete options.data.RoomType;
            delete options.data.Quantity;
            delete options.data.RentAmount;
        },
        cancelFields:function(){
            options.clearFields();
            form[gridId].hideEditor();
            form.btnRoomTypeAdd.enable();
        },
        saveFields:function(){
            var selectedRow = form.RoomTypeListId.getSelectedRow()[0];
            var newRow ={
                RoomType                : form.edRoomType.getValue(),
                Quantity                : form.edQuantity.getValue(),
                RentAmount              : form.edRentAmount.getValue(),

            };
            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['id'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnRoomTypeAdd.enable();
        },
        edit: function () {
            options.clearFields();
            var selectedRow = form.RoomTypeListId.getSelectedRow()[0];
            form[gridId].showEditor('edit');
            form.tblRoomTypeObj.options.data = {
                RoomType            : selectedRow["RoomType"],
                Quantity            : selectedRow["Quantity"],
                RentAmount          : selectedRow["RentAmount"],

            };
            form.btnRoomTypeAdd.disable();
        },
        delete: function () {
            if (form.RoomTypeListId.getSelectedRow()[0]) {
                form.RoomTypeListId.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
            form.btnRoomTypeAdd.enable();
        },
    };

    var obj = {
        addNewRow: function () {
            form.pnlRoomTypeIsCollapsed = false;
            form[gridId].showEditor('add');
            options.clearFields();
            form.btnRoomTypeAdd.disable();
        },
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (form.isFormEditMode==='true') {
                var selRow = form[gridId].getSelectedRow()[0] || {};
                options.items = [
                    {caption: gRB('edit'),   click: form.tblRoomTypeObj.options.edit},
                    {caption: gRB('delete'), click: form.tblRoomTypeObj.options.delete}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('RoomTypeListId');
form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    outputParams.SelectedRow=inputParams.SelectedRow;
    if(form.isFormEditMode ==='true'){
        inputParams.SelectedRow.PaymentTerm=form.cbPaymentTerm.getText();
        outputParams.SelectedRow.RoomTypeList  = form.tblRoomTypeObj.getItems();
        outputParams.SelectedRow.rentingFaresSimilar=inputParams.SelectedRow.rentingFaresSimilar;
    }
    if (tagName === 'CLOSE') {
        if(form.isFormEditMode === 'false'){
            form.sendForm('GO',false);
        }else{
            service.showDialogCancelConfirm(
                form,
                form.yesFunc
            )
        }
    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
}
