form.formParams = form.inputParams;
form.outputParams = form.formParams;

form.action = function (tagName) {
    form.formParams.TRANSTYPE = tagName;
    form.sendForm(tagName);
}