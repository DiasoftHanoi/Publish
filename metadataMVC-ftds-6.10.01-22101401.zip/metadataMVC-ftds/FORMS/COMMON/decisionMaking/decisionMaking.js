/* global form */

form.outputParams = {};

form.formParams = form.inputParams;
form.outputParams = form.formParams;

form.onShow = function () {

    if(form.rbDecisionType.value!=null){
        form.bNext.enabled=true;
    }
    form.tbCheckList.setItems(form.formParams.checksFormatList || []);

};
form.selectedId = -1;
form.formSettings = {
    DECISIONTYPE_ITEMS: form.formParams.decisionItems, 
    /*[
        {value: 'positive', text: 'Положительное'},
        {value: 'negative', text: 'Отрицательное'},
        {value: 'torework', text: 'Вернуть на доработку'}
    ],*/
    isShowRefuseReason: false
};
form.onChangeCheckDetails = function () {
    var selRows = form.tbCheckList.getSelectedRow();
    var selRow = null;
    if (selRows.length > 0) {
        selRow = selRows[0];
    }
    console.log('selRow');
    console.log(selRow);
    var chkDetails = selRow["CHECKDETAILS"];
    if (chkDetails == '') {

        chkDetails = 'Отсутствует протокол для выбранной проверки';
    }
    //form.startModalPageFlowProcess("FTDSMVC/COMMON/decisionMaking/checkComment", {CHECKDETAILS : selRow["CHECKDETAILS"]});
    form.showModalDialog("large", "Протокол проверки:", chkDetails, null, [{caption: "OK"}], function () {
    });
}

form.checksOptions = {
    'items': [
        {caption: 'Протокол проверки', click: form.onChangeCheckDetails}
    ]
}
form.REFUSEREASON_ITEMS = form.formParams.reasonListNew;

form.onChangeRefuseReason = function (value) {

}
form.onChangeDecisionType = function (value) {

    if(form.rbDecisionType.value!=null){
        form.bNext.enabled=true;
    }

    if (value == "negative") {
        form.formSettings.isShowRefuseReason = true;
    } else {
        form.formSettings.isShowRefuseReason = false;
    }
}


form.tbAttachedDocsOptions = form.inputParams.allAttachedDocList;

form.requiredControls = function () {
    return ([
            'rbDecisionType'
        ].join(',')) +
        (form.formSettings.isShowRefuseReason ? ',refuseReason' : "");
};
form.verifyForm = function (showFlag) {
    var veri_fied = false;
    try {
        var validateRes = form.validateControlsByIds(form.requiredControls());
        if (!validateRes["isShowFormErrors"] && validateRes["requiredComponents"].length == 0 && validateRes["notValidComponents"].length == 0) {
            veri_fied = true
        } else {
            throw "Присутствуют некорректно заполненные поля";
        }
        var decisionType = form.formParams.rbDecisionType;
        var checkResultErrorFlag = form.formParams.checkResultErrorFlag;
        if (decisionType === 'positive' && checkResultErrorFlag) {
            form.showInformationDialog("Имеются проверки со статусом 'Ошибка'. Необходимо перезапустить проверки");
            veri_fied = false;
        }
    } catch (e) {
        if (showFlag) {
            form.showErrorDialog(e, function () {
            }, [{caption: 'ОК'}]);
        }
    }
    return veri_fied;
}

form.executeCommand = function (message) {
    switch (message.event) {
        case 'GO_TO_PAGE':
            form.outputParams.TRANSTYPE = 'DIRECT';
            form.outputParams.NEXTPAGE = message.params.page;
            form.sendForm('GO', false);
            break;
        case 'WIZARD_DIRECT':
            form.outputParams.NEXTPAGE = message.WIZFORMID;
            form.sendForm('GO', false);
            break;
    }
};

form.action = function (tag) {
    if (tag == "NEXT") {
        if (!form.verifyForm(false)) {
            return;
        }
    }
    if (form.refuseReason) form.outputParams.refuseDescription = form.refuseReason.getText();
    form.sendForm(tag, false);
};