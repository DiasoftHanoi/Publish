template.formParams = template.data;
template.productGroupParamMap = template.formParams.productGroupParamMap || {};
template.inputParams = template.data.inputParams;
template.strToNum = service.strToNum;
template.onShow = function(){
    template.calculationLTV();
   if(template['nonStandartLTV']){
       template.nonStandartLTV.setFocus();
   }
};

template.calculationLTV = function () {
    var params = {
        formulaSysNameLTV: template.productGroupParamMap.formulaCalculatorCalcLTV? template.productGroupParamMap.formulaCalculatorCalcLTV.VALUE1 : gRB('noValue'),
        formulaSysNameLTVMSK: template.productGroupParamMap.formulaCalculatorCalcLTVWithMaternityCapital? template.productGroupParamMap.formulaCalculatorCalcLTVWithMaternityCapital.VALUE1 : null,
        propertyCost: Number(template.formParams.propertyCost),
        downPayment: Number(template.formParams.downPayment),
        creditAmount: Number(template.formParams.maxCreditAmountCC),
        maternityCapitalAmount: Number(template.formParams.maternityCapitalAmount)
    };
    form.startProcess('FTFLOANSMVC/COMMON/CALC/PROODUCTINFO/calculateLTV', {
        paramsLTV: params,
        formParams: template.formParams,
        APPLICATIONID: template.formParams.objId
    }, function(){}, true).then(function (response){
        if (response.lastErrorFlag){
            throw response.lastErrorMessage;
        }
        template.formParams.calculateLTV = response.calcLTV ? response.calcLTV.toFixed(2): 0;
        template.formParams.calculateLTVBeforeMaternityCapital = response.calcLTVMSK && template.productGroupParamMap.StandardLTVWithMaternityCapitalVisible ? response.calcLTVMSK.toFixed(2): 0;


    }).catch(function (err){
        form.showErrorDialog(err+'', function(){}, [{caption: form.getResourceBundle('dialog.ok')}]);
    });
};