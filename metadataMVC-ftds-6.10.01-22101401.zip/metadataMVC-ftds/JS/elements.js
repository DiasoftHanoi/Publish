/*DSMETA version = "6.01.01" hash = "5ce3901da8f2f5261699a30c4c0c51293cfc5d02"*/
/*
 initElementIdsJS 1.0 Copyright 2012 OOO "Diasoft". All rights reserved.
*/
function initElementIdsJS(){
/*EI=[];
var e=getAllIds();
for(var t=0;t<e.size();t++){
	var n=e.get(t),r=n.lastIndexOf("_");
	r=r==-1?n.lastIndexOf("."):r,r==-1?r=0:r++,EI[n.substring(r)]=n.replace(/[_]/gi,".")
}
*/
function getLastID(elID){
		var idxSL=elID.lastIndexOf("_");
	    var idxDot=elID.lastIndexOf(".");
	    if (idxDot==-1){idxDot=idxSL;  if (idxDot==-1) {idxDot=0;}else{idxDot++};}else{idxDot++}
		return [elID.substring(idxDot),idxDot];
	}
	EI=[];
	var eIds=getAllIds();
	for( var i=0;i<eIds.size();i++){
	   var elID=eIds.get(i);
	   var keyData = getLastID(elID);
	   var key=keyData[0];
	   var idx=keyData[1];
	   if (key=="parent"){
	      elID=elID.substring(0,idx-1);
		  key=getLastID(elID)[0];
         
	   }
	   EI[key]=elID.replace(/[_]/gi,".");
	}
}

//