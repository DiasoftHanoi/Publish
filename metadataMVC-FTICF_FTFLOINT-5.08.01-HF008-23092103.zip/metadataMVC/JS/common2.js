/*DSMETA version = "5.08.01-HF008-23092103" hash = "51bf27ed010f1509f4fb4cbf72ae0922a3d601e2"*/
/* global java, service */

function huAU(el,r){
	if(!r)r="\n";
	var str=[];
	str[0]="("+typeof el+") = "+el;
	for(var k in el)
		if(!/erHTML/.test(k))
			str[str.length]=k+"("+typeof el[k]+")"+" = "+el[k];
		str.sort();
		str=str.join(r);
		return str
}
function _Map_(map){
	if (map instanceof Object) this.putAll(map);
}
_Map_.prototype = {
	isMap : function(){
		return true;
	},
	size : function(){
		return Object.keys(this).length;
	},
	isEmpty : function(){
		return Object.keys(this).length == 0;
	},
	get : function(key){
		return this[key];
	},
	containsKey : function(key){
		if (key in this){
			return true;
		} else {
			return false;
		}
	},
	put : function(key,value){
		this[key] = value;
		return this;
	},
	putAll : function(map){
		var keys = Object.keys(map);
		/*console.log(keys);*/
		for (var i in keys) {
			/*console.log('i='+i);
			console.log('keys[i]='+keys[i]);*/
			this.put(keys[i],map[keys[i]]);
		}
		return this;
	},
	remove : function(key){
		delete this[key];
		return this;
	},
	clear : function(){
		var keys = Object.keys(this);
		for (var i in keys) {
			delete this[keys[i]];
		}
		return this;
	},
	forEach : function(callback){
		var len = this.size();
		for (var i = 0; i < len; i++) {
			var k = Object.keys(this)[i];
			var item = this.get(k);
			callback(item,k);
		}
		return this;
	}
};

function getNewMap(map){
	return new _Map_(map);
}
function getNewList(list){
	return (list instanceof Array ? list : new Array());
}

function getNewLinkedEntityId(list,key,tempList){
	if (list == null || list.size()==0) return 0;

	var res = list.size();
	for (var next=0;next<list.size();next++){
		var found = false;
		for (var i=0;i<list.size();i++){
			var listRowNum = parseFloat(list[i][key]);
			if (isNaN(listRowNum)) continue;
			if (next==listRowNum){
				found = true;
				break;
			}
		}
		if (!found){
			res = next;
			break;
		}
	}
	/********/
	return res;
}


function trim(s){return s!=null?(s+"").replace(/^[ \t]+|[ \t]+$/g,""):""}

function nvl(val, def){
	if (typeof val == "undefined" || val == null || val === "") return def;
	return val;
}

function objExtend(Child, Parent){
	    var F = function() { };
	    F.prototype = Parent.prototype;
	    Child.prototype = new F();
	    Child.prototype.constructor = Child;
	    Child.superclass = Parent.prototype;
}

function liderZero(i){
    if (i < 10) i = '0' + stringToNumeric(i);
    return i;
}

function datePars(str, tostr){
	var dateRazd = String('d.m.y').replace('y', '').replace('m', '').replace('d', '').substr(0, 1);
	var datePor = String('d.m.y').split(dateRazd).join('');
	var timeRazd = ':';
	var timePor = 'HMS';
    if (str == null) {
        return null;
    }
    var d = [];
    if (typeof(str) == 'string') {
        if (/^\d{4}-\d{2}-\d{2}[T| ]\d{2}:\d{2}:\d{2}:\d{3}\+\d{4}$/.test(str))
            str = str.replace(/^(\d{4})-(\d{2})-(\d{2})[T| ](\d{2}):(\d{2}):\d{2}:\d{3}\+(\d{4})$/, "$3.$2.$1 $4:$5");

        if (RegExp('^([1-9]|0[1-9]|[12][0-9]|3[01])[\\.]([1-9]|0[1-9]|1[012])[\\.][1-9]{1}[0-9]{3}( ([0-1]{1}[0-9]{1}|2[0-3]{1}):[0-5]{1}[0-9]{1}:[0-5]{1}[0-9]{1})?$', 'i').test(str)) {
            var dt = (str + '').split(' ');
            var tmp = dt[0].split(dateRazd);
            d = new Array();
            str = datePor;
            for (var i = 0; i < 3; i++)
                d[str.substr(i, 1)] = tmp[i];
            if (dt.length > 1) {
                tmp = dt[1].split(timeRazd);
            } else {
                tmp = ['00', '00'];
            }
            str = timePor;
            for (var i = 0; i < 2; i++)
                d[str.substr(i, 1)] = tmp[i];
        }
        d['ox'] = '+0000';//(new Date(d['y'], (d['m'] - 1), d['d'])).getOffset();
    } else {
        d = new Array();
        d['y'] = str.getFullYear();
        d['m'] = liderZero(str.getMonth() + 1);
        d['d'] = liderZero(str.getDate());
        d['ox'] = str.getOffset();
    }
    if (d)
        if (tostr) {
            tmp = d[datePor.substr(0, 1)] + dateRazd + d[datePor.substr(1, 1)] + dateRazd + d[datePor.substr(2, 1)];
            d = tmp;
        }
    return d;
}

function changeDateAsDate (str, d, m, y){
    if (str == null) {
        return null;
    }
    var tmp = datePars(str);
    tmp['d'] = stringToNumeric(tmp['d']) + stringToNumeric(d + '');
    tmp['m'] = stringToNumeric(tmp['m']) - 1 + stringToNumeric(m + '');
    tmp['y'] = stringToNumeric(tmp['y']) + stringToNumeric(y + '');
    tmp = new Date(tmp['y'], tmp['m'], tmp['d']);
    return tmp;
}

// function convertDate(str){
// 	var dateRazd = String('d.m.y').replace('y', '').replace('m', '').replace('d', '').substr(0, 1);
// 	var datePor = String('d.m.y').split(dateRazd).join('');
// 	var timeRazd = ':';
// 	var timePor = 'HMS';
//     var str2 = (str + '').replace(/ [^ ]{3,} (\d{4})$/g, " $1");
//     if (!(/^([1-9]|0[1-9]|[12][0-9]|3[01])[\.]?([1-9]|0[1-9]|1[012])[\.]?[1-9]{1}[0-9]{3}$/i).test(str2)) {
//         var tmp = new Date(str2);
//         var d = new Array();
//         d['y'] = tmp.getFullYear();
//         var tMon = tmp.getMonth();
//         d['m'] = (tMon + 1) < 10 ? "0" + (tMon + 1) : (tMon + 1);
//         var tDay = tmp.getDate();
//         d['d'] = tDay < 10 ? "0" + tDay : tDay;
//         var tHour = tmp.getHours();
//         d['H'] = tHour < 10 ? "0" + tHour : tHour;
//         var tMin = tmp.getMinutes();
//         d['M'] = tMin < 10 ? "0" + tMin : tMin;
//         var tSec = tmp.getSeconds();
//         d['S'] = tSec < 10 ? "0" + tSec : tSec;
//         str = '' + d[datePor.substr(0, 1)] + dateRazd + d[datePor.substr(1, 1)] + dateRazd + d[datePor.substr(2, 1)];
//         if (arguments.length > 1 && arguments[1] === true) {
//             str += ' ' + d[timePor.substr(0, 1)] + timeRazd + d[timePor.substr(1, 1)] + timeRazd + '00';
//         }
//     }
//     return str;
// }

// function curDate(){
//     var str = convertDate(new Date());
//     return str;
// }

function stringToNumeric(str){
    str += '';
    var n = parseFloat(str.replace(/[^\d,\.-]/g, '').replace(/,/g, '.')) + '';
    n = n.replace('NaN', '0');
    n = parseFloat(n);
    //if (b)
    //  n = parseInt(n);
    return n;
}

function changeDate(str, d, m, y){
    var t = changeDateAsDate(str, d, m, y);
    str = utils.convertDate(t);
    return str;
}

// function diffDate(d1, d2, r){
//     var diff = false;
//     var re = /^([1-9]|0[1-9]|[12][0-9]|3[01])[\.]?([1-9]|0[1-9]|1[012])[\.]?[1-9]{1}[0-9]{3}$/i;
//     if (re.test(d1))
//         if (re.test(d2)) {
//             if ((r == 'week') || (r == 'day')) {
//                 var date1 = changeDateAsDate(d1, 0, 0, 0);
//                 var date2 = changeDateAsDate(d2, 0, 0, 0);
//                 diff = date2 - date1;
//                 diff = diff / (3600000 * 24);
//                 if (r == 'week')
//                     diff = diff / 7;
//             } else {
//                 d1 = d1.split('.');
//                 d2 = d2.split('.');
//                 var d3 = new Array();
//                 for (var i = 0; i < 3; i++) {
//                     d3[i] = Math.abs(d2[i] - d1[i]);
//                     d1[i] = d2[i] - d1[i];
//                 }
//                 diff = d1[2] * 12 + d1[1];
//                 if (d1[0] < 0) {
//                     if (diff > 0)
//                         diff--;
//                 } else {
//                     if (diff < 0)
//                         diff++;
//                 }
//                 if (r == 'year')
//                     diff = diff / 12;
//             }
//         }
//     return diff;
// }

function validateRX(rx,doalert,form){
	if (rx==null || rx == "") return true;
	try {
		var xp = new RegExp(rx);
	} catch (e){
		if (e && e.message) {
			if (!!doalert)
				alert(e.message); 
			else 
				console.log(e.message);
			return false;
		} else {
			var def = form && form.getResourceBundle ? form.getResourceBundle("alert.regExp.incorrect") : getResourceBundle("alert.regExp.incorrect");
			if (!!doalert)
				alert(def); 
			else 
				console.log(def);//TODO
			return false;
		}
	}
	return true;
}

function checkCode200Error(data, form){
    if (data.ReturnCode && data.ReturnCode !== '0' && data.ReturnMsg) {
        form.inputParams.lastErrorCode = data.ReturnCode;
        form.inputParams.lastErrorMessage = data.ReturnMsg;
        form.showServiceErrors();
        return true; // Флаг ошибки
    }
}

function checkCode500Error(data, form){
    if (data.status && data.message) {
        form.inputParams.lastErrorCode = data.status;
        form.inputParams.lastErrorMessage = data.message;
        form.showServiceErrors();
        return true; // Флаг ошибки
    }
}

/*
 * РЕАЛИЗАЦИЯ ПОДХОДИТ ТОЛЬКО ДЛЯ ИСПОЛЬЗОВАНИЯ В PAGEFLOW
 */
function prepareNodesServer(nodeList, scheme, nodeIcon, leafIcon){
    
    /*
     * Схема маппировки узлов
     */
    if (!scheme) {
        scheme = new java.util.HashMap();
        scheme.put("ID", "id");
        scheme.put("Name", "name");
        scheme.put("Description", "description");
        
    }
    
    /*
     * Обязательный элемент
     */
    scheme.put("Children", "children");
    
    var newNodeList = new java.util.ArrayList();

    for (var i = 0, N = nodeList.size(); i < N; i++) {
        var node = nodeList.get(i);
        var newNode = new java.util.HashMap();
        
        var it = node.entrySet().iterator();
        while (it.hasNext()) {
            var entry = it.next();
            if (scheme.containsKey(entry.getKey())) {
                newNode.put(scheme.get(entry.getKey()), entry.getValue());
            }
        }
        
        if (newNode.containsKey("children") && newNode.get("children") && newNode.get("children").size()) {
            if (nodeIcon) {
                newNode.put("iconData", nodeIcon); // Добавим иконку узла 
            }
            newNode.put("children", prepareNodesServer(newNode.get("children"), scheme, nodeIcon, leafIcon)); // Рекурсия для дочерних
        } else {
            if (leafIcon) {
                newNode.put("iconData", leafIcon); // Добавим иконку листа 
            }
        }
        newNodeList.add(newNode);
    }
    return newNodeList;
}

function prepareNodes(nodeList, scheme, nodeIcon, leafIcon){
    
    /*
     * Схема маппировки узлов
     */
    if (!scheme) {
        scheme = {
            ID: 'id',
            Name: 'name',
            Description: 'description'
        };
    }
    
    /*
     * Обязательный элемент
     */
    scheme.Children = 'children';
    
    var newNodeList = [];
    
    for (var i=0,N=nodeList.length; i<N; i++) {
        var node = nodeList[i];
        var newNode = {};
        
        for (var key in node) {
            if (node.hasOwnProperty(key) && scheme.hasOwnProperty(key)) {
                newNode[scheme[key]] = node[key];
            }
        }
        
        if (newNode.hasOwnProperty('children') && newNode.children && newNode.children.length) {
            if (nodeIcon) {
                newNode.iconData = nodeIcon; // Добавим иконку узла 
            }
            newNode.children = service.prepareNodes(newNode.children, scheme, nodeIcon, leafIcon); // Рекурсия для дочерних
        } else {
            if (leafIcon) {
                newNode.iconData = leafIcon; // Добавим иконку листа 
            }
        }
        newNodeList.push(newNode);
    }
    return newNodeList;
}

function FilterParams (obj, clearOnConstruct){
    if (obj && angular.isObject(obj)) {
        for (var key in obj) {
            if (obj.hasOwnProperty(key)) {
                if (!clearOnConstruct || (clearOnConstruct && notEmpty(obj[key]))) {
                    this[key] = obj[key];
                }
            }
        }
    }
}
FilterParams.prototype.putParam = function (key, value){
    if (isEmpty(value)) {
        if (this.hasOwnProperty(key)) {
            delete this[key];
        }
    } else {
        this[key] = value;
    }
};

function translate (str){
	var enDict = ["alexander", "alexey", "anastasia", "anatoly", "andrey", "anna", "antonina", "anton", "afanasy", "boris", "valery", "valentin", "varvara", "vjatcheslav", "victor", "vitaly", "vladimir", "vera", "gennady", "georgy", "gleb", "grigory", "daria", "dmitry", "denis", "evgeny", "efim", "ekaterina", "elizaveta", "elena", "zakhar", "zinaida", "zinovy", "zoya", "ivan", "ignat", "ilya", "irina", "igor", "kirill", "konstantin", "kouzma", "ksenia", "lev", "lidia", "liubov", "liudmila", "larisa", "makar", "maxim", "maria", "margarita", "mikhail", "nadezda", "natalia", "nikita", "nikolay", "olga", "oleg", "oxana", "pavel", "petr", "rodion", "roman", "raisa", "sergey", "semen", "stepan", "tatiana", "timofey", "fedor", "philipp", "foma", "khristina", "julia", "yuri", "iakov", "ay", "ey", "iy", "oy", "uy", "yy", "ey", "yuy", "yay", "a", "b", "v", "g", "d", "e", "ye", "zh", "z", "i", "y", "k", "l", "m", "n", "o", "p", "r", "s", "t", "u", "f", "kh", "ts", "ch", "sh", "shch", "`", "y", "'", "e", "yu", "ya"];
	var ruDict = ["александр", "алексей", "анастасия", "анатолий", "андрей", "анна", "антонина", "антон", "афанасий", "борис", "валерий", "валентин", "варвара", "вячеслав", "виктор", "виталий", "владимир", "вера", "геннадий", "георгий", "глеб", "григорий", "дарья", "дмитрий", "денис", "евгений", "ефим", "екатерина", "елизавета", "елена", "захар", "зинаида", "зиновий", "зоя", "иван", "игнат", "илья", "ирина", "игорь$", "кирилл", "константин", "кузьма", "ксения", "лев", "лидия", "любовь", "людмила", "лариса", "макар", "максим", "мария", "маргарита", "михаил", "надежда", "наталья", "никита", "николай", "ольга", "олег", "оксана", "павел", "петр", "родион", "роман", "раиса", "сергей", "семен", "степан", "татьяна", "тимофей", "федор", "филипп", "фома", "христина", "юлия", "юрий", "яков", "ай", "ей", "ий", "ой", "уй", "ый", "эй", "юй", "яй", "а", "б", "в", "г", "д", "е", "ё", "ж", "з", "и", "й", "к", "л", "м", "н", "о", "п", "р", "с", "т", "у", "ф", "х", "ц", "ч", "ш", "щ", "ъ", "ы", "ь", "э", "ю", "я"];
    str = str.toLowerCase();
    ruDict.forEach(
        function (value, index){
            var re = new RegExp(value, "ig");
            str = str.replace(re, enDict[index]);
        }
    );
    return str.toUpperCase();
}

/*
 * Проверки на пустоту
 */
var emptyValues = [null, undefined, ''];

function isEmpty(value){
    return emptyValues.indexOf(value) !== -1;
}

function notEmpty(value){
    return emptyValues.indexOf(value) === -1;
}

function ifEmpty(value, elseVal){
    return emptyValues.indexOf(value) !== -1 ? elseVal : value;
}

function ifNotEmpty(value, elseVal){
    return emptyValues.indexOf(value) === -1 ? elseVal : value;
}


function businessError(){
    var target = false; 
    if (InputParams.get("Status").getParamData() === "OK" 
        && (InputParams.get("lastErrorStack").getParamData() === null || InputParams.get("lastErrorStack").getParamData() === "")){
       OutputParams.get("Status").setParamData(null);    
       OutputParams.get("lastErrorStack").setParamData(null);   
       OutputParams.get("lastErrorCode").setParamData(null);   
       OutputParams.get("lastErrorMessage").setParamData(null);
       target = true;
    } 
    else if (InputParams.get("lastErrorStack").getParamData() !== null 
            && InputParams.get("lastErrorStack").getParamData() !== ""){
       var errorInfo = InputParams.get("lastErrorStack").getParamData().get("Result");
       OutputParams.get("lastErrorCode").setParamData(errorInfo.get(0).get('MSGCODE'));   
       OutputParams.get("lastErrorMessage").setParamData(errorInfo.get(0).get('LONGMSG'));
       target = true;
    }   
    OutputParams.get("lastErrorStack").setParamData(null);
    return target;
}