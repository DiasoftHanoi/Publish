/*DSMETA version = "5.08.01-HF008-23092103" hash = "ce8b44ab2f20044a0cb37b5eb9d5a82792d7f612"*/
/* global form */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var convertDate = service.convertDate;
var getTableContent = service.getTableContent;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.isFormEditMode = form.inputParams.EDITMODE || false;

var inputParams = form.inputParams;
var outputParams = form.outputParams;

form.formParams = inputParams.formParams || {};
outputParams.formParams = form.formParams;

form.settings = {
    edTypeCollateral_items : [
        {value : "main", text: "${Main}"},
        {value : "supplementary", text: "${Supplementary}"}
    ],
    cmbTypePropertyComboBoxParams: {
        ReferenceSysName: 'typePropertyLOS',
        ORDERBY: 'ReferenceItemID'
    },
    requiredElements : [
        "rgTypeCollateral",
        "cmbTypeProperty",
        "edBrandCar",
        "edChassisNo",
        "edEngineNo",
        "adbAddressCollateral",
        "edDocumentsUsageRight",
        "edPendingDocumentsUsageRight",
        //These are not required, but need to be verified:
        "edApartmentDetailInformation",
        "edInformationAboutSales",
        "edOwnerNameVehicleRegistration",
        "edVehicleRegistrationOffice",
        "edLandNo",
        "edMapNo",
        "edArea",
        "edUnit",
        "edUsagePurpose",
        "edUsageForm",
        "edUsageTerm",
        "edUsageSource",
		"edRegistrationNo",
        "edRegistrationDate",
        "edAttachedLandInfo"
    ]
};

form.realEstateTemplateData={
    address:form.formParams.address || {},
    addressText:form.formParams.addressString || "",    
};

form.templateData={
    address:form.formParams.addressIssuedOfficeVehicleRegistration || {},
    addressText: form.formParams.addressIssuedOfficeVehicleRegistrationString || "",
    addressEnabled: (!form.isApprovalState+"").toLowerCase()
};

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
    form.checkVehicleFlag();
    form.templateData.addressEnabled = (!form.isApprovalState+"").toLowerCase();
    if (form.adbVehicleRegistrationOfficeAddress){
        form.adbVehicleRegistrationOfficeAddress.refresh();
    }
    //form.cmbTypeProperty.setText(form.formParams.typeAssets);
};

var sendMessage = function (message) {
    var PROCESS_RIGHT_LIST = getInputParams("PROCESS_RIGHT_LIST");
    if (PROCESS_RIGHT_LIST) {
        for (var ar in PROCESS_RIGHT_LIST) {
            form.commandRight(ar, message);
        }
    }
};

form.executeCommand = function (message) {
    if (message.event == "FAB_NAVIGATOR_NAVIGATE") {
        form.outputParams.NEXTPAGE = message.params.step;
        form.action("DIRECT");
    }
};

form.curDate = service.convertDate(new Date());

form.yesFunc = function() {
    form.outputParams.TRANSTYPE = 'SAVEDRAFT';
    if (form.verifyForm()) {
        form.sendForm('GO', false);
    }
};

form.checkVehicleFlag = function(){
    form.vehicleFlagReq = form.formParams.sysnameTypeAssets == "vehicle" && (form.formParams.newObject || form.formParams.cbNewObject == "true" ) && form.formParams.sysnameTypeCollateral=="main";
    form.isApprovalState = inputParams.STATE == "Approval Result Notification";
}

form.action = function (tag) {
    if (form.isFormEditMode) {
    outputParams.TRANSTYPE = tag;
    form.formParams.typeAssets     = form.cmbTypeProperty.getText();
    form.formParams.typeCollateral = gRB(form.formParams.sysnameTypeCollateral);
    form.formParams.address        = form.edAddressBlock ? form.edAddressBlock.data.address : {};
    form.formParams.addressString  = form.edAddressBlock ? form.edAddressBlock.data.address.addressText: "";
    form.formParams.addressIssuedOfficeVehicleRegistration       = form.adbVehicleRegistrationOfficeAddress ? form.adbVehicleRegistrationOfficeAddress.data.address : {};
    form.formParams.addressIssuedOfficeVehicleRegistrationString = form.adbVehicleRegistrationOfficeAddress ? form.adbVehicleRegistrationOfficeAddress.data.address.addressText: "";
    }
    if (tag === 'CLOSE' && form.isFormEditMode) {
        service.showDialogCancelConfirm(
            form,
            form.yesFunc
        )
    }
    else {
        if ((tag === 'NEXT' || tag === "DIRECT" || tag === 'PREV') && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;
    var buttonNextSave = (form.isLastWizForm) ? "btnSave" : "btnNext";
    var isMainCollateralFlag = "" + form.formParams.isMainCollateralFlag;
    if (isMainCollateralFlag == "true") {
        if ((form.formParams.COLLATERALMODE == "EDIT" && form.formParams.sysnameTypeCollateralCurrent != "main" && form.formParams.sysnameTypeCollateral == "main")
            || (form.formParams.COLLATERALMODE == "ADD" && form.formParams.sysnameTypeCollateral == "main")) {
            form.showInformationDialog(gRB("dialog.addMainCollateralAlreadyExist"), function () {
            }, [{
                caption: gRB('dialog.ok')
            }]);
            return false;
        }
    }
    try {
        if ((form.validateControlsByIds(form.settings.requiredElements.join(','), showFlag === true ? buttonNextSave : undefined).isShowFormErrors)) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};