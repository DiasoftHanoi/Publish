/*DSMETA version = "5.08.01-HF008-23092103" hash = "ccbaa1cb37c0c4e3e87bfdc89dcf58fc2666dd6a"*/
form.direct = function (item) {
    var commandMessage = {
        event: 'WIZARD_DIRECT',
        WIZFORMID: item.WIZFORMID
    };
    form.command(commandMessage);
};

form.formParams = {};
form.formParams.formWizardItems = [];

form.executeCommand = function (message) {
    service.lgr("wiz navigator executeCommand");
    service.lgr(message);
    var params = message.params || {};
    var step = params.step || {};

    var formList = [];
    var forms = [];

    if (message.event === 'FAB_NAVIGATOR_UPDATE'){
        formList = step.formList || [];
        forms = step.forms || [];
    } else {
        formList = message.formList || [];
        forms = message.forms || [];
    }

    var formListLength = formList.length;
    var formsLength = forms.length;

    for (var i=0; i < formListLength; i++){
        for (var j = 0; j < formsLength; j++){
            if (formList[i]["WIZFORMID"] == forms[j]["FORM"]){
                formList[i]["isChecked"] = ((forms[j]["VERIFIED"] + "") == "true");
            }
        }
    }

    switch (message.event){
        case 'FAB_NAVIGATOR_UPDATE':
            if (form.formParams.formNavigatorValue != message.params.step.curpage) {
                form.formParams.formWizardItems = [];
                for (var i = 0; i < formListLength; i++){
                    form.formParams.formWizardItems.push(formList[i]);
                }
                form.formParams.formNavigatorValue = Number(message.params.step.curpage);
            }
            break;
        case 'CURPAGE_MSG' :
            if (form.formParams.formNavigatorValue != message.curpage) {
                form.formParams.formWizardItems = [];
                for (var i = 0; i < formListLength; i++){
                    form.formParams.formWizardItems.push(formList[i]);
                }
                form.formParams.formNavigatorValue = Number(message.curpage);
            }
            break;

        default :
            break;
    }
};