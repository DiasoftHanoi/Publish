/*DSMETA version = "6.01.01" hash = "6a97539b8596025d5d3a344d2dabde2cf0c0c17f"*/
﻿/* состав мап в wizard params*/

var wizardParamsRef = {
    appMap:[
        "DOCTYPENAME",
        "STATE",
        "CREATIONDATE",
        "DOCUMENTNUMBER",
        "DOCUMENTID",
        "TYPESYSNAME",
        "bankProductName",
        "bankProductId",
        "bankProductBrief",
        "bankProductGroupId",
        "bankProductGroupName",
        "clientPropertyRegion",
        "clientPropertyRegionText",
        "clientDocumentFeeder",
        "clientSalesChannel",
        "clientSalesChannelSecond",
        "clientSalesPoint",
        "clientTypesCreditObligations",
        "clientRefinancedLoan",
        "clientOccurrenceDate",
        "loanAmount",
        "loanCurrency",
        "loanTerm",
        "withdrawalTerm",
        "interestRate",
        "nonStandartLTV",
        "disbursmentMethodSysName",
        "disbursmentMethod",
        "disbursmentMethodOther",
        "commission",
        "paymentDate",
        "subsidyAmount",
        "clientCategory",
        "refinancedLoanType",
        "refinancedLoanAmount",
        "refinancedLoanCurrency",
        "clientIncomeList",
        "clientTotalIncome",
        "clientExpensesList",
        "clientFlagAgreeCheckBKI",
        "clientFlagAgreeCheckPersonalInfo",
        "clientFlagAgreeInfoNetworkOperator",
        "clientSocialStatus",
        "clientCategoryCode",
        "bankProductGroupName",
        "clientDocumentFeeder",
        "clientSalesChannelComment",
        "AtypicalConditionList",
        "AddConditionList",
        "SuspensiveConditionList",
        "checkResultCostCalculator",
        "AssessmentNeed",
        "AssessmentDate",
        "AssessmentTime",
        "EstimatedCompanyType",
        "EstimatedConclusion",
        "EstimatedComment",
        "CompanyName",
        "EstimatedCompanyTypeValue",
        "EstimatedCompanyNotInList",
        "EstimatedCost",
        "EstimatedCompanyInn",
        "EstimatedCompanyLegalID",
        "EstimatedCompanyFlagJobNotRef",
        "CompanyNameInn",
        "creditCurrencyName",
        "creditCurrencySysName",
        "loanPurposeSysName",
        "loanPurpose",
        "loanPurposeDetail",
        "principalRepaymentMethodSysName",
        "principalRepaymentMethod",
        "interestRepaymentMethodSysName",
        "interestRepaymentMethod",
        "subproductList",
        "feeList",

        "CODE",
        "divisionRiskValuationSysName",
        "divisionRiskValuation",
        "divisionCustomerGroup",
        "divisionCustomerType",

        "approvedWithConditions",
        "REFSYSNAME",
        "DETAILS",
        "controlMethod",
        "controlMethodSysName",
        "approverLevelUnderwriter",
        "approverLevelUnderwriterSysName",
        "userApproverID",
        "CURRENTUSERID",
        "acptSubstandartFlag",
        "controlMethod",
        "ApproverFullName",
        "ApproverIdFromSrv",
        "StatusSrv",
        "userGroupList",
        "memberList",
        "decisionItems",
        "participantList",
        "creditCommitteeMeetingMethodSysName",
        "creditCommitteeMeetingMethod",
        "creditCommitteeGroupSysName",
        "creditCommitteeGroup",
        "startDateCreditCommittee",
        "startTimeCreditCommittee",
        "endDateCreditCommittee",
        "endTimeCreditCommittee",
        "RefuseReasonCode",
        "RefuseReason",
        "ChooseUserSysName",
        "ChooseUser",
        "nonStandartConditionsList", //НУ, ИСУ1, ИСУ2
        "ClientSDRResultsMap", //Результат проверки СПЗ
        "approvedProductName",
        "approvedProductId",
        "approvedProductBrief",
        "approvedLoanPurposeSysName",
        "approvedLoanPurpose",
        "approvedLoanPurposeOther",
        "approvedLoanAmount",
        "approvedCurrencySysName",
        "approvedCurrencyName",
        "approvedLoanTerm",
        "approvedInterestRate",
        "approvedCardNumber",
        "additionalContactsList",
        "markers",
		"secondSupplementatyCard",
		"foApproverPersonRole",
		"creditLimitApproved"
    ],
    clientMap:[
        "CLIENTID",
        "clientLastName",
        "clientLastName",
        "clientFirstName",
        "clientMiddleName",
        "clientGender",
        "clientBirthDate",
        "clientAge",
        "clientBirthPlace",
        "clientCitizenshipCode",
        "clientCitizenship",
        "clientCitizenshipName",
        "isSalaryClient",
        "clientIsResident",
        "clientIsTaxResident",
        "clientMainDocSeries",
        "clientSocialStatus",
        "clientMainDocNumber",
        "clientMainDocIssuerCode",
        "clientMainDocIssueDate",
        "clientMainDocIssuedBy",
        "clientAdditionalDocsTable",
        "contactTableList",
        "addressTableList",
        "clientJobName",
        "clientJobInn",
        "clientWorkPosition",
        "clientFlagJobNotRef",
        "clientEmployerID",
        "clientPositionID",
        "clientCorporateCategory",
        "clientVTBGroupCategory"
    ],
    excludeMap:[
        "DOCTYPENAME",
        "STATE",
        "CREATIONDATE",
        "DOCUMENTNUMBER",
        "DOCUMENTID"
    ]
};

function transformerWizardParam(wizardParams){
    if (arguments.length > 1){
        for(var i = 1; i < arguments.length; i++) {
            var nextMapName = arguments[i];
            var mapKeys = wizardParamsRef[nextMapName];
            logger.info("#### "+getNewList(mapKeys));
            var clearMap = new java.util.HashMap();
            // если мапа уже есть, добавлять в нее.
            if (wizardParams.get(nextMapName) != undefined && wizardParams.get(nextMapName) != null){
                clearMap = wizardParams.get(nextMapName);
            }
            // перекладываем из визарда в нужную мапу
            for (var j = 0; j < mapKeys.length; j++) {
                if (wizardParams.get(mapKeys[j]) != undefined && wizardParams.get(mapKeys[j]) != null) {
                    clearMap.put(mapKeys[j], wizardParams.get(mapKeys[j]));
                    wizardParams.put(nextMapName, clearMap);
                }
                if (wizardParamsRef['excludeMap'].indexOf(mapKeys[j]) == -1){
                    wizardParams.remove(mapKeys[j]);
                }
            }
        }
        return wizardParams;
    }
    else {
        if(arguments.length == 1){
            return wizardParams;
        }
    }
}

// берет значение из мапы если такое значится в списках мапы
// иначе берет значение из wizardParam
// например getWizardParamValue(wizardParams, "clientLastName", "clientMap") будет искать в clientMap внутри визарда
// или getWizardParamValue(wizardParams, "applicationSaleChannel", "appMap", "clientMap") будет искать в appMap и clientMap

function getWizardParamValue(wizardParams, valueName){
    if (arguments.length > 2){
        var mapName = "";
        for(var i = 2; i < arguments.length; i++) {
            var nextMapName = arguments[i];
            var mapKeys = wizardParamsRef[nextMapName];
            if(mapKeys!=null) {
                for (var j = 0; j < mapKeys.length; j++) {
                    if (mapKeys[j] == valueName) {
                        mapName = nextMapName;
                        break;
                    }
                }
            }
        }
        if (mapName!="" && wizardParams.get(mapName) != null){
            return wizardParams.get(mapName).get(valueName);
        }
        else {
            return wizardParams.get(valueName);
        }
    }
    else if(arguments.length == 2){
        return wizardParams.get(valueName);
    }
    else{
        return null;
    }
}

// Вычищаем wizardParams от атрибутов, которые есть в мапе с переданным именем, например, appMap
function cleanupWizardParam(wizardParams){
    if (arguments.length > 1){
        for(var i = 1; i < arguments.length; i++) {
            var nextMapName = arguments[i];
            if (wizardParams.get(nextMapName) != undefined && wizardParams.get(nextMapName) != null) {
                var nextMap = wizardParams.get(nextMapName);
                var mapKeys = nextMap.keySet();
                var iter    = mapKeys.iterator();
                while (iter.hasNext()) {
                    var itemKey = iter.next();
                    if (wizardParamsRef['excludeMap'].indexOf(itemKey+'') == -1) {
                        wizardParams.remove(itemKey+'');
                    }
                }
            }
        }
        return wizardParams;
    }
    else {
        if(arguments.length == 1){
            return wizardParams;
        }
    }
}
