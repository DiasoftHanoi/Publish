form.formParams = form.inputParams.formParams
form.getAge = service.getAge;

console.log("add panel client Info");
console.log(form.inputParams);

form.formParams.DOCTYPESYSNAME = form.formParams.DOCTYPESYSNAME || '';
var docTypeSysname = form.formParams.DOCTYPESYSNAME.toLowerCase();
form.clientDataFlag = (docTypeSysname.search('mortgage') > -1) || ( form.formParams.DOCTYPESYSNAME == 'loanAppCodebtor') || ( form.formParams.DOCTYPESYSNAME == 'loanAppGuarantee')  ;


form.getProductTermTypeText = function (term, type){
    if (type == 'День'){
        return pluralForm(term, 'день', 'дня', 'дней');
    } else
    if (type == 'Месяц'){
        return pluralForm(term, 'месяц', 'месяца', 'месяцев');
    }
    return '';

    function pluralForm(n, form1, form2, form5){
        var n = Math.abs(n) % 100;
        var n1 = n % 10;
        if (n > 10 && n < 20){
            return form5;
        }
        if (n1 > 1 && n1 < 5){
            return form2;
        }
        if (n1 == 1){
            return form1;
        }
        return form5;
    }
}


