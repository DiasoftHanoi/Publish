/*DSMETA version = "5.11.01-24042402" hash = "11040b57853a2116cc4cfb940fc2979f6540f0d6"*/
function registerMethod(initService){
    var service={};
    for (var ar in initService){
        if (initService.hasOwnProperty(ar)){
            if (ar.indexOf('Service')>-1 || typeof (initService[ar]) != 'function'){
                service[ar]=initService[ar];
            }else{
                var fn=initService[ar].toString();
                if (fn && fn.length) {
                    var sIdx=fn.search(/\(/)+1;
                    var eIdx=fn.search(/\)\{/);
                    var args=fn.substring(sIdx,eIdx);
                    eval("service."+ar+"=function("+args+")"+fn.substring(eIdx+1,fn.length));
                }
            }
        }
    }
    return service;
}
service=registerMethod(service);

var lgr=service.lgr;
var nvl=service.nvl;
var getInputParams=service.getInputParams;

var inputParams = form.inputParams || {};
form.searchParams = inputParams.searchParams || {};

var outputParams = form.outputParams || {};
outputParams.searchParams = form.searchParams || {};

var linkedAppParams = form.inputParams.linkedAppParams || {};
form.hasLinkName = (linkedAppParams.LINKNAME != undefined && linkedAppParams.LINKNAME != "" && linkedAppParams.LINKNAME != null) ? true : false; 
var doctypesysnames = form.inputParams.doctypesysnames || [];
var flagList = form.inputParams.flagList || [];

form.isHideCreateButton = inputParams.isHideCreateButton != null ?  true : false;

form.documentObj = (function (grId){
    var gridId = grId;
    var dateStart = undefined;
    var dateEnd = undefined;
    var branchID = null;
    var participantType = form.inputParams.PARTICIPANTID ? 1: undefined;

    if(form.inputParams.searchAppListFlag == true) {
        dateStart = utils.curDateJS();
        dateEnd = utils.curDateJS();
        dateStart.setDate(dateEnd.getDate()-7);
        dateEnd.setDate(dateEnd.getDate()+1);

    }

    if(form.inputParams.searchAppListFlag == true) {
        if(form.inputParams.USERDEPT != "Head office") {
           branchID = form.inputParams.USERDEPTID;
        }
    }
    if(form.inputParams.searchParams!=undefined) {
       if(form.inputParams.searchParams["IdentityCardTypeBrief"]!=undefined){
           participantType = undefined;
       }
    }

    var obj = {
        gridId: grId,

        cols : [
            {
                value: 'DOCUMENTNUMBER',
                type: 'text',
                caption: "${NumberCaption}",
                width: 15
            },
            {
            	value: 'STRING4',
                type: 'text',
                caption: "${CustomerNameCaption}",
                width: 10
            },
            {
            	value: 'STATE',
                type: 'text',
                caption: "${StatusCaption}",
                width: 10
            },
            {
            	value: 'CREATIONDATE',
                type: 'date',
                caption: "${CreationDateCaption}",
                width: 10
            },
            {
            	value: 'DOCTYPENAME',
                type: 'text',
                caption: "${ProductLineCaption}",
                width: 10
            },
            {
            	value: 'STRING1',
                type: 'text',
                caption: "${ProductNameCaption}",
                width: 15
            },
            {
            	value: 'FIOBankEmployee',
                type: 'text',
                caption: "${CreatedByCaption}",
                width: 15,
                sortable: false
            },
            {
            	value: 'STRING3',
                type: 'text',
                caption: "${BranchNameCaption}",
                width: 15
            }
        ],
        options : {flagList: form.inputParams.flagList,
            setFlagColorValue:function(flagSysname, flagValueBool, mode) {
                var additMarkList = form.inputParams.additMarkList || [];
                var modeResult = "";
                for (var i = 0, countI = additMarkList.length; i < countI; i++) {
                    var additMarkMap = additMarkList[i];
                    if (String(additMarkMap["ReferenceItemCode"]) == String(flagSysname)) {
                        if (flagValueBool != undefined && String(additMarkMap["ReferenceItemName"]) == String(flagValueBool)) {
                            modeResult = String(additMarkMap[(mode == 'value') ? "ReferenceItemBrief" : "ReferenceItemComment"]);
                            break;
                        }
                    }
                }
                return modeResult;
            }
        },
        remoteMethod : {
            filterParams : {
                    PARTICIPANTID: form.inputParams.PARTICIPANTID,
                    DOCTYPESYSNAMES: doctypesysnames,
                    CREATIONMINDATE: dateStart,
                    CREATIONMAXDATE: dateEnd,
                    STATETYPE_NOT_EQUAL: 2,
                    BRANCHIDS: branchID,
                    PARTICIPANTTYPE: participantType,
                    PERSONDOCTYPE: form.inputParams.searchParams == undefined ? "NationalID" : (form.inputParams.searchParams["IdentityCardTypeBrief"] !=undefined ? form.inputParams.searchParams["IdentityCardTypeBrief"] : undefined),
                    RETURN_EXTATTRIBUTES: true,
                    needAttributesList: [
                        "DOCTYPENAME",
                        "FIOBankEmployee",
                        "creditLimitApproved",
                        "secondSupplementatyCard"
                    ]
            }
        },
        refresh : function (){
            form[gridId].refresh();
        },
		onChangeItems: function () {
        }
    };

    for (var i = 0; i < flagList.length; i++) {
        var flagSysname = nvl(flagList[i]['SYSNAME'], '');
        if (flagSysname != '') {
            obj.remoteMethod.filterParams.needAttributesList.push(flagSysname);
        }
    }

    return obj;
})("documentList");

form.onShow = function () {
    form.setTabCaption(form.getResourceBundle("applicationList"));
};

form.applicationObj = {
    items: (function() {
        var ItemMenuList = form.inputParams.ItemMenuList || [];
            for(var i=0; i<ItemMenuList.length; i++) {
                ItemMenuList[i]["caption"]= ItemMenuList[i]["ITEMNAME"];
                var SYSNAME = ItemMenuList[i]["SYSNAME"];
                var func = function(Index) {
                    outputParams.SYSNAME = Index['item']['SYSNAME'];
                    form.outputParams.ACTION = "NEXT";
                    form.outputParams.curPage = "MINIAPP";
                    form.sendForm("NEXT", false);
                };
                ItemMenuList[i]["click"] =  func;
            }
        return ItemMenuList;
    }()),
    isShowHideCreateButton : (function() {
        var searchAppListFlag = form.inputParams.searchAppListFlag || false,
            isSalesPerson = form.inputParams.isSalesPerson || false,
            isRelationshipManager = form.inputParams.isRelationshipManager || false;
        if ((searchAppListFlag && isRelationshipManager) || (!searchAppListFlag && (isRelationshipManager || isSalesPerson))) {
            return true;
        }
        return false;
    }())
};

form.executeCommand = function(message) {

    switch(message.event){
        case 'SEARCH':
            var DOCTYPESYSNAMES = (!message.params.ApplicationType) ? doctypesysnames : undefined;
            var STATES = (message.params.STATES) ? message.params.STATES : undefined;
            form.documentObj.remoteMethod.filterParams = {
                PARTICIPANTID: form.inputParams.PARTICIPANTID,
                STRING4: message.params.CurrentName,
                PERSONDOCTYPE: message.params.PERSONDOCTYPE,
                PERSONDOCNUMBER: message.params.PERSONDOCNUMBER,
                DOCUMENTTYPE: message.params.ApplicationType,
                DOCTYPESYSNAMES: DOCTYPESYSNAMES,
                DOCUMENTNUMBER: message.params.Number,
                STATE: message.params.STATE,
                STATES: STATES,
                CREATIONMINDATE: message.params.CREATIONMINDATE,
                CREATIONMAXDATE: message.params.CREATIONMAXDATE,
                BRANCHIDS: message.params.BRANCHID,
                CREATEDBY: message.params.CreatedBy,
                DOCATTRIBUTE1: "/root/clientExtObj",
                DAVALUE1: message.params.clientExtObjID,
                STATETYPE_NOT_EQUAL: message.params.STATETYPE_NOT_EQUAL,
                RETURN_EXTATTRIBUTES: true,
                needAttributesList: [
                    "DOCTYPENAME",
                    "FIOBankEmployee",
                    "creditLimitApproved",
                    "secondSupplementatyCard",
                    "clientExtObj"
                ]
            };

        for (var i = 0; i < flagList.length; i++) {
            var flagSysname = nvl(flagList[i]['SYSNAME'], '');
            if (flagSysname != '') {
                form.documentObj.remoteMethod.filterParams.needAttributesList.push(flagSysname);
            }
        }

        if (!form.documentObj.remoteMethod.filterParams.PERSONDOCTYPE && !form.documentObj.remoteMethod.filterParams.PERSONDOCNUMBER) {
            delete form.documentObj.remoteMethod.filterParams.PARTICIPANTTYPE;
        }else{
           form.documentObj.remoteMethod.filterParams.PARTICIPANTTYPE = 1;
        }

        form.documentList.refresh();
            break;
        case 'REFRESH_PRODUCT_LIST':
            form.documentList.refresh();
            break;
       default:
            break;
    }
};

form.action = function (tag) {
    form.outputParams.ACTION = tag;
    form.sendForm(tag, false);
};

form.onSelectApplication = function(item) {
    lgr('onSelectApplication', arguments);
    var params = {
        APPLICATIONID: item.DOCUMENTID,
        application: {
            executeSource: 'applicationList',
            escalationFlag: item.escalationFlag
        }
    };
    form.documentObj.options['ID' + item.DOCUMENTID + item.STATE] = undefined;
    form.startProcess(
        form.getCurrentProjectSysname() + '/COMMON/APPLICATION/getTransferList',
        params,
        function(p) {
            lgr('fillTransfers', p);
            var transfersList = nvl(p['transfersList'], {});
            var resActions = [];
            if (transfersList && transfersList.length && item.STATE != "Waiting") {
                for (var i = 0; i < transfersList.length; i++) {
                    resActions.push({
                        caption: transfersList[i]["NAME"],
                        click: function() {
                            form.onApplicationAction(this, item)
                        },
                        TRANSITIONID: transfersList[i]["TRANSITIONID"]
                    })
                }
            }
            form.documentObj.options['ID' + item.DOCUMENTID + item.STATE] = resActions;
        }
    );
};

form.onApplicationAction=function(data,item){
	form.documentList.setSelectedRow(undefined);
	form.documentObj.options['ID' + item.DOCUMENTID+item.STATE] = null;
	form.startNewPageFlowProcess(
	    data.caption+'. Application №'+item['DOCUMENTNUMBER'],
	    form.getCurrentProjectSysname()+'/'+'COMMON/STATEMACHINE/callPageflowByTransfer',
	    {
            APPLICATIONID:item.DOCUMENTID,
            MAINAPPLICATIONID:item.DOCUMENTID,
            TRANSITIONID:data.TRANSITIONID
        },
        true,
        undefined,
        function(){
            if(form.documentList){
                form['documentList'].refresh();
            }
        }
	)
};

form.onCreateLink = function () {
    form.outputParams.ACTION = "NEXT";
    form.outputParams.curPage = "";
    form.sendForm("NEXT", false);
};
