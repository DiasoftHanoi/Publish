/*DSMETA version = "5.11.01-24042402" hash = "0592ad58969a9bbe1fc51b1539237faba105a3f5"*/
form.outputParams = {};

form.formParams = form.inputParams;
form.outputParams = form.formParams;
var lgr = service.lgr;
form.lgr = lgr;

form.fillAttachmentsBySelectedApps = function(){
    lgr('fillAttachmentsBySelectedApps');
    var allAttachedDocList = form.formParams.allAttachedDocList || [];
    var selAppIds = form['tbLinkedApps'].getSelectedRows();
    var attachedDocList = [];

    for (var i= 0; i<allAttachedDocList.length; i++){
        if ( selAppIds.indexOf(allAttachedDocList[i]['OBJECTID']) != -1){
            attachedDocList.push(allAttachedDocList[i]);
        }
    }
    form['tbAttachedDocs'].setItems(attachedDocList);
}
form.changeItemsLinkedAppsExecFlag = false;
form.changeItemsLinkedApps = function (){
    if (form.changeItemsLinkedAppsExecFlag) {
        form['tbLinkedApps'].setSelectedRows(form['tbLinkedApps'].getSelectedRows());
    } else {
        var linkedAppsList = form.formParams.linkedAppsList || []
        var selAppIds = [];
        for (var i=0;i<linkedAppsList.length; i++){
            if (linkedAppsList[i]['COPYCASE'] === 'FULL'){
                selAppIds.push(linkedAppsList[i]['DOCUMENTID'])
            }
        }
        form['tbLinkedApps'].setSelectedRows(selAppIds);
        form.changeItemsLinkedAppsExecFlag = true;
    }
    form.fillAttachmentsBySelectedApps();
}

form.changeItemsAttachedDocs = function (){
    lgr('changeItemsAttachedDocs');
    var allAttachedDocList = form.formParams.allAttachedDocList || [];
    var tArray = [];
    for (var i=0;i<allAttachedDocList.length; i++){
        tArray.push(allAttachedDocList[i]['ATTACHMENTID'])
    }
    form['tbAttachedDocs'].setSelectedRows(tArray);
    form.changeItemsAttachedDocsExecFlag = true;
}

form.formSettings = {
    documentGetAllByPackageParams :  form.inputParams.linkAppsSearchParams,
    isLinkedApps : form.inputParams.isLinkedApps
};

form.tbAttachedDocsOptions = form.inputParams.allAttachedDocList;

form.executeCommand = function (message) {
    switch (message.event) {
        case 'GO_TO_PAGE':
            form.outputParams.TRANSTYPE = 'DIRECT';
            form.outputParams.NEXTPAGE = message.params.page;
            form.sendForm('GO',false);
            break;
        case 'WIZARD_DIRECT':
            form.outputParams.NEXTPAGE = message.WIZFORMID;
            form.sendForm('GO',false);
            break;
    }
};

form.action = function (tag) {
    form.formParams.attachedDocsList =  form.tbAttachedDocs.getItems();
    if (form.inputParams.isLinkedApps && form.tbLinkedApps){
        form.formParams.linkedAppsList = form.tbLinkedApps.getItems();
    }
    if (tag == 'NEXT' && !form.verifyForm()){
        form.showErrorDialog('Создание заявки по образцу невозможно. Выберите заемщика!', function(){}, [{caption:'ОК'}]);
    } else {
        form.sendForm(tag,false);
    }
};

form.changeCopyParams = function(){
    var selRow = form['tbLinkedApps'].getSelectedRow()[0];
    form.startModalPageFlowProcess(form.getCurrentProjectSysname()+'/FORMLIB/copyApplication/copyParams', {
        COPYCASE: selRow['COPYCASE']
    }).then(function (result) {
        lgr(result)
        selRow['COPYCASE'] = result['COPYCASE'];
        form['tbLinkedApps'].updateRow(form.formParams.linkedAppsSelectedId, selRow);
        form.fillAttachmentsBySelectedApps();
    });
}

form.tbLinkedAppsElements = {
    options: {
        menuItems: [
            {caption: 'Изменить параметры копирования', click: form.changeCopyParams}
        ],
        getCopyCaseText : function(copyCaseValue){
            switch (copyCaseValue){
                case 'LINK':
                    return 'Ссылка';
                case 'FULL':
                    return 'Полное копирование';
                default: return'';
            }
        }
    }
}

form.changeParticipantsRole = function (){
    form.startModalPageFlowProcess(form.getCurrentProjectSysname()+'/FORMLIB/copyApplication/changeParticipantsRole', {
        linkedAppsList: form.formParams.linkedAppsList || [],
        DOCTYPESYSNAME: form.formParams.DOCTYPESYSNAME,
    }).then(function (result) {
        lgr(result);
        if (result.formParams.ACTIONTYPE === 'SAVE'){
            form.formParams.linkedAppsList = angular.copy(result.formParams.linkedAppsList);
            var selRows = form['tbLinkedApps'].getSelectedRows();
            lgr(selRows);
            form['tbLinkedApps'].setItems(result.formParams.linkedAppsList);
            setTimeout(function(){
                form['tbLinkedApps'].setSelectedRows(selRows);
                form.fillAttachmentsBySelectedApps();
            }, 10);
        }
    });
}

form.verifyForm = function (){
    if(!form.inputParams.isLinkedApps)
        return true;
    if(form.tbLinkedApps) {
        var linkedApps = form['tbLinkedApps'].getItems();
        var selectedRows = form.tbLinkedApps.getSelectedRows()
    }

    var  debtorFlag = false;
    for (var i=0; i<selectedRows.length; i++){
        if (getAppById(selectedRows[i])['DOCTYPESYSNAME'] === form.inputParams.DOCTYPESYSNAME){
            debtorFlag = true;
            break;
        }
    }
    return debtorFlag;

    function getAppById(appId){
        var resultMap = {};
        for (var i=0; i<linkedApps.length; i++){
            if (linkedApps[i]['DOCUMENTID'] == appId){
                resultMap = angular.copy(linkedApps[i]);
                break;
            }
        }
        return resultMap;
    }

}

