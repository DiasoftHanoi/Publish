/*DSMETA version = "5.11.01-24042402" hash = "591d8bf9a33051b0238d6c5f56f9694f4b3df02e"*/
form.outputParams = {};
form.formParams = form.inputParams || {};
form.outputParams = form.formParams;

form.copyOptions =  [
    {value: 'copyMain', text: '${copyMain}'},
    {value: 'copyAll', text: '${copyAll}'}
];

form.action = function (tag) {
    form.outputParams.DOCTYPESYSNAME = form.inputParams.wizardParams.DOCTYPESYSNAME;
    form.sendForm("NEXT", false);
};