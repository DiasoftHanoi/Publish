/*DSMETA version = "5.11.01-24040404" hash = "7b1170147e927391fe87a4114f3049570f885022"*/
var inputParams = form.inputParams || {};
var outputParams = form.outputParams || {}


var lgr = service.lgr;
var gRB = function (key) {
    return service.nvl(form.localize[key], key);
};
form.gRB = gRB;

form.action = function (tagName) {
    form.outputParams.responsibleID=form.inputParams.responsibleID;
    form.sendForm(tagName);
};

form.onShow = function () {
    if(form.cbResponsible) form.cbResponsible.setValue(form.inputParams.responsibleID);
};
form.Responsible = {
    lkpParams: {
        ROLEID: form.inputParams.ROLEID,
        UserAccountStatus: 'ACTIVE'
    },
    lkpElement_fields: [
        {
            value: 'UserID',
            caption: 'ID',
            width: 2
        },
        {
            value: 'USERLOGIN',
            caption: 'Логин',
            width: 4
        },
        {
            value: 'EMPLOYEENAME',
            caption: 'ФИО',
            width: 6
        }
    ]
};

form.getUserEmail= function () {
    var id = inputParams.responsibleID;
    var CurrentUserID =inputParams.CurrentUserID; 
    var list = form.cbResponsible.items;
    for (var i = 0; i < list.length; i++) {
        var map = list[i];
        if (map.UserID == id) {
            form.outputParams.newResponsibleEMAIL = map.EMAIL;
        }
        if (map.UserID == CurrentUserID) {
            form.outputParams.currenResponsibleEMAIL = map.EMAIL;
        }        
    }
};

