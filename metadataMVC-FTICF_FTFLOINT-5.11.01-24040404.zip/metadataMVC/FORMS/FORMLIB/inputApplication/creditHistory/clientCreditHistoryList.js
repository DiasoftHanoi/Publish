/*DSMETA version = "5.11.01-24040404" hash = "03608c796ec77ecf43a7f58680201e0b2728daf3"*/
/* global form */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var convertDate = service.convertDate;
var getTableContent = service.getTableContent;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.isFormEditMode = form.inputParams.EDITMODE || false;

var inputParams = form.inputParams;
var outputParams = form.outputParams;

form.formParams = inputParams.formParams || {};
outputParams.formParams = form.formParams;

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
    form.tblLoanObj.setItems(form.inputParams.CreditHistoryLoans || []);
    form.tblOverdraftObj.setItems(form.inputParams.CreditHistoryOverdraft || []);
    form.tblCreditCardObj.setItems(form.inputParams.CreditHistoryCreditCard || []);

    if (!form.isFormEditMode) {
        if (form.btnNext) {
            form.btnNext.setFocus();
        }
        else if (form.btnSave) {
            form.btnSave.setFocus();
        }
        else {
            form.btnCancel.setFocus();
        }
    }
};

var sendMessage = function (message) {
    var PROCESS_RIGHT_LIST = getInputParams("PROCESS_RIGHT_LIST");
    if (PROCESS_RIGHT_LIST) {
        for (var ar in PROCESS_RIGHT_LIST) {
            form.commandRight(ar, message);
        }
    }
};

form.curDate = service.convertDate(new Date());

form.yesFunc = function() {
    form.outputParams.TRANSTYPE = 'SAVEDRAFT';
    form.sendForm('GO', false);
};

form.action = function (tag) {
    outputParams.TRANSTYPE = tag;
    form.outputParams.VERIFIED = true;
    outputParams.CreditHistoryLoans = form.tblLoanObj.getItems() || [];
    outputParams.CreditHistoryOverdraft = form.tblOverdraftObj.getItems() || [];
    outputParams.CreditHistoryCreditCard = form.tblCreditCardObj.getItems() || [];
    outputParams.loansNumberCreditHistory = outputParams.CreditHistoryLoans.length;
    outputParams.overdraftCardsNumberCreditHistory = outputParams.CreditHistoryOverdraft.length;
    outputParams.creditCardsNumberCreditHistory = outputParams.CreditHistoryCreditCard.length;

    if (tag === 'CLOSE') {
        if(form.inputParams.EDITMODE === false){
            form.sendForm('GO',false);
        }else {
            service.showDialogCancelConfirm(
                form,
                form.yesFunc
            )
        }
    }
    else {
        form.sendForm('GO', false);
    }
};

form.executeCommand = function (message) {
    if (message.event == "FAB_NAVIGATOR_NAVIGATE") {
        form.outputParams.NEXTPAGE = message.params.step;
        form.action("DIRECT");
    }
};

/////////////////////////////////////////////////////////////////////////////////////
form.getMapFromList = function (list, key, val) {
    for (var i = 0; i < list.length; i++) {
        if (list[i][key] + '' === val + '') {
            return list[i];
        }
    }
};
////Loan
form.tblLoanObj = (function (grId) {
    var gridId = grId;
    var options = {
        delete: function () {
            if (form.tblLoan.getSelectedRow()[0]) {
                form.tblLoan.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
        },
        editLoanItem : function (pageHeader, editMode) {
            var selectedRow = form.tblLoan.getSelectedRow()[0] || {};
            var editModeTemp = (form.isFormEditMode) ? "edit" : "view";
            var LoanParam = {
                newRow  : (editMode == "add") ? {} : selectedRow,
                PAGEHEADER  : "${pnlClientLoan.caption}",
                EDITMODE    : (editMode) ? editMode : editModeTemp,
                timeOfOverdueDebt : form.formParams.timeOfOverdueDebt,
                addPanel    : "${pnlClientLoanAdd.caption}"
            };
            form.startModalPageFlowProcess(form.getCurrentProjectSysname() + "/FORMLIB/inputApplication/creditHistory/clientCreditHistory", LoanParam).then(function (response) {
                if (!response) return;
                var newRow = response.newRow || {};
                if (LoanParam.EDITMODE == "view") return;
               // form.tblLoan.hideEditor();
                if (selectedRow['id'] && LoanParam.EDITMODE != "add") {
                    if (newRow instanceof Object && Object.keys(newRow).length > 0) {
                        form.tblLoan.updateRow(selectedRow['id'], newRow);
                    }
                }
                else {
                    if (newRow instanceof Object && Object.keys(newRow).length > 0) {
                        newRow['id'] = new Date().getTime();
                        form.tblLoan.addRow(newRow);
                    }
                }
            });
        }
    };

    var obj = {
        gridId: grId,
        loanPanelIsCollapsed: !inputParams.CreditHistoryLoans || inputParams.CreditHistoryLoans.length == 0,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        addNewRow: function () {
            obj.loanPanelIsCollapsed = false;
            this.options.editLoanItem("${pnlClientLoan.caption}", "add");
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (form.isFormEditMode == true) {
                options.items = [
                    {caption: gRB('edit'), click: form.tblLoan.options.editLoanItem},
                    {caption: gRB('delete'), click: form.tblLoan.options.delete}
                ];
            }
            else {
                options.items = [
                    {caption: gRB('view'), click: form.tblLoan.options.editLoanItem}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblLoan');

////Overdraft
form.tblOverdraftObj = (function (grId) {
    var gridId = grId;
    var options = {
        delete: function () {
            if (form.tblOverdraft.getSelectedRow()[0]) {
                form.tblOverdraft.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
        },
        editOverdraftItem : function (pageHeader, editMode) {
            var selectedRow = form.tblOverdraft.getSelectedRow()[0] || {};
            var editModeTemp = (form.isFormEditMode) ? "edit" : "view";
            var OverdraftParam = {
                newRow  : (editMode == "add") ? {} : selectedRow,
                PAGEHEADER  : "${pnlOverdraft.caption}",
                EDITMODE    : (editMode) ? editMode : editModeTemp,
                addPanel    : "${pnlOverdraftAdd.caption}"
            };
            form.startModalPageFlowProcess(form.getCurrentProjectSysname() + "/FORMLIB/inputApplication/creditHistory/clientCreditHistory", OverdraftParam).then(function (response) {
                if (!response) return;
                var newRow = response.newRow || {};
                if (OverdraftParam.EDITMODE == "view") return;
                if (selectedRow['id'] && OverdraftParam.EDITMODE != "add") {
                   // form.tblOverdraft.hideEditor();
                    if (newRow instanceof Object && Object.keys(newRow).length > 0) {
                        form.tblOverdraft.updateRow(selectedRow['id'], newRow);
                    }
                }
                else {
                   // form.tblOverdraft.hideEditor();
                    if (newRow instanceof Object && Object.keys(newRow).length > 0) {
                        newRow['id'] = new Date().getTime();
                        form.tblOverdraft.addRow(newRow);
                    }
                }
            });
        }
    };

    var obj = {
        gridId: grId,
        overdraftPanelIsCollapsed: !inputParams.CreditHistoryOverdraft || inputParams.CreditHistoryOverdraft.length == 0,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        addNewRow: function () {
            obj.overdraftPanelIsCollapsed = false;
            this.options.editOverdraftItem("${pnlOverdraft.caption}", "add");
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            var selectedRow = form.tblOverdraft.getSelectedRow()[0];
            if (form.isFormEditMode == true) {
                options.items = [
                    {caption: gRB('edit'), click: form.tblOverdraft.options.editOverdraftItem},
                    {caption: gRB('delete'), click: form.tblOverdraft.options.delete}
                ];
            }
            else {
                options.items = [
                    {caption: gRB('view'), click: form.tblOverdraft.options.editOverdraftItem}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblOverdraft');

////CreditCard
form.tblCreditCardObj = (function (grId) {
    var gridId = grId;
    var options = {
        delete: function () {
            if (form.tblCreditCard.getSelectedRow()[0]) {
                form.tblCreditCard.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
        },
        editCreditCardItem : function (pageHeader, editMode) {
            var selectedRow = form.tblCreditCard.getSelectedRow()[0] || {};
            var editModeTemp = (form.isFormEditMode) ? "edit" : "view";
            var CreditCardParam = {
                newRow  : (editMode == "add") ? {} : selectedRow,
                PAGEHEADER  : "${pnlCreditCard.caption}",
                EDITMODE    : (editMode) ? editMode : editModeTemp,
                addPanel    : "${pnlCreditCardAdd.caption}"
            };
            form.startModalPageFlowProcess(form.getCurrentProjectSysname() + "/FORMLIB/inputApplication/creditHistory/clientCreditHistory", CreditCardParam).then(function (response) {
                if (!response) return;
                var newRow = response.newRow || {};
                if (CreditCardParam.EDITMODE == "view") return;
                if (selectedRow['id'] && CreditCardParam.EDITMODE != "add") {
                   // form.tblCreditCard.hideEditor();
                    if (newRow instanceof Object && Object.keys(newRow).length > 0) {
                        form.tblCreditCard.updateRow(selectedRow['id'], newRow);
                    }
                }
                else {
                   // form.tblCreditCard.hideEditor();
                    if (newRow instanceof Object && Object.keys(newRow).length > 0) {
                        newRow['id'] = new Date().getTime();
                        form.tblCreditCard.addRow(newRow);
                    }
                }
            });
        }
    };

    var obj = {
        gridId: grId,
        creditCardPanelIsCollapsed: !inputParams.CreditHistoryCreditCard || inputParams.CreditHistoryCreditCard.length == 0,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        addNewRow: function () {
            obj.creditCardPanelIsCollapsed = false;
            this.options.editCreditCardItem("${pnlCreditCard.caption}", "add");
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (form.isFormEditMode == true) {
                options.items = [
                    {caption: gRB('edit'), click: form.tblCreditCard.options.editCreditCardItem},
                    {caption: gRB('delete'), click: form.tblCreditCard.options.delete}
                ];
            }
            else {
                options.items = [
                    {caption: gRB('view'), click: form.tblCreditCard.options.editCreditCardItem}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblCreditCard');