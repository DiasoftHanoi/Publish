/*DSMETA version = "6.01.01" hash = "b2d27c673500061f4589e73f1d2111d1d8840525"*/
service.showDialogCancelConfirm = showDialogCancelConfirm;

function showDialogCancelConfirm(form, yesFunc, noFunc){
    var gRB = form.getResourceBundle;

    form.showQuestionDialog(
        form.inputParams.APPLICATIONID ? gRB('dialog.confirmCancelAndModify') : gRB('dialog.confirmCancelAndSave'),

        function (response){
            switch (response.buttonIndex){
                case 0:
                    if (yesFunc){
                        yesFunc();
                    } else {
                        form.outputParams.TRANSTYPE = 'SAVE';
                        form.sendForm('GO',false);
                    }
                    break;
                case 1:
                    if (noFunc){
                        noFunc();
                    } else {
                        form.outputParams.TRANSTYPE = 'CLOSE';
                        form.sendForm('GO',false);
                    }
                    break;
            }
        },
        [
            {caption: gRB('dialog.yes')},
            {caption: gRB('dialog.no')},
            {caption: gRB('dialog.cancel')}
        ]
    )
}