template.formParams = template.data;
template.notData = form.getResourceBundle('summaryLoan.notData.caption');
