/*DSMETA version = "5.11.01-24040302" hash = "bd6fb658c817b0855d4324f87c723c5739beadba"*/
/* global form, service */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;
var linkedAppParams = inputParams.PARAMS || {};
linkedAppParams.DOCUMENTTYPEID = inputParams.DOCUMENTTYPEID;
linkedAppParams.MAINAPPLICATIONID = inputParams.APPLICATIONID;
linkedAppParams.MAINDOCTYPESYSNAME = inputParams.MAINDOCTYPESYSNAME;
linkedAppParams.EDITMODE = form.inputParams.EDITMODE || false;
var outputParams = form.outputParams || {};
outputParams.formParams = form.formParams;
var lgr = service.lgr;
var nvl = service.nvl;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.isFormEditMode = form.inputParams.EDITMODE || false;

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
    if (!form.isFormEditMode) {
        if (form.btnNext) {
            form.btnNext.setFocus();
        }
        else if (form.btnSave) {
            form.btnSave.setFocus();
        }
        else {
            form.btnCancel.setFocus();
        }
    }
};

form.disEnElem = function(elID) {
    if (form.isFormEditMode) {
        if (form[elID].isEnabled()) {
           form[elID].disable();
            return
        }
    form[elID].enable();
    } 
};

form.participantList = inputParams.formParams.participantList;
form.addParticipant = function () {
    form.disEnElem("btnParticipantListAdd");
    form.startNewPageFlowProcess("Add Application",  form.getCurrentProjectSysname() + '/' + 'loanApp/' + inputParams.MAINDOCTYPESYSNAME +'/inputApplication/inputLinkedApplication', {
        extraParams: linkedAppParams
    },
    true, null,
    function(p){
        if (form.participantList)
           form.sendForm('REFRESH', false);
    });
};

form.executeCommand = function (msg) {
    switch (msg.event) {
        case 'REFRESH_PERSON_LIST':
            form['addParticipantListTable'].setItems(msg.params.participantList);
            form['addParticipantListTable'].refresh();
            form.participantList = msg.params.participantList;
        break;
        case 'FAB_NAVIGATOR_NAVIGATE':
            outputParams.NEXTPAGE = msg.params.step;
            form.action('DIRECT');
        break;
        default:
            break;
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;
    var buttonNextSave = (form.isLastWizForm) ? "btnSave" : "btnNext";
    try {
        var btnNext =  form['btnNext'] ? 'btnNext' : 'btnComplete';
        if (form.validateControlsByIds('*', showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {lgr(e);
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.participantListObj = (function (grId){
    var gridId = grId;
    var processParams = {
        PROCESS_RIGHT_LIST :  inputParams.PROCESS_RIGHT_LIST,
        EDITMODE: form.isFormEditMode
    };

    var obj = {
        gridId: grId,
        options : {
		},
        refresh : function (){
        },

		onChangeItems: function () {
        }
    };

    return obj;
})("participantListObj");

form.onSelectParticipantList=function(item){
    lgr('onSelectParticipantList', arguments);
    var params = {
        APPLICATIONID : item.DOCUMENTID,
                application : {mode:(form.isFormEditMode ? 'edit' : 'view')}
    };
    form.participantListObj.options['ID' + item.DOCUMENTID+item.STATE] = undefined;

    if (item.participant == form.inputParams.PARAMS['linkViewName'])
        form.startProcess(
            form.getCurrentProjectSysname()+'/COMMON/APPLICATION/getTransferList',
            params,
            function (p) {
                lgr('fillTransfers', p);
                var transfersList = nvl(p['transfersList'],{});
                var resActions=[];
                if (transfersList && transfersList.length) {
                for (var i=0;i<transfersList.length;i++){
                    if(transfersList[i]["SYSNAME"].indexOf("subject")==0) 
                        resActions.push({
                            caption:transfersList[i]["NAME"],
                            click:function(){form.onApplicationAction(this,item)},
                            TRANSITIONID:transfersList[i]["TRANSITIONID"]
                        })
                    }
                }
                form.participantListObj.options['ID' + item.DOCUMENTID+item.STATE] = resActions;
            }
        );
    else if (item.participant == form.inputParams.PARAMS['mainAppLinkViewName']) {
        var resActions=[];
        if (!form.isFormEditMode) {
            resActions.push({
                caption:        form.getResourceBundle("view"),
                click:          function(){form.onMainApplicationAction(this,item)},
                DOCTYPESYSNAME: item.DOCTYPESYSNAME
            })
        }
        form.participantListObj.options['ID' + item.DOCUMENTID+item.STATE] = resActions;
    }

};

form.onApplicationAction=function(data,item){
    form.addParticipantListTable.setSelectedRow(undefined);
    form.participantListObj.options['ID' + item.DOCUMENTID+item.STATE] = null;
    form.startNewPageFlowProcess(data.caption+'. Application',form.getCurrentProjectSysname()+'/COMMON/STATEMACHINE/callPageflowByTransfer',{
        APPLICATIONID:item.DOCUMENTID,
        MAINAPPLICATIONID:inputParams.APPLICATIONID,
        TRANSITIONID:data.TRANSITIONID,
        extraParams: linkedAppParams
    },true,null,function(p) { 
        if (form.participantList)
            form.sendForm('REFRESH', false)
    })
};

form.onMainApplicationAction=function(data,item){
    form.addParticipantListTable.setSelectedRow(undefined);
    form.participantListObj.options['ID' + item.DOCUMENTID+item.STATE] = null;

    var extraParams = linkedAppParams;
    extraParams.LINKNAME        = form.getResourceBundle("Client");
    extraParams.packLinkSysname = undefined;
    extraParams.wizardSysname   = data.DOCTYPESYSNAME; //they are match
    extraParams.DOCTYPESYSNAME  = data.DOCTYPESYSNAME;
    var pfd = '';
    switch (data.DOCTYPESYSNAME){
        case 'autoLoanAppINT':
            pfd = form.getCurrentProjectSysname()+'/loanApp/autoLoanAppINT/inputApplication/inputLinkedApplication';
            break;
        case 'issueCardAppINT':
            pfd = form.getCurrentProjectSysname()+'/loanApp/issueCardAppINT/inputApplication/inputLinkedApplication';
            break;
        case 'mortgageLoanAppINT':
            pfd = form.getCurrentProjectSysname()+'/loanApp/mortgageLoanAppINT/inputApplication/inputLinkedApplication';
            break;
        case 'consumerLoanAppINT':
            pfd = form.getCurrentProjectSysname()+'/loanApp/consumerLoanAppINT/inputApplication/inputLinkedApplication';
            break;            
    }

    form.startNewPageFlowProcess(data.caption+'. Application', pfd, {
        APPLICATIONID:     item.DOCUMENTID,
        MAINAPPLICATIONID: inputParams.APPLICATIONID,
        extraParams:       extraParams
    },true,null,function(p) { 
        if (form.participantList)
           form.sendForm('REFRESH', false)
    })
};

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    form.formParams.participantList =  form.participantList;
    if (tagName === 'CLOSE') {
        form.sendForm('GO', false);
    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};
