/*DSMETA version = "5.11.01-24040302" hash = "b62ccc8f75ce25b63410ea0d7d740558099db3fa"*/
var inputParams = form.inputParams;
var outputParams = form.outputParams;

var nvl = service.nvl;

var transList = nvl(form.inputParams.transList, []);

form.onMenuAction = function (data) {
    outputParams.TRANSITIONID = data['TRANSITIONID'];
    outputParams.TRANSITIONSYSNAME = data['SYSNAME'];
    outputParams.VERIFIED = true;
    outputParams.TRANSTYPE = 'NEXT';
    form.sendForm('GO');
};

form.onBtnAction = function (i) {
    outputParams.TRANSITIONID = transList[i]['TRANSITIONID'];
    outputParams.TRANSITIONSYSNAME = transList[i]['SYSNAME'];
    outputParams.TRANSTYPE = 'NEXT';
    outputParams.VERIFIED = true;
    form.sendForm('GO');
};

form.onShow = function () {
    form.action1 = '';
    form.action2 = '';
    form.actions = [];
    for (var i = 0; i < transList.length; i++) {
        form.actions.push({
            caption: transList[i]["NAME"],
            click: function () {
                form.onMenuAction(this)
            },
            TRANSITIONID: transList[i]["TRANSITIONID"]
        });
    }
    if (transList.length == 1) {
        form.action1 = transList[0]["NAME"];
    }
    if (transList.length == 2) {
        form.action1 = transList[0]["NAME"];
        form.action2 = transList[1]["NAME"];
    }
    service.wizFormNavigatorCommand({
        context: form,
        event: "CURPAGE_MSG"
    });
};

form.executeCommand = function (msg) {
    if (msg.event == "FAB_NAVIGATOR_NAVIGATE") {
        form.outputParams.NEXTPAGE = msg.params.step;
        form.action("DIRECT");
    }
};

form.action = function (tag) {
    outputParams.VERIFIED = true;
    outputParams.TRANSTYPE = tag;
    form.sendForm('GO', false);
};