/*DSMETA version = "5.08.01-22051101" hash = "be7e33f0e06a7d92501d7e71f98cf53a7a74db78"*/
function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var inputParams = form.inputParams || {};
form.searchParams = inputParams.searchParams || {};
var gRB = service.gRB;
var outputParams = form.outputParams || {}
outputParams.searchParams = form.searchParams || {};
var linkedAppParams = form.inputParams.extraParams || {};
form.hasLinkName = (linkedAppParams.LINKNAME != undefined && linkedAppParams.LINKNAME != "" && linkedAppParams.LINKNAME != null) ? true : false;
form.isHideCreateButton = inputParams.isHideCreateButton != null ?  true : false;
form.onShow = function () {

};

form.personBrowseListParams = {};
form.personBrowseListParams.method = 'dsPersonBrowseListByParam';
form.personBrowseListParams.service = 'crmws';
form.personBrowseListParams.id = 'PersonID';
form.personBrowseListParams.itemIdField = 'PersonID';
form.personBrowseResultName = 'PersonBrowseList';

form.personBrowseListParams.filterParams = {
        ReturnAsHashMap: 'TRUE',
        PersonBrief: form.searchParams.CurrentName,
        BirthDay: form.searchParams.BirthDay,
        IdentityCardNumber: form.searchParams.IdentityCardNumber,
        IdentityCardTypeBrief: form.searchParams.IdentityCardTypeBrief,
        ContactValue: form.searchParams.ContactValue
};

form.onSelectClient = function(item) {
    var selRow = form.personBrowseList.getSelectedRow()[0];
    if (selRow instanceof Object && Object.keys(selRow).length > 1) {
        form.showQuestionDialog(gRB("clientIdentificationList.clientIsIdentified"),
            function (response) {
                switch (response.buttonIndex) {
                    case 0:
                        form.outputParams.PersonID = item.PersonID;
                        form.outputParams.ACTION = "NEXT";
                        form.outputParams.curPage = "APPLIST";
                        form.sendForm('NEXT', false);
                        break;
                    case 1:
                        break;
                }
            },
            [
                {caption: gRB('dialog.yes')},
                {caption: gRB('dialog.no')}
            ]
        )
    }
};

form.executeCommand = function(msg) {
    switch(msg.event){
        case 'SEARCH':
        form.personBrowseListParams.filterParams = {
            ReturnAsHashMap: 'TRUE',
            PersonBrief: (msg.params.CurrentName ? msg.params.CurrentName : undefined),
            BirthDay: (msg.params.BirthDay ? msg.params.BirthDay : undefined),
            IdentityCardNumber: (msg.params.IdentityCardNumber ? msg.params.IdentityCardNumber : undefined),
            IdentityCardTypeBrief: (msg.params.IdentityCardTypeBrief ? msg.params.IdentityCardTypeBrief : undefined),
            ContactValue: (msg.params.ContactValue ? msg.params.ContactValue : undefined)
        };

        form.personBrowseList.refresh();
            break;
        case 'UPDATE_SEARCH_PARAMS':
            form.outputParams.searchParams = msg.params.searchParams;
            break;
        case 'REFRESH_PRODUCT_LIST':
            form.personBrowseList.refresh();
            break;
        case 'GO_TO_PAGEFLOW':
            form.startNewPageFlowProcess(msg.caption, msg.params.PAGEFLOW, {
                APPLICATIONID: msg.params.APPLICATIONID,
                EDITMODE: false
            });
            break;
       default:
            break;
    }
};

form.applicationObj = {
    items: (function() {
        var ItemMenuList = form.inputParams.ItemMenuList || [];
            for(var i=0; i<ItemMenuList.length; i++) {
                ItemMenuList[i]["caption"]= ItemMenuList[i]["ITEMNAME"];
                var SYSNAME = ItemMenuList[i]["SYSNAME"];
                var func = function(Index) {
                    outputParams.SYSNAME = Index['item']['SYSNAME'];
                    form.outputParams.ACTION = "NEXT";
                    form.outputParams.curPage = "MINIAPP";
                    form.sendForm("NEXT", false);
                }
                ItemMenuList[i]["click"] =  func;
            }
        return ItemMenuList;
    }())
};

form.action = function (tag) {
    form.outputParams.ACTION = tag;
    form.sendForm(tag, false);
};