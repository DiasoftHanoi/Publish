/*DSMETA version = "5.10.01-23081102" hash = "4c706767b74e9f578e87337db694aaae5ac5068c"*/

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var inputParams = form.inputParams;

var outputParams = form.outputParams;

outputParams.formParams = {};
form.params = form.inputParams.formParams || {};
form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.params.assetsList = form.params.assetsList ? form.params.assetsList : [];
form.params.incomeList  = form.params.incomeList ? form.params.incomeList:[];
form.pnlAssetsInfoIsCollapsed = /*true;*/ form.params.assetsList.length <= 0;
form.pnlValueblePaperIsCollapsed = /*true;*/ form.params.valPaperList.length <= 0;
form.isFormEditMode = form.inputParams.EDITMODE || false;
form.WIZARDNAME = form.inputParams.wizardParams["WIZARDNAME"];
form.params.hasCompanyParams = form.companyParams ? false : true;

service.lgr(form.params);

var log = service.lgr;
var gRB = service.gRB;
var nvl = service.nvl;

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });

    form.assetsInfo.setItems(form.params.assetsList || []);

    form.valueblePaper.setItems(form.params.valPaperList || []);

    if (!form.isFormEditMode) {
        if (form.btnNext) {
            form.btnNext.setFocus();
        }
        else if (form.btnSave) {
            form.btnSave.setFocus();
        }
        else {
            form.btnCancel.setFocus();
        }
    }
};

form.showRemoveDialog =function(form, yesFunc, noFunc, question){
    form.showDeleteDialog(question,
        function (response){
            switch (response.buttonIndex){
                case 0:
                    var selRow = form.assetsInfo.getSelectedRow()[0]; 
                    var isCollateral = (selRow) ? selRow.isCollateral : "";
                    if (isCollateral) {
                        form.showDeleteDialog(gRB("dialog.RemoveAssetsIsCollateral"), function (){
                        }, [{caption: 'OK'}]);
                        return;
                    }
                    if (yesFunc){
                        yesFunc();
                    } else {
                        form.outputParams.TRANSTYPE = 'SAVE';
                        form.sendForm('GO',false);
                    }
                    break;
            }
        },
        [
            {caption: gRB('dialog.yes')},
            {caption: gRB('dialog.no')}
        ]
    )
};

form.saveRow = function(selectedRow,gridId) {
    //if (selectedRow['fabIndex']*1 >= 0) {
    if (selectedRow['editAssetsCompanyFlag']) {
        selectedRow['editAssetsCompanyFlag'] = undefined;
        form[gridId].updateRow(selectedRow['id'], selectedRow);
    }
    else {
        var newRow = {};
        selectedRow['id'] = new Date().getTime();
        form[gridId].addRow(selectedRow);
        form[gridId].refresh();
    }
};

form.executeCommand = function (msg) {
    switch (msg.event) {
        case 'COMPANY_LIST':
        form.saveRow(msg.params,"valueblePaper");
            form.btnValPaperAdd.enable();
            form.companyParams = msg.params;
        break;
        case 'FAB_NAVIGATOR_NAVIGATE':
            outputParams.NEXTPAGE = msg.params.step;
            form.action('DIRECT');
        break;
        default:
            break;
    }
};


form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var save =  form['save'];

        if (form.validateControlsByIds('*', showFlag === true ? save : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.tblHasRows = function(list) {
    if (list.length > 0) {
       return true; 
    }
    return false;
};

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    outputParams.VERIFIED = true;

    if (form.isFormEditMode) {
        outputParams.formParams.assetsList = nvl(form.assetsInfo.getItems(), []);
        outputParams.formParams.valPaperList = nvl(form.valueblePaper.getItems(), []);
        outputParams.formParams.incomeList = form.params.incomeList;

    }
    if (tagName === 'CLOSE') {
        if(form.inputParams.EDITMODE === false){
            form.sendForm('GO',false);
        }else {
            service.showDialogCancelConfirm(
                form,
                function () {
                    form.outputParams.TRANSTYPE = 'SAVEDRAFT';
                    form.verifyForm(false);
                    form.sendForm('GO', false);
                }
            )
        }
    }
    else {
        form.sendForm('GO', false);
    }
};
form.templateData={
    templateKind:"small" ,
    address:{},
    addressText:"",    
}
form.tblAssetsInfoObj = (function (grId) {
    var gridId = grId; 
    var options = {
        templateData:form.templateData,
        cancel: function () {
            options.clearFields();
            form[gridId].hideEditor();
            form.btnDataWorkAdd.enable();
        },
        save: function () {
            form.verifyForm(true);
            var selectedRow = form.assetsInfo.getSelectedRow()[0];
            var newRow = {
                sysnameTypeAssets          : form.cbAssetsType.getValue(),
                typeAssets          : form.cbAssetsType.getText(),
                estimatedValue        : form.estimVal.getValue(),
                description     : form.descrip.getValue(),
                estimView: form.estimVal.getText(),
				estimCurrency: inputParams.loanCurrency || "",
                estimBundle : gRB('estimatedValue')	
            };

            if (form.tblAssetsInfoObj.options.isRealEstate()) {
                var sysnameObjectTypeRealEstate = form.sysnameObjectTypeRealEstate ? form.sysnameObjectTypeRealEstate.getValue() : null;
                var objectTypeRealEstate = form.sysnameObjectTypeRealEstate ? form.sysnameObjectTypeRealEstate.getText() : null ;
                var certificateNumberRealEstate = form.edcertifNo ? form.edcertifNo.getValue() : null;
                var certificateIssueDatRealEstate = form.clIssueDate ? form.clIssueDate.getValue() : null;
                var address = form.edAddressBlock ? form.edAddressBlock.data.address : null;
                var addressString = form.edAddressBlock ? form.edAddressBlock.data.address.addressText : null;
                newRow.sysnameObjectTypeRealEstate = sysnameObjectTypeRealEstate;
                newRow.objectTypeRealEstate = objectTypeRealEstate;
                newRow.certificateNumberRealEstate = certificateNumberRealEstate;
                newRow.certificateIssueDatRealEstate = certificateIssueDatRealEstate;
                newRow.address = address;
                newRow.addressString = addressString;

            }
            if (form.tblAssetsInfoObj.options.isVehicle()) {
                var brandCar= form.edBrand ? form.edBrand.getValue() : null;
                var engineNumber = form.edEngine ? form.edEngine.getValue(): null;
                var noChassis = form.edChassisNo ? form.edChassisNo.getValue(): null;
                var RegistrationNumberCar = form.edRegNoCar ? form.edRegNoCar.getValue(): null;
                var registrationDateCar = form.clRegDate ? form.clRegDate.getValue(): null;
                newRow.brandCar = brandCar;
                newRow.engineNumber = engineNumber;
                newRow.noChassis = noChassis;
                newRow.RegistrationNumberCar = RegistrationNumberCar;
                newRow.registrationDateCar = registrationDateCar;
            }
            options.clearFields();
            if (selectedRow['LinkID']) {
                newRow['LinkID'] = selectedRow['LinkID'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['LinkID'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnDataWorkAdd.enable();
        },
        clearFields: function () {
            delete options.data.typeAssets;
            delete options.data.sysnameTypeAssets;
            delete options.data.estimatedValue;
            delete options.data.description;
            delete options.data.sysnameObjectTypeRealEstate;
            delete options.data.objectTypeRealEstate;
            delete options.data.certificateNumberRealEstate;
            delete options.data.certificateIssueDatRealEstate;
            delete options.data.address;
            delete options.data.addressString;
            delete options.data.brandCar;
            delete options.data.engineNumber;
            delete options.data.noChassis;
            delete options.data.RegistrationNumberCar;
            delete options.data.registrationDateCar;
            if(form.edAddressBlock) {
                form.edAddressBlock.data.address={};
                form.edAddressBlock.data.addressText="";
            }
        },
        getOptionsData: function () {
            var selectedRow = form.assetsInfo.getSelectedRow()[0];

            form.tblAssetsInfoObj.options.data = {
                typeAssets           : selectedRow["typeAssets"],
                sysnameTypeAssets    : selectedRow["sysnameTypeAssets"],
                estimatedValue   : selectedRow["estimatedValue"],
                description : selectedRow['description'],
                sysnameObjectTypeRealEstate : selectedRow["sysnameObjectTypeRealEstate"],
                objectTypeRealEstate :  selectedRow["objectTypeRealEstate"],
                certificateNumberRealEstate : selectedRow["certificateNumberRealEstate"],
                certificateIssueDatRealEstate : selectedRow["certificateIssueDatRealEstate"],
                brandCar: selectedRow["brandCar"],
                engineNumber : selectedRow["engineNumber"],
                noChassis : selectedRow["noChassis"],
                RegistrationNumberCar : selectedRow["RegistrationNumberCar"],
                registrationDateCar : selectedRow["registrationDateCar"],
                estimCurrency : selectedRow["estimCurrency"]
            };
            form.tblAssetsInfoObj.options.templateData.address=selectedRow["address"];
            form.tblAssetsInfoObj.options.templateData.addressText=selectedRow["addressString"];           
         
        }, 
        edit: function () {
            options.clearFields();
            options.getOptionsData();            
            form[gridId].showEditor('edit');
            form.btnDataWorkAdd.disable();
        },
        view : function () {
            options.getOptionsData();
            var projectSysname = form.getCurrentProjectSysname();
            var pfd = '/FORMLIB/inputApplication/assetsInfo/viewAssetsInfo';
            form.startModalPageFlowProcess(projectSysname+pfd, {
            rowData: options.data
            });

        },
        delete: function () {
            var index=-1;
            var isFind=false;
            for (var i=0;i<form.params.incomeList.length;i++){
                var item = form.params.incomeList[i];
                if(item["LinkID"]===obj.selectedId){
                    index=i;
                    isFind=true;
                    break;
                }
            }
            var question = isFind ? gRB('dialog.RemoveAssetsAndIncomeLists') : gRB('dialog.RemoveFinancinalInformationHousehold');
            form.showRemoveDialog(form,
                function (){
                    if(isFind){
                        form.params.incomeList.splice(index, 1);
                        if (form.assetsInfo.getSelectedRow()[0]) {
                            form.assetsInfo.deleteRow(obj.selectedId);
                            form[gridId].refresh();
                        }
                    }
                    else {
                        if (form.assetsInfo.getSelectedRow()[0]) {
                            form.assetsInfo.deleteRow(obj.selectedId);
                            form[gridId].refresh();
                        }
                    }
                },
                null, question);
        },
        onChangeItems:  function () {
        },
        isRealEstate: function () {
            if (nvl(form.tblAssetsInfoObj.options.data.sysnameTypeAssets)) {
                if (form.tblAssetsInfoObj.options.data.sysnameTypeAssets.toLowerCase() == "realestate") {
                    return true;    
                }
            }
        return false;
        },
        isVehicle: function () {
            if (nvl(form.tblAssetsInfoObj.options.data.sysnameTypeAssets)) {
                if (form.tblAssetsInfoObj.options.data.sysnameTypeAssets.toLowerCase() == "vehicle") {
                  return true;    
                }
            }
        return false;
        },

        getCurDate: function () {
            var now = new Date();
            return service.convertDate(now);
        },

        assetsTypeList: form.params.assetsTypeList,
        propertiesInOwnershipList : form.params.propertiesInOwnershipList,
        data: {}

    };
    
    var obj = {
        addNewRow: function () {
            options.clearFields();
            form.pnlAssetsInfo.isCollapsed = false;
            form[gridId].showEditor('add');
            
            
            form.btnDataWorkAdd.disable();
            
        },
        onSelectRow: function () {
            var selRow = form[gridId].getSelectedRow()[0] || {};
            if (form.isFormEditMode) {
                options.items = [
                    {caption: gRB('edit'), click: form.tblAssetsInfoObj.options.edit},
                    {caption: gRB('delete'), click: form.tblAssetsInfoObj.options.delete}
                ];
            }
            else {
                options.items = [
                    {caption: gRB('view'), click: form.tblAssetsInfoObj.options.view},
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('assetsInfo');



form.tblValueblePaperObj = (function (grId) {
    var gridId = grId; 
    var processParams = {
        PROCESS_RIGHT_LIST :  inputParams.PROCESS_RIGHT_LIST,
        EDITMODE: form.isFormEditMode
    };
     
    var options = {
        startValPaperPfd : function(actionName) {
            if (form.isFormEditMode) {
                form.btnValPaperAdd.disable();
            };
            if (nvl(actionName, '') != 'add') {
                processParams.selectRow = form.valueblePaper.getSelectedRow()[0] || {};
                processParams.selectRow['loanCurrency'] = inputParams.loanCurrency || "";
                processParams.selectRow['editAssetsCompanyFlag'] = true;
                processParams.rowId = form.valueblePaper.selectedIndex;
            } else {
                processParams.selectRow = {};
                processParams.rowId = null;
            }
          
            form.startNewPageFlowProcess("${assetsInfoFormWizard}",  form.getCurrentProjectSysname() + '/' + 'FORMLIB/inputApplication/assetsInfo/assetsInfoFormWizard', {
                wizardParams: processParams                     
            },true, false,function(response){
                if (form.isFormEditMode) {form.btnValPaperAdd.enable()};
            }); 
        }, 
        cancel: function () {
            form[gridId].hideEditor();
            form.btnValPaperAdd.enable();
        },
        
        edit: function (selRow) {
            form.btnValPaperAdd.disable();
            form.tblValueblePaperObj.options.startValPaperPfd();
                      
        },
    
        view : function (selRow) {
            form.tblValueblePaperObj.options.startValPaperPfd();            
        },
        
        delete: function () {
            form.showRemoveDialog(form,
                function(){
                    if (form.valueblePaper.getSelectedRow()[0]) {
                        form.valueblePaper.deleteRow(obj.selectedId);
                        form[gridId].refresh();
                    }
                }, null, gRB('dialog.RemoveFinancinalInformationHousehold'));
        },
        onChangeItems:  function () {
        },
        data: {},
        estimCurrency: inputParams.loanCurrency || "",
        estimBundle :  gRB('estimatedValue')	

    };
    
    var obj = {
        addNewRow: function() {
            form.pnlValueblePaper.isCollapsed = false;
            form.tblValueblePaperObj.options.startValPaperPfd('add');
        },
        onSelectRow: function () {
            var selRow = form[gridId].getSelectedRow()[0] || {};
            if (form.isFormEditMode) {
                options.items = [
                    {caption: gRB('edit'), click: form.tblValueblePaperObj.options.edit},
                    {caption: gRB('delete'), click: form.tblValueblePaperObj.options.delete}
                ];
            }
            else {
                options.items = [
                    {caption: gRB('view'), click: form.tblValueblePaperObj.options.view},
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('valueblePaper');


