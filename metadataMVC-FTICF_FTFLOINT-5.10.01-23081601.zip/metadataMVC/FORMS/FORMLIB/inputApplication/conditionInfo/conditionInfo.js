/*DSMETA version = "5.10.01-23081601" hash = "f71fc6787ac87b0023726cc4fad93eb399ed104a"*/
/* global form, service */


function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
var service = registerMethod(service);

form.params = form.inputParams.formParams || {};
form.params.businessesList = form.params.businessesList ? form.params.businessesList : [];
var convertDate = service.convertDate;
var getTableContent = service.getTableContent;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.isFormEditMode = form.inputParams.EDITMODE || false;
form.isFormEditModeMain = form.inputParams.EDITMODE;

var inputParams = form.inputParams;
var outputParams = form.outputParams;

form.formParams = inputParams.formParams || {};
outputParams.formParams = form.formParams;


var lgr = service.lgr;
var nvl = service.nvl;
service.lgr(form.params);
form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
};
form.requiredElements = [
    //These are not required, but need to be verified:
    "memConditionsBeforeDisbursement",
    "memConditionsAfterDisbursement",
    "memChecksConditionsAfterDisbursement",
    "memOtherConditions",
    "memExceptions"
];



form.verifyForm = function (showFlag, tag) {

    var verified = true;
    var buttonNextSave = (form.isLastWizForm) ? "btnSave" : "btnNext";
    if (tag === 'CLOSE') {
        buttonNextSave = "btnCancel";
    }

    try {
        console.log('verifyForm');
        console.log('r ',form.requiredElements.join(','));
        if ((form.validateControlsByIds(form.requiredElements.join(','), showFlag === true ? buttonNextSave : undefined).isShowFormErrors)) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    outputParams.VERIFIED = verified;
    console.log('verified ',verified);
    return verified;
};

form.executeCommand = function (msg) {

    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE') {
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};

form.yesFunc = function() {
    outputParams.TRANSTYPE = 'SAVEDRAFT';
    form.sendForm('GO', false);
};

form.action = function (tag) {

    outputParams.TRANSTYPE = tag;

    if (form.isFormEditModeMain) {
        outputParams.formParams.conditionsBeforeDisbursement         = form.params.conditionsBeforeDisbursement;
        outputParams.formParams.conditionsAfterDisbursement          = form.params.conditionsAfterDisbursement;
        outputParams.formParams.checksConditionsAfterDisbursement    = form.params.checksConditionsAfterDisbursement;
        outputParams.formParams.otherConditions                      = form.params.otherConditions;
        outputParams.formParams.exceptions                           = form.params.exceptions;

    }
    if (tag === 'CLOSE') {
        if(form.inputParams.EDITMODE === false){
            form.sendForm('GO',false);
        }else{
            form.verifyForm(true, tag);
            service.showDialogCancelConfirm(
                form,
                form.yesFunc
            )
        }
    }
    else {
        if (tag === 'NEXT' && !form.verifyForm(true) ) {
            return;
        }else{
            form.verifyForm(false);
        }
        form.sendForm('GO', false);

    }
}