/*DSMETA version = "5.10.01-23081601" hash = "8b4b6a6193fe2a940ebaaeccc41cc1542e1077c7"*/
/* global form */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var convertDate = service.convertDate;
var getTableContent = service.getTableContent;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.isFormEditMode = form.inputParams.EDITMODE || false;

var inputParams = form.inputParams;
var outputParams = form.outputParams;

form.formParams = inputParams.formParams || {};
outputParams.formParams = form.formParams;

form.formParams.expensesList = form.formParams.expensesList ? form.formParams.expensesList : [];
form.formParams.revenueListHousehold  = form.formParams.revenueListHousehold ? form.formParams.revenueListHousehold:[];
form.formParams.costOfGoodsList  = form.formParams.costOfGoodsList ? form.formParams.costOfGoodsList:[];

form.totalProfitFlag=(form.formParams.expensesList.length+form.formParams.revenueListHousehold.length+form.formParams.costOfGoodsList.length)>0

form.totalProfit=form.formParams.totalProfit || parseFloat(0);
form.requiredElements = [
    ""
];

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });

    form.tblCostOfGoodsSolObj.setItems(form.inputParams.formParams.costOfGoodsList  || []);
    form.tblRevenueObj.setItems(form.inputParams.formParams.revenueListHousehold  || []);
    form.tblExpensesObj.setItems(form.inputParams.formParams.expensesList  || []);

    if (!form.isFormEditMode) {
        if (form.btnNext) {
            form.btnNext.setFocus();
        }
        else if (form.btnSave) {
            form.btnSave.setFocus();
        }
        else {
            form.btnCancel.setFocus();
        }
    }

};

var sendMessage = function (message) {
    var PROCESS_RIGHT_LIST = getInputParams("PROCESS_RIGHT_LIST");
    if (PROCESS_RIGHT_LIST) {
        for (var ar in PROCESS_RIGHT_LIST) {
            form.commandRight(ar, message);
        }
    }
};

form.curDate = service.convertDate(new Date());

form.yesFunc = function() {
    form.outputParams.TRANSTYPE = 'SAVEDRAFT';
    if (form.verifyForm()) {
        form.sendForm('GO', false);
    }
};

form.action = function (tag) {
    outputParams.TRANSTYPE = tag;
    form.outputParams.VERIFIED = true;
    if(form.isFormEditMode){

        outputParams.formParams.costOfGoodsList  = form.tblCostOfGoodsSolObj.getItems();
        outputParams.formParams.revenueListHousehold = form.tblRevenueObj.getItems();
        outputParams.formParams.expensesList = form.tblExpensesObj.getItems();
        outputParams.formParams.totalProfit=form.totalProfit;
    }

    if (tag === 'CLOSE' && form.isFormEditMode) {
        service.showDialogCancelConfirm(
            form,
            form.yesFunc
        )
    }
    else {
        form.sendForm('GO', false);
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;
    var buttonNextSave = (form.isLastWizForm) ? "btnSave" : "btnNext";
    try {
        console.log('verifyForm')
        if ((form.validateControlsByIds(form.requiredElements.join(','), showFlag === true ? buttonNextSave : undefined).isShowFormErrors)) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.executeCommand = function (message) {
    if (message.event == "FAB_NAVIGATOR_NAVIGATE") {
        form.outputParams.NEXTPAGE = message.params.step;
        form.action("DIRECT");
    }
};

////////////////////////////////////////////////////////////////////////////////
form.executeCommand = function (msg) {
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE') {
        form.outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};
/////////////////////////////////////////////////////////////////////////////////////
form.getMapFromList = function (list, key, val) {
    for (var i = 0; i < list.length; i++) {
        if (list[i][key] + '' === val + '') {
            return list[i];
        }
    }
};
form.roundToTwo = function(num) {
    return +(Math.round(num + "e+2")  + "e-2");
}
//////////
form.showRemoveDialog =function(form, yesFunc, noFunc){
    var gRB = form.getResourceBundle;
    form.showQuestionDialog(gRB('dialog.RemoveFinancinalInformationHousehold'),
        function (response){
            switch (response.buttonIndex){
                case 0:
                    if (yesFunc){
                        yesFunc();
                    } else {
                        form.outputParams.TRANSTYPE = 'SAVE';
                        form.sendForm('GO',false);
                    }
                    break;
            }
        },
        [
            {caption: gRB('dialog.yes')},
            {caption: gRB('dialog.cancel')}
        ]
    )
}
/////Revenue
form.tblRevenueObj = (function (grId) {
    var gridId = grId;
    var options = {

        requiredElements : [
            "edIncomeType",
            "edIncomeValue"
        ],
        cancel: function () {
            form[gridId].hideEditor();
            form.btnRevenueAdd.enable();
        },
        save: function () {
            var selectedRow = form.tblRevenue.getSelectedRow()[0];
            var newRow = {
                incomeType         : options.incomeType,
                incomeValue        : options.incomeValue,
                incomeValueText    : form.edIncomeValue.getText(),
                incomeDescription  : options.incomeDescription
            };

            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                var oldSum=parseFloat(options.oldIncomeValue);
                var newSum=parseFloat(options.incomeValue);
                form.totalProfit = form.roundToTwo(form.totalProfit+newSum-oldSum);
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);
            }
            else {
                newRow['id'] = new Date().getTime();
                var sum=parseFloat(options.incomeValue);
                form.totalProfit = form.roundToTwo(form.totalProfit+sum);
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnRevenueAdd.enable();

            form.totalProfitFlag=(form.tblCostOfGoodsSolObj.getItems().length+form.tblRevenueObj.getItems().length+ form.tblExpensesObj.getItems().length)>0
        },
        clearFields: function () {
            delete options.incomeType;
            delete options.incomeValue;
            delete options.incomeDescription;

        },
        edit: function () {
            form.addAddrMode = 'edit';
            form[gridId].showEditor('edit');
            options.clearFields();
            var selectedRow = form.tblRevenue.getSelectedRow()[0];
            options.oldIncomeValue      = selectedRow["incomeValue"];
            options.incomeType          = selectedRow["incomeType"];
            options.incomeValue         = selectedRow["incomeValue"];
            options.incomeDescription   = selectedRow["incomeDescription"];
            form.btnRevenueAdd.disable();
        },
        delete: function () {
            form.showRemoveDialog(form,
                function(){
                    var row = form.tblRevenue.getSelectedRow()[0];
                    if (row) {
                        var item =form.tblRevenue.getItems(obj.selectedId);
                        var sum = parseFloat(row.incomeValue);
                        form.totalProfit=form.roundToTwo(form.totalProfit-sum);
                        form.tblRevenue.deleteRow(obj.selectedId);
                        form[gridId].refresh();
                    }
                    form.totalProfitFlag=(form.tblCostOfGoodsSolObj.getItems().length+form.tblRevenueObj.getItems().length+ form.tblExpensesObj.getItems().length)>0
                });
            form.btnRevenueAdd.enable();

        },
        view: function () {
            var financialInfoParam = {
                formParams : form.tblExpenses.getSelectedRow()[0]
            };
            form.startModalPageFlowProcess(form.getCurrentProjectSysname() + "/FORMLIB/inputApplication/financialInfo/clientFinancialInfoView", financialInfoParam).then(function (response) {
            });
        }
    };
    var obj = {
        gridId: grId,
        pnlRevenuePanelIsCollapsed : /*true;*/form.inputParams.formParams.revenueListHousehold.length <= 0,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        addNewRow: function () {
            form[gridId].showEditor('add');
            options.clearFields();
            form.btnRevenueAdd.disable();
            obj.pnlRevenuePanelIsCollapsed=false;
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            var selectedRow = form.tblRevenue.getSelectedRow()[0];
            if (form.isFormEditMode == true) {
                options.items = [
                    {caption: gRB('edit'), click: form.tblRevenue.options.edit},
                    {caption: gRB('delete'), click: form.tblRevenue.options.delete}
                ];
            }
            else {
               /* options.items = [
                    {caption: gRB('view'), click: form.tblRevenue.options.view}
                ];*/
            }
        }
    };
    obj.options = options;
    return obj;
})('tblRevenue');

////Cost of Goods Sol
form.tblCostOfGoodsSolObj = (function (grId) {
    var gridId = grId;

    var options = {

        requiredElements : [
            'edGoodsKind',
            'edCost'
        ],
        cancel: function () {
            form[gridId].hideEditor();
            form.btnCostOfGoodsSolAdd.enable();
        },
        save: function () {
            var selectedRow = form.tblCostOfGoodsSol.getSelectedRow()[0];
            var newRow = {
                goodsKind              : options.goodsKind,
                cost                   : options.cost,
                description            : options.description

            };

            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                form[gridId].hideEditor();
                var oldSum=parseFloat(options.oldCost);
                var newSum=parseFloat(options.cost);
                form.totalProfit = form.roundToTwo(form.totalProfit-newSum+oldSum);
                form[gridId].updateRow(obj.selectedId, newRow);
            }
            else {
                newRow['id'] = new Date().getTime();
                form[gridId].hideEditor();
                var sum=parseFloat(options.cost);
                form.totalProfit = form.roundToTwo(form.totalProfit-sum);
                form[gridId].addRow(newRow);
            }
            form.btnCostOfGoodsSolAdd.enable();
            form.totalProfitFlag=(form.tblCostOfGoodsSolObj.getItems().length+form.tblRevenueObj.getItems().length+ form.tblExpensesObj.getItems().length)>0
        },
        clearFields: function () {
            delete options.goodsKind;
            delete options.cost;
            delete options.description;

        },
        edit: function () {
            options.clearFields();
            var selectedRow = form.tblCostOfGoodsSol.getSelectedRow()[0];
            form[gridId].showEditor('edit');
            options.oldCost             = selectedRow["cost"];
            options.goodsKind            = selectedRow['goodsKind'];
            options.cost                = selectedRow['cost'];
            options.description         = selectedRow['description'];

            form.btnCostOfGoodsSolAdd.disable();
        },
        delete: function () {
            form.showRemoveDialog(form,
                    function(){
                        var row = form.tblCostOfGoodsSol.getSelectedRow()[0]
                        if (row) {
                            var sum = parseFloat(row.cost);
                            form.totalProfit=form.roundToTwo(form.totalProfit+sum);
                            form.tblCostOfGoodsSol.deleteRow(obj.selectedId);
                            form[gridId].refresh();

                        }
                        form.totalProfitFlag=(form.tblCostOfGoodsSolObj.getItems().length+form.tblRevenueObj.getItems().length+ form.tblExpensesObj.getItems().length)>0
                    });
            form.btnCostOfGoodsSolAdd.enable();

        },
    };
    var obj = {
        gridId: grId,
        pnlCostOfGoodsSolPanelIsCollapsed : /*true;*/form.inputParams.formParams.costOfGoodsList.length <= 0,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        addNewRow: function () {
            options.clearFields();
            form[gridId].showEditor('add');
            form.btnCostOfGoodsSolAdd.disable();
            obj.pnlCostOfGoodsSolPanelIsCollapsed=false;
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            var selectedRow = form.tblCostOfGoodsSol.getSelectedRow()[0];
            if (form.isFormEditMode == true) {
                options.items = [
                    {caption: gRB('edit'), click: form.tblCostOfGoodsSol.options.edit},
                    {caption: gRB('delete'), click: form.tblCostOfGoodsSol.options.delete}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblCostOfGoodsSol');


/////Expenses
form.tblExpensesObj = (function (grId) {
    var gridId = grId;
    var isExpenseDescription=false;

    var options = {

        requiredElements : [
            "edExpenseType",
            "edExpenseValue"
        ],

        data: {},
        cancel: function () {
            form[gridId].hideEditor();
            form.btnExpensesAdd.enable();
        },
        save: function () {
            var selectedRow = form.tblExpenses.getSelectedRow()[0];
            var newRow = {
                expenseType          : options.expenseType,
                expenseValue         : options.expenseValue,
                expenseDescription   : options.expenseDescription
            };
            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                form[gridId].hideEditor();
                var oldSum=parseFloat(options.expenseValue);
                var newSum=parseFloat(options.oldExpenseValue);
                form.totalProfit = form.roundToTwo(form.totalProfit+newSum-oldSum);
                form[gridId].updateRow(obj.selectedId, newRow);
            }
            else {
                newRow['id'] = new Date().getTime();
                form[gridId].hideEditor();
                var sum=parseFloat(options.expenseValue);
                form.totalProfit = form.roundToTwo(form.totalProfit-sum);
                form[gridId].addRow(newRow);
            }
        //    form.checkClientAddress();
            form.btnExpensesAdd.enable();
            form.totalProfitFlag=(form.tblCostOfGoodsSolObj.getItems().length+form.tblRevenueObj.getItems().length+ form.tblExpensesObj.getItems().length)>0
        },
        clearFields: function () {
            delete options.expenseType;
            delete options.expenseValue;
            delete options.expenseDescription;
        },
        edit: function () {
            form.addAddrMode = 'edit';
            form[gridId].showEditor('edit');
            options.clearFields();
            var selectedRow = form.tblExpenses.getSelectedRow()[0];
            options.oldExpenseValue    = selectedRow["expenseValue"];
            options.expenseType        = selectedRow["expenseType"];
            options.expenseValue       = selectedRow["expenseValue"];
            options.expenseDescription = selectedRow['expenseDescription'];
            form.btnExpensesAdd.disable();
        },
        delete: function () {
            form.showRemoveDialog(form,
                function(){
                    var row = form.tblExpenses.getSelectedRow()[0]
                    if (row) {
                         var sum=parseFloat(row.expenseValue);
                        form.totalProfit=form.roundToTwo(form.totalProfit+sum);
                        form.tblExpenses.deleteRow(obj.selectedId);
                        form[gridId].refresh();

                    }
                    form.totalProfitFlag=(form.tblCostOfGoodsSolObj.getItems().length+form.tblRevenueObj.getItems().length+ form.tblExpensesObj.getItems().length)>0
            });
            form.btnExpensesAdd.enable();

        },
    };
    var obj = {
        pnlExpensesPanelIsCollapsed : /*true;*/form.inputParams.formParams.expensesList.length <= 0,
        gridId: grId,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
            isExpenseDescription=false;
        },
        addNewRow: function () {
            form[gridId].showEditor('add');
            options.clearFields();
            form.btnExpensesAdd.disable();
            obj.pnlExpensesPanelIsCollapsed=false;
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            var selectedRow = form.tblExpenses.getSelectedRow()[0];
            if (form.isFormEditMode == true) {
                options.items = [
                    {caption: gRB('edit'), click: form.tblExpenses.options.edit},
                    {caption: gRB('delete'), click: form.tblExpenses.options.delete}
                ];
            }

        }
    };
    obj.options = options;
    return obj;
})('tblExpenses');
