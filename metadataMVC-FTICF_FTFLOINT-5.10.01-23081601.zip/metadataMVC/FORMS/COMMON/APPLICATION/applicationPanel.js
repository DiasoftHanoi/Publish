/*DSMETA version = "5.10.01-23081601" hash = "d2a6934dc15b9ea5c1ab03c5e853e79fe5562e9a"*/
function registerMethod(initService){
    var service={};
    for (var ar in initService){
        if (initService.hasOwnProperty(ar)){
            if (ar.indexOf('Service')>-1 || typeof (initService[ar]) != 'function'){
                service[ar]=initService[ar];
            }else{
                var fn=initService[ar].toString();
                if (fn && fn.length) {
                    var sIdx=fn.search(/\(/)+1;
                    var eIdx=fn.search(/\)\{/);
                    var args=fn.substring(sIdx,eIdx);
                    eval("service."+ar+"=function("+args+")"+fn.substring(eIdx+1,fn.length));
                }
            }
        }
    }
    return service;
}

service=registerMethod(service);
var nvl=service.nvl;
var gRB = function(key){
    return service.nvl(form.localize[key],key);
};
var inputParams = form.inputParams || {};
form.searchParams = inputParams.searchParams || {};

var outputParams = form.outputParams || {};
outputParams.searchParams = form.searchParams || {};

//Флаг для добавления 'All, except end states' в поле Application status
var flagOnChangeApplicationStatusItems = false;
//Флаг для очистки 'All, except end states' в поле Application status
var flagCallClearSearchParams = false;

form.clearSearchParams = function() {
    if( form.inputParams.searchAppListFlag == true ) {
        //application parameters
        form.applicationType.clearValue("");
        form.applicationNumber.setValue("");
        form.applicationStatus.setValue('All');
        form.creationDate.setValue("last_week");
        form.startDate.setValue(null);
        form.endDate.setValue(null);
        form.nowDate.setValue(null);
        form.searchParams.BRANCHID = undefined;
        form.searchParams.clientExtObjID = undefined;
        var item = form.branchName.getItems();
        for (var i = 0, count = item.length; i < count; i++) {
            if (item[i].DepartmentID == inputParams.USERDEPTID) {
                form.searchParams.BRANCHID = form.inputParams.USERDEPTID;
                break;
            }
        }
        form.createdBy.clearValue("");
        //Customer parameters
        form.customerName.setValue("");
        form.documentType.clearValue();
        form.documentNumber.setValue("");
    }else{
        //application parameters
        form.applicationType.clearValue("");
        form.applicationNumber.setValue("");
        form.applicationStatus.setValue("");
        form.creationDate.clearValue("");
        form.startDate.setValue(null);
        form.endDate.setValue(null);
        form.nowDate.setValue(null);
        form.branchName.clearValue("");
        form.createdBy.clearValue("");
        //Customer parameters
        form.customerName.setValue("");
        form.documentType.clearValue();
        form.documentNumber.setValue("");
        flagCallClearSearchParams = true;
    }
    if (form.btnSearch.errorPanelObj) {
        for (var i = 0; i < form.btnSearch.errorPanelObj.requiredComponents.length; i++)
            form.btnSearch.errorPanelObj.requiredComponents[i].isShowError = false
        form.btnSearch.errorPanelObj.isShowFormErrors = false;
        form.btnSearch.isShowError = false;
    }
};

form.onClickSearch = function () {
        //Application Type
        form.searchParams.ApplicationType = form.searchParams.ApplicationType;
        //Application Number
        form.searchParams.documentNumber = form.applicationNumber.getText();
        //Brunch name
        form.searchParams.BRANCHID = form.searchParams.BRANCHID;
        //Created by
        form.searchParams.CREATEDBY = form.searchParams.CREATEDBY;

        var message = {};
        message.event = 'SEARCH';
        message.params = {};

        /*Application Parameters*/

        //Application Type
        message.params["ApplicationType"] = form.searchParams.ApplicationType;
        //Application number
        message.params["Number"] = form.searchParams.documentNumber;

        message.params['STATE']=form.applicationStatus.getText();
        //Application status
        if(form.applicationStatus.getValue() == 'All') {
            message.params['STATETYPE_NOT_EQUAL'] = 2;
            delete  message.params['STATE'];
        }else{
           delete message.params['STATETYPE_NOT_EQUAL'];

        }
        //Branch name
        message.params["BRANCHID"] = form.searchParams.BRANCHID;
        //Creation Date
        if (form.searchParams.PERIOD == 'date'){
            message.params["CREATIONMINDATE"] = form.searchParams.MINDATE;
        	message.params["CREATIONMAXDATE"] = form.searchParams.MINDATE;
        }else if(form.searchParams.PERIOD == 'period'){
            message.params["CREATIONMINDATE"] = form.searchParams.MINDATE;
            message.params["CREATIONMAXDATE"] = form.searchParams.MAXDATE;
        }
        else if(form.searchParams.PERIOD != undefined) {
            message.params["CREATIONMINDATE"] = form.searchParams.CREATIONMINDATE;
            message.params["CREATIONMAXDATE"] = form.searchParams.CREATIONMAXDATE;
        }
        //Created By
        message.params["CreatedBy"] =  form.searchParams.CREATEDBY;
        //CIF number
        message.params["clientExtObjID"] =  form.searchParams.clientExtObjID;

        /*Customer parameters*/

        //Customer name
        message.params["CurrentName"] = form.searchParams.CurrentName;
        //Document type
        message.params["PERSONDOCTYPE"] =  form.searchParams.IdentityCardTypeBrief;
        //Document number
        message.params["PERSONDOCNUMBER"] =  form.documentNumber.getText();
        form.command(message);
};

form.applicationTypeParams = {
    PARENTSYSNAME: 'loanAppINT',
    CheckRights: "true"
};

form.onShow = function () {
    var items = [];
    items.push({
        NAME : form.getResourceBundle("exceptEndStates"),
        SYSNAME : 'All'
    });
    form.applicationStatus.setItems(items);
    form.enabledBranchName = true;
    //Если переход к списку заявок осуществляется через выбор «Application List»
    if( form.inputParams.searchAppListFlag == true ) {
        form.creationDate.setValue("last_week");
        form.applicationStatus.setValue('All');
        if (inputParams.USERDEPTID){
            var item = form.branchName.getItems();
            for (var i = 0, count = item.length; i < count; i++) {
                if (item[i].DepartmentID == inputParams.USERDEPTID) {
                    form.searchParams.BRANCHID = inputParams.USERDEPTID;
                    break;
                }
            }
            if (!inputParams.rightOrgStructure ) {
                form.enabledBranchName = false;
            }
        }
    }
};

form.applicationStatusParams = {};
form.onChangeApplicationStatus = function () {
    form.applicationStatusParams.OBJECTTYPEID = form.searchParams.ApplicationType;
    if(form.searchParams.ApplicationType==null) {
        var items=[];
        items.push({NAME:form.getResourceBundle("exceptEndStates"), SYSNAME: 'All'});
        form.applicationStatus.setItems(items);
        if (flagCallClearSearchParams == false) {
            form.applicationStatus.setValue('All');
        } else {
            flagCallClearSearchParams = false;
        }
    }else{
        form.applicationStatus.refresh();
        flagOnChangeApplicationStatusItems = true;
    }
};

form.onChangeApplicationStatusItems = function () {
    if (flagOnChangeApplicationStatusItems) {
        flagOnChangeApplicationStatusItems = false;
        var items = form.applicationStatus.items;
        items.push({NAME:form.getResourceBundle("exceptEndStates"), SYSNAME: 'All'});
        form.applicationStatus.setItems(items);
        form.applicationStatus.setValue('All');
    }
    else{
        var isAll=false;
        var list = form.applicationStatus.getItems()
        for (var i = 0, count = list.length; i < count; i++) {
            if (list[i].SYSNAME =='All') {
                isAll=true;
                break;
            }
        }
        if(!isAll) form.applicationStatus.setEmptyValue("All",form.getResourceBundle("exceptEndStates"))
    }
};

form.periodItems = [
    {value:"today", text:gRB("list.calendar.today")},
    {value:"today_yesterday", text:gRB("list.calendar.todayYesterday")},
    {value:"last_week", text:gRB("list.calendar.lastWeek")},
    {value:"last_month", text:gRB("list.calendar.lastMonth")},
    {value:"period", text:gRB("list.calendar.period")},
    {value:"date", text:gRB("list.calendar.date")}
];

form.onChangePeriod = function (item){
	var dateStart = utils.curDateJS();
    var dateEnd = utils.curDateJS();
    switch (item.value){
        case "today":
            dateEnd.setDate(dateEnd.getDate()+1);
            break;
        case "today_yesterday":
            dateStart.setDate(dateEnd.getDate()-1);
            dateEnd.setDate(dateEnd.getDate()+1);
            break;
        case "last_week":
            dateStart.setDate(dateEnd.getDate()-7);
            dateEnd.setDate(dateEnd.getDate()+1);
            break;
        case "this_month":
            dateStart.setMonth(dateEnd.getMonth()-1);
            dateEnd.setDate(dateEnd.getDate()+1);
            break;
    }

	form.searchParams.MINDATE=utils.jsDateToJsonDate(dateStart);
    form.searchParams.MAXDATE=utils.jsDateToJsonDate(dateEnd);

    form.searchParams.CREATIONMINDATE = dateStart;
    form.searchParams.CREATIONMAXDATE = dateEnd;
};
