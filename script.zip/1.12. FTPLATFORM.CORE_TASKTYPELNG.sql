
INSERT INTO CORE_TASKTYPELNG (TASKTYPEID,LOCALE,TASKTYPENAME,DESCRIPTION) 
VALUES
	(5003, 'vi', N'Một bước kiểm soát', N'Một bước kiểm soát'),
	(5004, 'vi', N'Hai bước kiểm soát', N'Hai bước kiểm soát'),
	(2005, 'vi', N'Yêu cầu phát hành thẻ', N'Yêu cầu phát hành thẻ'),
	(3006, 'vi', N'Xử lý Lead', N'Xử lý Lead'),
	(2045, 'vi', N'Phê duyệt phát hành thẻ', N'Phê duyệt phát hành thẻ'),
	(2034, 'vi', N'Tái thẩm định đánh giá hồ sơ', N'Tái thẩm định đánh giá hồ sơ'),
	(7003, 'vi', N'Tái thẩm định đánh giá hồ sơ (hồ sơ trình lại)', N'Tái thẩm định đánh giá hồ sơ (hồ sơ trình lại)');
