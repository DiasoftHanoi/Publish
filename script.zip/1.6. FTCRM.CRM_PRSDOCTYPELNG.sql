insert into CRM_PRSDOCTYPELNG (PERSONDOCTYPEID, NAME, DESCRIPTION, LOCALE)
select PERSONDOCTYPEID, NAME, DESCRIPTION, case LOCALE
	when 'en' then 'vi' end as LOCALE 
	from CRM_PRSDOCTYPELNG where LOCALE in ('en') 
	and PERSONDOCTYPEID in (select PERSONDOCTYPEID from CRM_PERSONDOCTYPE 
			where [SYSNAME] in ('nationalID12', 'nationalIDPolice', 'nationalIDArmy'));