insert into DOC_DOCPARTLINKLNG (DOCPARTLINKID, LINKNAME, LINKDESCRIPTION, LOCALE)
select 
	DOCPARTLINKID, case LINKNAME
	when 'Customer' then N'Khách hàng' 
	when 'Borrower' then N'Tên khách hàng vay' 
	when 'Co-borrower' then N'Tên người đồng vay' 
	when 'Guarantor' then N'Người bảo lãnh' 
	when 'Guaranter' then N'Người bảo lãnh' 
	when 'Pledgor (Individual)' then N'Chủ tài sản' 
	when 'Pledgor (Company)' then N'Chủ tài sản' 
	end as LINKNAME, LINKDESCRIPTION, 
	case LOCALE
	when 'en' then 'vi' end as LOCALE 
from DOC_DOCPARTLINKLNG 
where LOCALE in ('en') 
	and LINKNAME in ('Customer', 'Borrower', 'Co-borrower', 'Guarantor', 'Pledgor (Individual)', 'Pledgor (Company)');