/* global form, service */
function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;
form.isShowCode=form.formParams.CODE!==''?true:false;
var outputParams = form.outputParams || {};
outputParams.formParams = form.formParams;
var lgr = service.lgr;
var nvl = service.nvl;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.isFormEditMode = form.inputParams.EDITMODE || false;

form.templateData = {
    inputParams: form.inputParams,
    parentForm: form
};

form.settings = {
    cbDivisionRiskValuation:JSON.stringify( {
        ReferenceSysName: 'divisionRiskValuationLOS',
        ORDERBY: 'ReferenceItemID'
    }),
    cbControlMethod:JSON.stringify( {
        ReferenceSysName: 'controlMethodLOS',
        ORDERBY: 'ReferenceItemID'
    }),
    chooseAUserIDFields:  [
        {
            value: "USERLOGIN",
            caption: "Login",
            width: 3
        },
        {
            value: "EMPLOYEENAME",
            caption: "Name",
            width: 9
        }
    ],
    chooseAUserIDMethodParams: {},
    decisionName: ''
};

form.onShow = function () {
    form.onChangeDecision();
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
};

form.onChangeDecision = function(){
    var RoleSysName = '';
    var GROUPID = '';
    var DepartmentIDList = form.inputParams.DepartmentIDList || [];
    var paramMap = {};
    form.settings.decisionName = undefined;
    form.formParams.CURRENTUSERID = undefined;
    if (form.inputParams.decisionNameMap && Object.keys(form.inputParams.decisionNameMap).length && form.formParams.approverLevelUnderwriterSysName) {
        form.settings.decisionName = form.inputParams.decisionNameMap.hasOwnProperty(form.formParams.approverLevelUnderwriterSysName) ? angular.copy(form.formParams.approverLevelUnderwriterSysName) : undefined;
        var currentDecisionMap = form.inputParams.decisionNameMap[form.formParams.approverLevelUnderwriterSysName] || {};
        if (currentDecisionMap && Object.keys(currentDecisionMap).length) {
            RoleSysName = currentDecisionMap['employeeRoleSysName'] || '';
            if (RoleSysName) {
                paramMap["RoleSysName"] = RoleSysName;
            }
            if (form.inputParams.userGroupMap && Object.keys(form.inputParams.userGroupMap).length) {
                GROUPID = form.inputParams.userGroupMap[currentDecisionMap['employeeGroupName']] || '';
                if (GROUPID) {
                    paramMap["GROUPID"] = GROUPID;
                }
            }
        }
        if (DepartmentIDList && DepartmentIDList.length) {
            paramMap["DepartmentIDList"] = DepartmentIDList;
        }
    }
    form.settings.chooseAUserIDMethodParams = JSON.stringify(paramMap);
    if (form.cbApprover) {
        form.cbApprover.refresh();
    }
};

form.executeCommand = function (msg) {
    switch (msg.event) {
        case 'FAB_NAVIGATOR_NAVIGATE':
            outputParams.NEXTPAGE = msg.params.step;
            form.action('DIRECT');
        break;
        default:
            break;
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var save =  form['save'];

        if (form.validateControlsByIds('*', showFlag === true ? save : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.yesFunc = function() {
    outputParams.TRANSTYPE = 'SAVEDRAFT';
    if (form.verifyForm()) {
        form.sendForm('GO', false);
    }
};

form.GetIncomeListText=function(value){
    var str="fieldCheck."+value;
    return form.getResourceBundle(str);
};
form.getRefSysNameText= function(value){
    for(var i=0;i<form.formParams.stageResultDecisionItems.length;i++){
        var itm = form.formParams.stageResultDecisionItems[i];
        if(itm["value"]==value){
             return itm["text"];
        }
    }
    return null;
};
form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    if(form.isFormEditMode==='true'){
        form.formParams.divisionRiskValuation=form.cbDivisionRiskValuation.getText();
        form.formParams.divisionRiskValuationSysName=form.cbDivisionRiskValuation.getValue();
        form.formParams.controlMethod=form.cbControlMethod ? form.cbControlMethod.getText() : "";
        form.formParams.controlMethodSysName=form.cbControlMethod ? form.cbControlMethod.getValue() : "";
        for (var i=0; i<form.formParams.chooseApproverLevelItems.length;i++){
            var item=form.formParams.chooseApproverLevelItems[i];
            if(item["value"]==form.formParams.approverLevelUnderwriterSysName){
                form.formParams.approverLevelUnderwriter = item["text"];
                break;
            }
        }
        if(form.formParams.approverLevelUnderwriterSysName===form.settings.decisionName){
            form.formParams.ApproverFullName = form.cbApprover.getText();
            form.formParams.CURRENTUSERID = form.cbApprover.getValue();
        }
    }

    if (tagName === 'CLOSE') {
        if(form.isFormEditMode === 'false'){
            form.sendForm('GO',false);
        }else{
            service.showDialogCancelConfirm(
                form,
                form.yesFunc
            )
        }
    } else {
        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};
