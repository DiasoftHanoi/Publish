/* global form, service */

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;

var outputParams = form.outputParams || {};
outputParams.formParams = form.formParams;

var lgr = service.lgr;
var nvl = service.nvl;
var strToNum = service.strToNum;

lgr(inputParams);

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.isCompanyNotInList = false;
form.isAssessmentNeed = true;

form.getMinAssessmentDate = function () {
    var date = new Date();
    date.setMonth(date.getMonth() - 6);
    //return service.convertDate(date);
    form.clAssessmentDate.setMinDate(service.convertDate(date));

};

form.getMaxAssessmentDate = function () {
    var date = new Date();
    return service.convertDate(date);
};

form.onShow = function () {
    form.getMinAssessmentDate();
    form.rulePresenceEvaluationReport();
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
};

form.requiredElements = [
    'cbEstimatedCompanyType',
    'edCompanyName',
    'clAssessmentDate',
    'rbAssessmentNeed',
    'rbCalcCheck',
    'edEstimatedCost',
    'edEstimatedCompanyInn',
    'edCompanyNameInn'
];

form.checkTime = function () {
    var time = form.formParams.AssessmentTime;
    if (time != undefined) {
        if (time.length > 1) {
            if (time.substring(0, 2) > 23) {
                form.edAssessmentTime.setValue("");
            }
        }
        if (time.length > 2) {
            if (time.substring(2, 4) > 59) {
                form.edAssessmentTime.setValue("");
            }
        }
    }
}

form.rulePresenceEvaluationReport = function(){
    var result = 0;
    var rulePresenceEvaluationReportParams = form.formParams.rulePresenceEvaluationReportParams || {};
    rulePresenceEvaluationReportParams.checkResultCostCalculator = form.formParams.checkResultCostCalculator;
    var params={
        SYSNAME: "rulePresenceEvaluationReport",
        RULEPARAMS: rulePresenceEvaluationReportParams || {},
        ReturnAsHashMap: true
    };
    form.dsCall('[dmsws]','ruleResult',params).then(function (res){
        if (res && res.data && res.data.RULERESULT >= 1){
            result = 1;
        }

        if (result == 0) {
            form.formParams.AssessmentNeed = 'Требуется';
            form.isAssessmentNeed = true;
        } else {
            form.formParams.AssessmentNeed = 'Не требуется';
            form.isAssessmentNeed = false;
        }
    });
};

form.onExitEstimatedCost = function (value) {
    var LTV = 100 * strToNum(form.formParams.creditAmount) / strToNum(value);
    if (LTV > strToNum(form.formParams.StandardLTV) &&  strToNum(value) > 0) {
        var message = "Значение К/З составляет " + service.formatAmount(strToNum(LTV), 2) + "% и превышает нормативное значение, установленное в размере " + service.formatAmount(strToNum(form.formParams.StandardLTV), 2) + "%";
        form.showInformationDialog(message, function (){}, [{caption: 'OK'}]);
    }
};

form.settings = {
    cmCheck_items: [{
        value: 'Положительный',
        text: 'Положительный'
    }, {
        value: 'Отрицательный',
        text: 'Отрицательный'
    }
    ],

    cmAssessmentNeed_items: [{
        value: 'Требуется',
        text: 'Требуется'
    }, {
        value: 'Не требуется',
        text: 'Не требуется'
    }
    ]
};

form.EstimatedCompanyTypeParams = {
    ReferenceGroupName: 'Общие',
    ReferenceName: 'Тип оценочной компании'
};

form.executeCommand = function (msg) {
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE') {
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};

form.estimatedCompanyTypeChange = function () {
   if(form.formParams.EstimatedCompanyTypeValue && form.formParams.EstimatedCompanyTypeValue.toLowerCase() == 'не рок'){
       form.EstimatedCompanyLegalID = form.formParams.EstimatedCompanyLegalID;
       delete form.formParams.EstimatedCompanyLegalID;
   }else{
       form.formParams.EstimatedCompanyLegalID = form.EstimatedCompanyLegalID;
   }
};

form.companySearch = function () {
    service.showModalWindow(form,
        'COMMON/CLIENT/clientSelect',
        {ShowSelector: false, EnableFtseSearch: true, STATE: 'ACTIVE', isAppraisalCompany: true, EXTENDED_PartnerType: "partnerType_appraisalCompany", SearchTemplateSysName: 'PartnerFuzzySearchActualByParam', extINN:'1', isLegal: true},
        function (result) {
            if (typeof result != 'undefined' && result.SELECT_RESULT == 'OK') {
                form.formParams.CompanyNameInn = result._CLIENT_NAME + ", " + result._CLIENT_INN;
                form.formParams.CompanyName = result._CLIENT_NAME;
                form.formParams.EstimatedCompanyInn = result._CLIENT_INN;
                form.formParams.EstimatedCompanyLegalID = result.LegalID;
            }
        }
    );
};

form.verifyForm = function (showFlag) {
    var verified = true;

    try {
        var btnNext =  form['btnNext'] ? 'btnNext' : 'btnSave';
        if (form.validateControlsByIds('*', showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    outputParams.VERIFIED = true;

    if (!form.verifyForm(tagName === 'NEXT' ? true : false) && tagName === 'NEXT') {
        return;
    }
    if (tagName === 'CLOSE') {
        service.showDialogCancelConfirm(form, form.yesFunc);
    } else {
        form.sendForm('GO', false);
    }
};

form.yesFunc = function () {
    form.outputParams.TRANSTYPE = 'SAVEDRAFT';
    form.outputParams.skipTransferState = true;
    form.verifyForm(false);
    form.sendForm('GO', false);
};


form.checkINNValid = function(val,fieldName){

    var innVal = nvl(form.formParams[val],'').trim();
    if (innVal+''!=''){
        if (innVal.length < 10) {
            return form.getResourceBundle('minINNLength')
        }
        if (form[fieldName] && form.formParams[val] != undefined && form.formParams[val].length >= 10 && form.formParams[val].length <= 12 || form.formParams[val].length < 10) {
            if (form[fieldName].getValue() != null && !service.checkINN(form[fieldName].getValue())) {
                return form.getResourceBundle('invalidINN')
            } else {
                return ''
            }
        }
    } else {
        return ''
    }

};