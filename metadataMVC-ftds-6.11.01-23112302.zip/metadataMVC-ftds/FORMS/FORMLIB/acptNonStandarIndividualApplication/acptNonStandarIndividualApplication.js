/* global form, service */

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;

var outputParams = form.outputParams || {}
outputParams.formParams = form.formParams;

var lgr = service.lgr;
var nvl = service.nvl;

var editModeFlag = (inputParams.EDITMODE == 'YES') || (inputParams.EDITMODE == 'true');

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.applicationTypeItems =[];
form.applicationTypeItem = {
    text: form.formParams.substandartTypeText,
    value: form.formParams.substandartType || form.formParams.substandartTypeText
};
form.applicationTypeItems.push(form.applicationTypeItem);

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
    form.substandartTypeText.setValue(form.applicationTypeItem.value);
};

form.executeCommand = function(msg){
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;

    if (!editModeFlag){
        outputParams.VERIFIED = inputParams.VERIFIED;
        return verified;
    }

    try {
        var pressBtn =  (form.formParams.REFSYSNAME == 'reject') ? form.formParams.REFSYSNAME : '';
        if (form.validateControlsByIds('*', showFlag === true ? pressBtn : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {lgr(e);
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }

 /*   try {
        var btnNext =  form['btnNext'] ? 'btnNext' : 'btnSave';
        if (form.validateControlsByIds('*', showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {lgr(e);
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }*/
    outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tagName, acptSubstandartFlag) {
    //collect data
    var comment = form.formParams.comment || [];
    var date = new Date().toISOString();
    comment.add({
        commentatorID:form.inputParams.EMPLOYEEID,
        commentatorName:form.inputParams.USERFIO,
        date:date,
        text:form.formParams.acptComment,
        type:'acptNonStandarIndividualApplication',
        visible:null
    });
    form.formParams.comment = comment;

    /////////////
    outputParams.TRANSTYPE = tagName;

    if (tagName === 'CLOSE') {
        form.outputParams.TRANSTYPE = 'CLOSE';
        form.outputParams.EXIT_TYPE = "CLOSE";
        form.sendForm('CANCEL', false);
    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};


form.makeDecision = function (refItem) {
    form.formParams.REFSYSNAME = refItem.refItem.REFSYSNAME;
    form.formParams.DECISION = refItem.refItem.REFNAME;
    //for method
    outputParams.STAGERESULT = form.formParams.DECISION;
    outputParams.REFSYSNAME =form.formParams.REFSYSNAME;
    outputParams.STAGEDETAILS = form.formParams.acptComment;
    outputParams.STAGEDATE = new Date();
    ////////////
    if (refItem.refItem.REFSYSNAME == 'reject') {
        form.formParams.acptSubstandartFlag = false;
    } else if (refItem.refItem.REFSYSNAME == 'approve') {
        form.formParams.acptSubstandartFlag = true;
    }
    form.acptComment.required = (refItem.refItem.REFSYSNAME == 'reject');
    form.verifyForm(true);
    form.action('NEXT');
};

form.decisionRefItems = (function (decisionRefItems) {
    var items = [];
    var decisionRefItems = form.inputParams.formParams.DecisionRefList;
    for (var i = 0; i<decisionRefItems.length; i++){
        items.push({
            caption: decisionRefItems[i]['REFNAME'],
            refItem: decisionRefItems[i],
            click: function () {
                form.makeDecision(this.refItem);
            }
        })
    }
    return items;
})(nvl(inputParams.DecisionRefList, []));
