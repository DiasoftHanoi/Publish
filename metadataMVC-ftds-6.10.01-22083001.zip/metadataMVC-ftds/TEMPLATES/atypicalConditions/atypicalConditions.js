template.formParams = template.data;

if(template.formParams.nonStandartConditionsList && template.formParams.nonStandartConditionsList.length > 0){
    var idList = {};
    for(var el = 0, size = template.formParams.nonStandartConditionsList.length; el < size; el++){
        if(idList[template.formParams.nonStandartConditionsList[el].id]){
            template.formParams.nonStandartConditionsList[el].id = new Date().getTime();
        }
        idList[template.formParams.nonStandartConditionsList[el].id] = true;
    }
}

template.tabAtypicalConditionObj = (function (grId) {
    var gridId = grId;
    var options = {
        cbKindParams: {
            ReferenceSysName: 'ConditionKind',
            ORDERBY: 'ReferenceItemID'
        },
        fieldsCaption: {},
        cancel: function () {
            template[gridId].hideEditor();
            template.addButtonAtypicalCondition.enable();
        },
        onChangeType: function (item) {
            if (item){
                options.NEEDCOMMENT = item.NEEDCOMMENT;
            } else {
                delete options.NEEDCOMMENT;
            }
            if (!options.NEEDCOMMENT){
                delete options.comment;
            }
        },
        save: function () {
            var selectedRow = template.tabAtypicalCondition.getSelectedRow()[0];
            var newRow = {
                kind: options.kind,
                kindText: template.cbKind.getText(),
                type: options.type,
                typeText: template.cbType.getText(),
                subjectType: form.getResourceBundle('PARTLINKTYPE.mortgageLoanApp'),
                subjectFIO: (template.formParams.clientLastName || '') + ' '+(template.formParams.clientFirstName || '') + ' '+ (template.formParams.clientMiddleName || ''),
                definitionMode: 'HAND',
                comment: options.comment,
                DOCUMENTID: template.formParams.DOCUMENTID
            };
            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                template[gridId].hideEditor();
				template[gridId].updateRow(obj.selectedId, newRow);
            } else {
                newRow['id'] = new Date().getTime();
                template[gridId].hideEditor();
                template[gridId].addRow(newRow);
                template[gridId].refresh();
            }
            template.addButtonAtypicalCondition.enable();
        },
        clearFields: function () {
            delete options.kind;
            delete options.type;
            delete options.comment;
            delete options.NEEDCOMMENT;
        },
        edit: function () {
            options.clearFields();
            var selectedRow = template.tabAtypicalCondition.getSelectedRow()[0];
            template[gridId].showEditor('edit');
            options.kind = selectedRow['kind'];
            options.type = selectedRow['type'];
            options.comment = selectedRow['comment'];
            template.addButtonAtypicalCondition.disable();
        },
        delete: function () {
            if (template.tabAtypicalCondition.getSelectedRow()[0]) {
                template.tabAtypicalCondition.deleteRow(obj.selectedId);
                template[gridId].refresh();
            }
            template.addButtonAtypicalCondition.enable();
        },
        onChangeKind : function () {
            delete options.type;
        }
    };

    var obj = {
        gridId: grId,
        refresh: function () {
            template[gridId].refresh();
        },
        onChangeItems: function () {
            template.formParams.nonStandartConditionsList = template.tabAtypicalCondition.getItems();
        },
        addNewAtypicalConditionRow: function () {
            template[gridId].showEditor('add');
            options.clearFields();
            template.addButtonAtypicalCondition.disable();
        },
        setItems: function (items) {
            template[gridId].setItems(items);
        },
        getItems: function () {
            return template[gridId].getItems();
        },
        onSelectRow: function () {
            var selRow = template[gridId].getSelectedRow()[0] || {};
            options.items = [];
            if (selRow.definitionMode != 'AUTO'){
                options.items = [
                    {
                        caption: form.getResourceBundle('atypicalConditions.btnEdit'),
                        click: template.tabAtypicalCondition.options.edit
                    },
                    {
                        caption: form.getResourceBundle('atypicalConditions.btnDel'),
                        click: template.tabAtypicalCondition.options.delete
                    }
                ];
            }
        }
    };

    obj.options = options;
    return obj;
})('tabAtypicalCondition');