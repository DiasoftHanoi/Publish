/* global form, service */


var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;
var outputParams = form.outputParams || {};
outputParams.formParams = form.formParams;
form.notData = 'нет данных';
var strToNum = service.strToNum;
form.strToNum = service.strToNum;

var lgr = service.lgr;
var nvl = service.nvl;

var editModeFlag = (inputParams.EDITMODE == 'YES') || (inputParams.EDITMODE == 'true');

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.formParams.advanceAppFlag = (form.formParams.advanceAppFlag == true) ? "Да" : "Нет"; 

form.getLevelMpr = function(n) {
    form.dsCall('[refws]','dsReferenceItemBrowseListByParam',{ReferenceSysName:'AutoLoanLevelMpr'}).then(function(response) {
        var data = response.data.Result || []
        form.levelMprItems = data;
        if (form.inputParams.formParams){
            var levelMpr = '';
            var iter = n || 0;
            if (form.formParams.substandartType == 'NonStandard'){
                iter = 5
            }
            if (form.formParams.substandartType == 'Individual'){
                iter = 6
            }
            for (var j = 0;j<form.levelMprItems.length;j++){
                var refiter = form.levelMprItems[j].ReferenceItemCode;
                if (refiter+'' == iter+''){
                    levelMpr = form.levelMprItems[j].ReferenceItemBrief;
                }
            }
        };
        form.formParams.levelMpr = levelMpr;
    });
};

form.onShow = function () {
    /*service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });*/
    if (form.formParams.CalcBasis == "" || form.formParams.Score == "" || form.formParams.DTI == "")
        form.getScoringList();
    if (form.tabAtypicalConditions) form.tabAtypicalConditions.setItems(form.formParams.nonStandartConditionsList || []);
    form.getSelectedAlternative();
};

form.executeCommand = function (msg) {
    //form.sendForm(msg.event);
    switch (msg.event) {
        case 'appParticipants':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/loanApp/autoLoanApp/decisionRM/appParticipantsAuto", {
                APPLICATIONID: form.formParams.DOCUMENTID,
                isLoanOfficerRole: false,
                isDecisionView: true
            });
            break;                
        case 'relatedBorrGroup':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/loanApp/autoLoanApp/decisionRM/relatedBorrGroupAuto", {
                APPLICATIONID: form.formParams.DOCUMENTID
            });
            break;
        case 'processingStage':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/loanApp/autoLoanApp/decisionRM/processingStageAuto", {
                APPLICATIONID: form.formParams.DOCUMENTID
            });
            break;
        case 'attachedDocuments':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/loanApp/autoLoanApp/decisionRM/attachedDocumentsAuto", {
                APPLICATIONID: form.formParams.DOCUMENTID
            });
            break;
        case 'linkedDocuments':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/COMMON/APPLICATION/LINKEDAPP/applicationLinked_autoRM", {
                APPLICATIONID: form.formParams.DOCUMENTID
            });
            break;
        case 'reports':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/loanApp/autoLoanApp/decisionRM/reportsAuto", {
                APPLICATIONID: form.formParams.DOCUMENTID
            });
            break;
        case 'analysisResult':
            form.startNewPageFlowProcess(form.getResourceBundle("analysisResult.pageHeader"), "FTFLOANSMVC/COMMON/APPLICATION/applicationAnalysisResult", {
                APPLICATIONID: form.formParams.DOCUMENTID,
                PAGEHEADER: form.getResourceBundle("analysisResult.pageHeader")
            });
            break;
        case 'viewPledge':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/loanApp/autoLoanApp/inputPledgeData/inputPledgeAuto", {
                APPLICATIONID: form.formParams.DOCUMENTID,
                isDecisionView: true
            });
            break;  
        case 'viewMatrixOffers':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/loanApp/autoLoanApp/matrixSolutions/matrixSolutions", {
                APPLICATIONID: form.formParams.DOCUMENTID,
                isDecisionView: true
            });
            break;
        case 'ApplicationComment':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/loanApp/autoLoanApp/decisionRM/ApplicationCommentAuto", {
                APPLICATIONID: form.formParams.DOCUMENTID
            });
            break;

            
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;

    if (!form.editModeFlag){
        outputParams.VERIFIED = inputParams.VERIFIED;
        return verified;
    }

    try {
        var btnNext =  form['btnNext'] ? 'btnNext' : 'btnSave';
        if (form.validateControlsByIds('*', showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {lgr(e);
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tag) {
    if (tag == "NEXT") {
        if (!form.verifyForm(false)) {
            return;
        }
        form.outputParams.EXIT_TYPE = 'SAVE';
        form.saveComment();
        form.sendForm(tag, false);
    } else {
        form.outputParams.EXIT_TYPE = 'CLOSE';
        form.sendForm(tag, false);
    }
};

form.templateData = {
    formParams: form.formParams,
    inputParams: form.inputParams,
    parentForm: form,
    isAutoFlag: true
};

form.onChangeDecisionType = function (value) {
    if (form.rbDecisionType.value != null) {
        form.bNext.enabled = true;
    }
    if (value == "negative" || value == "decline" || value == "cancel") {
        form.formSettings.isShowRefuseReason = true;
    } else {
        form.formSettings.isShowRefuseReason = false;
    }
form.getDECISIONSTAGEID();
};

form.formSettings = {
    DECISIONTYPE_ITEMS: form.inputParams.decisionItems,
    /*[
     {value: 'positive', text: 'Положительное'},
     {value: 'negative', text: 'Отрицательное'},
     {value: 'torework', text: 'Вернуть на доработку'}
     ],*/
    isShowRefuseReason: false
};
form.REFUSEREASON_ITEMS = form.inputParams.reasonListNew;

form.showInfo = function (type) {
    var informationTemplate = type == "product" ? form.formParams.informationTemplateProduct : form.formParams.informationTemplateProgram; 
    form.startProcess('FTFLOANSMVC/ADMIN/REPORTBOOK/getProductInfo',
                {
                    reportParams: {informationTemplate : informationTemplate}
                },
                function (p) {
                    if (!p['ErrorMessage']) {
                        form.startModalPageFlowProcess('FTFLOANSMVC/COMMON/APPLICATION/viewReports', p);
                    }
                }
        );
};

form.getScoringList = function(){
    var ObjID = Number(form.formParams.DOCUMENTID);
    form.dsCall('[dmsws]','decisionStageGetListByParams',{STAGESYSNAME:"scoringDecision",ReturnAsHashMap:true}).then(function (response){
        var DECISIONSTAGEID = response.data.DECISIONSTAGEID;
        form.DECISIONSTAGEID = DECISIONSTAGEID;
        if (DECISIONSTAGEID){
            form.dsCall('[dmsws]','decisionGetListByParams',{OBJECTID:ObjID,DECISIONSTAGEID:DECISIONSTAGEID,ORDERBY:'DECISIONDATE DESC',ReturnAsHashMap:true}).then(function (responseScoring){
                var ScoringList  = responseScoring.data;
                form.ScoringList = ScoringList;
                var AppDecision  = form.ScoringList.AppDecision[0]||{};
                var ProductClientDecision = AppDecision.ProductClientDecision[0]||{};
                var DecisionDetailsAuto = AppDecision.DecisionDetailsAuto[0] ||{};
                if (form.formParams.CalcBasis == ""){
                    form.formParams.CalcBasis = AppDecision.CalcBasis;
                }
                if (form.formParams.Score == ""){
                    form.formParams.Score = ProductClientDecision.Score;
                }
                if (form.formParams.DTI == ""){
                    form.formParams.DTI = ProductClientDecision.DTI;
                }
                if (form.formParams.monthlyPayment == ""){
                    form.formParams.monthlyPayment = DecisionDetailsAuto.MaxMonthlyPayment;
                }
                var LevelCompetenceRM = DecisionDetailsAuto.LevelCompetenceRM||0 
                form.getLevelMpr(LevelCompetenceRM);
            });
        }
    }); 
}
// Временное решение по задачам 2274635 и 2274298 пока дорабатывается интеграция
form.getDECISIONSTAGEID = function(){ 
    if (form.formParams.rbDecisionType == 'approve'||form.formParams.rbDecisionType == 'cancel'){
       form.formParams.STAGESYSNAME = 'makeDecisionLPR';
    } else {
        form.formParams.STAGESYSNAME = form.inputParams.formParams.STAGESYSNAME;
    }
    form.dsCall('[dmsws]','decisionStageGetListByParams',{STAGESYSNAME:form.formParams.STAGESYSNAME,ReturnAsHashMap:true,OBJECTTYPEID:form.formParams.DOCUMENTTYPE}).then(
        function(response){
            form.formParams.DECISIONSTAGEID = response.data.DECISIONSTAGEID || 0;
            form.formParams.DECISIONTERM = response.data.DECISIONTERM || 0;
        }
)};

form.saveComment = function(){
    var comment = form.formParams.comment ||[];
    var DETAILS = form.mComment.value || '';
    if (DETAILS+'' !== ''){
        var date = new Date().toISOString();
        comment.add({
            commentatorID:form.inputParams.EMPLOYEEID,
            commentatorName:form.inputParams.USERFIO,
            date:date,
            text:DETAILS,
            visible:null
        });
        var params = {
            DOCUMENTID : form.formParams.DOCUMENTID,
            comment : form.formParams.comment
        };

        form.dsCall('[frontws2]', 'documentModifyOld', params).then(function (response) {
            if (response && response.data && response.data.Result) {
                var p = response.data.Result.DOCUMENTID;
                if (p) {
                }
                else {
                    console.log(response);
                    form.showErrorDialog(form.getResourceBundle("decisionMakingRM.saveCommError")+".", function () {
                    }, [{caption: 'ОК'}]);
                }
            }
        });
    }
};

form.getNewMonthlyPayment = function(){
var prdMap = {Limit:form.formParams.creditAmount, InterestRate:form.formParams.totalInterestRate,loanTerm:form.formParams.creditTerm}
var formulaSysName = 'matrixAutoMp';
if (form.formParams.leftPaymentFlag+'true'=='true'){
formulaSysName = 'matrixAutoMpWithLeftForAmountStrategy';
}
form.startProcess('FTFLOANSMVC/FORMLIB/matrixOffers/getFormulaResult', {
        prdMap: prdMap
       ,formulaSysName: formulaSysName
    }, function(){},true).then(function (response) {       
        form.formulaResult = response.formulaResult;
        form.formParams.monthlyPayment = form.formulaResult;
    }); 
}

form.getSelectedAlternative = function(){
    if (form.formParams.AlternativeProduct && form.formParams.AlternativeProduct.length>0){
        var AlternativeProductList = form.formParams.AlternativeProduct || [];
        for (var j=0;j<AlternativeProductList.length;j++){
            var AlternativeProductMap = AlternativeProductList[j];
            var isSelected = AlternativeProductMap.isSelected+'' || 'false';
            if (isSelected+'' == 'true'){
                if (AlternativeProductMap.CreditAmount && AlternativeProductMap.CreditAmount != 0){
                    form.formParams.creditAmount = AlternativeProductMap.CreditAmount;
                }
                if (AlternativeProductMap.CreditTerm && AlternativeProductMap.CreditTerm != 0){
                    form.formParams.creditTerm = AlternativeProductMap.CreditTerm;
                }
                if (AlternativeProductMap.FinalRate && AlternativeProductMap.FinalRate != 0){
                    form.formParams.totalInterestRate = AlternativeProductMap.FinalRate;
                }
                if (AlternativeProductMap.MaxCreditAmount && AlternativeProductMap.MaxCreditAmount != 0){
                    form.formParams.maxCreditAmountCC = AlternativeProductMap.MaxLimit;
                }
                if (AlternativeProductMap.MaxLimit && AlternativeProductMap.MaxLimit != 0){
                    form.formParams.DecisionDetailsBeginOfAmtRange = AlternativeProductMap.MaxCreditAmount;
                }
		if (AlternativeProductMap.PRODUCTNAME && AlternativeProductMap.PRODUCTNAME != ""){
                    form.formParams.product = AlternativeProductMap.PRODUCTNAME;
                }
		if (AlternativeProductMap.ProgramName && AlternativeProductMap.ProgramName != ""){
                    form.formParams.program = AlternativeProductMap.ProgramName;
                }
                if (AlternativeProductMap.informationTemplate && AlternativeProductMap.informationTemplate != ""){
                    form.formParams.informationTemplateProgram = AlternativeProductMap.informationTemplate;
                }
                if (AlternativeProductMap.leftPaymentFlag && AlternativeProductMap.leftPaymentFlag+"" != ""){
                    form.formParams.leftPaymentFlag = AlternativeProductMap.leftPaymentFlag || false;
                }
                if (AlternativeProductMap.MonthlyPayment && AlternativeProductMap.MonthlyPayment != 0){
                    form.getNewMonthlyPayment();                    
                }
            }
        }
    };
};