/* global form */

form.onClickPage = function (item) {
    if (item.sysname) {
        if (item.pageflowAction){
            form.startNewPageFlowProcess(item.caption, item.pageflowAction, {
                APPLICATIONID: form.inputParams.APPLICATIONID
            });
            return;
        }
        form.command({
            event: item.sysname,
            caption: item.caption
        });
    }
};