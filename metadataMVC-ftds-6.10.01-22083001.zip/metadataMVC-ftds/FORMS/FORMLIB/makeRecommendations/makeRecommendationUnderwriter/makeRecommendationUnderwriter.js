debugger;
/* global form, service */
function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;
form.isShowCode=form.formParams.CODE!==''?true:false;
var outputParams = form.outputParams || {};
outputParams.formParams = form.formParams;
var lgr = service.lgr;
var nvl = service.nvl;
var gRB = service.gRB;
var gRBT = service.gRBT;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.isFormEditMode = form.inputParams.EDITMODE || false;

form.templateData = {
    inputParams: form.inputParams,
    parentForm: form
};

form.settings = {
    cbDivisionRiskValuation:JSON.stringify( {
        ReferenceSysName: 'divisionRiskValuationLOS',
        ORDERBY: 'ReferenceItemID'
    }),
    cbControlMethod:JSON.stringify( {
        ReferenceSysName: 'controlMethodLOS',
        ORDERBY: 'ReferenceItemID'
    }),
    chooseAUserIDFields:  [
        {
            value: "USERLOGIN",
            caption: "Login",
            width: 3
        },
        {
            value: "EMPLOYEENAME",
            caption: "Name",
            width: 9
        }
    ],
    chooseAUserIDMethodParams: {},
    decisionName: ''
};

form.onShow = function () {
    form.onChangeDecision();
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
};

form.onChangeDecision = function(){
    var RoleSysName = '';
    var GROUPID = '';
    var DepartmentIDList = form.inputParams.DepartmentIDList || [];
    var paramMap = {};
    form.settings.decisionName = undefined;
    form.formParams.CURRENTUSERID = undefined;
    if (form.inputParams.decisionNameMap && Object.keys(form.inputParams.decisionNameMap).length && form.formParams.approverLevelUnderwriterSysName) {
        form.settings.decisionName = form.inputParams.decisionNameMap.hasOwnProperty(form.formParams.approverLevelUnderwriterSysName) ? angular.copy(form.formParams.approverLevelUnderwriterSysName) : undefined;
        var currentDecisionMap = form.inputParams.decisionNameMap[form.formParams.approverLevelUnderwriterSysName] || {};
        if (currentDecisionMap && Object.keys(currentDecisionMap).length) {
            RoleSysName = currentDecisionMap['employeeRoleSysName'] || '';
            if (RoleSysName) {
                paramMap["RoleSysName"] = RoleSysName;
            }
            if (form.inputParams.userGroupMap && Object.keys(form.inputParams.userGroupMap).length) {
                GROUPID = form.inputParams.userGroupMap[currentDecisionMap['employeeGroupName']] || '';
                if (GROUPID) {
                    paramMap["GROUPID"] = GROUPID;
                }
            }
        }
        if (DepartmentIDList && DepartmentIDList.length) {
            paramMap["DepartmentIDList"] = DepartmentIDList;
        }
    }
    form.settings.chooseAUserIDMethodParams = JSON.stringify(paramMap);
    if (form.cbApprover) {
        form.cbApprover.refresh();
    }
};

form.executeCommand = function (msg) {
    switch (msg.event) {
        case 'FAB_NAVIGATOR_NAVIGATE':
            outputParams.NEXTPAGE = msg.params.step;
            form.action('DIRECT');
            break;
        default:
            break;
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var save =  form['save'];

        if (form.validateControlsByIds('*', showFlag === true ? save : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.yesFunc = function() {
    outputParams.TRANSTYPE = 'SAVEDRAFT';
    if (form.verifyForm()) {
        form.sendForm('GO', false);
    }
};

form.GetIncomeListText=function(value){
    var str="fieldCheck."+value;
    return form.getResourceBundle(str);
};
form.getRefSysNameText= function(value){
    for(var i=0;i<form.formParams.stageResultDecisionItems.length;i++){
        var itm = form.formParams.stageResultDecisionItems[i];
        if(itm["value"]==value){
            return itm["text"];
        }
    }
    return null;
};
form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    if(form.isFormEditMode==='true'){
        form.formParams.divisionRiskValuation=form.cbDivisionRiskValuation.getText();
        form.formParams.divisionRiskValuationSysName=form.cbDivisionRiskValuation.getValue();
        form.formParams.controlMethod=form.cbControlMethod ? form.cbControlMethod.getText() : "";
        form.formParams.controlMethodSysName=form.cbControlMethod ? form.cbControlMethod.getValue() : "";
        for (var i=0; i<form.formParams.chooseApproverLevelItems.length;i++){
            var item=form.formParams.chooseApproverLevelItems[i];
            if(item["value"]==form.formParams.approverLevelUnderwriterSysName){
                form.formParams.approverLevelUnderwriter = item["text"];
                break;
            }
        }
        if(form.formParams.approverLevelUnderwriterSysName===form.settings.decisionName){
            form.formParams.ApproverFullName = form.cbApprover.getText();
            form.formParams.CURRENTUSERID = form.cbApprover.getValue();
        }
    }

    getResponsiblePerson().then(() => {
        if (tagName === 'CLOSE') {
            if(form.isFormEditMode === 'false'){
                form.sendForm('GO',false);
            }else{
                service.showDialogCancelConfirm(
                    form,
                    form.yesFunc
                )
            }
        } else {
            if (tagName === 'NEXT' && !form.verifyForm(true)) {
                return;
            } else {
                form.verifyForm(false);
            }
            form.sendForm('GO', false);
        }
    });
};

var promises = [];

function getRefApprovingRegion(){
    return new Promise(function(resolve, reject) {
        var res = null,
            ReferenceItemCode = form.formParams.approverLevelUnderwriterSysName;
        var params = {
            ReferenceSysName: 'ApprovingRegion',
            ReferenceItemCode: ReferenceItemCode
            //ReferenceItemBrief: form.cbApplicationType.getValue(),
            //ReferenceItemName: form.cbStageApplication.getText()
        };
        form.dsCall('[refws]', 'dsReferenceItemBrowseListByParam', params).then(function(result) {
            var data = result.data || {},
                Result = data.Result || [];

            if(Result.length == 0){
                reject('error');
                showError(gRB('ErrorGetRefApprovingRegion')+ ReferenceItemCode);
                return;
            }

            Result.forEach(function(item, i, arr) {
                if(item.ReferenceItemCode == ReferenceItemCode){
                    //res = item[name];
                    paramsF['Region'] = item.ReferenceItemComment;
                    paramsF['ApproverLevel'] = item.ReferenceItemName;
                    resolve();
                    return;
                } else if (i+1 == Result.length) {
                    reject('error');
                    showError(gRB('ErrorGetRefApprovingRegion')+ ReferenceItemCode);
                    return;
                }
            });
        });
        resolve();
    });
}

function getFunctionCode(){
    return new Promise(function(resolve, reject) {
        var code = null;
        var params = {
            SYSNAMECONSTANT: 'ProjectConstants',
            SYSNAMETYPE: 'Common'
        };
        form.dsCall('[frontws2]','settingsGetByParams',params).then(function (p){
            var data = p.data || {},
                Result = data.Result || {},
                PARAMS = Result.PARAMS || {},
                ConstantList = PARAMS.ConstantList || [];

            if(ConstantList.length == 0){
                reject('error');
                showError(gRB('ErrorGetFunctionCode')+ 'FunctionCode');
                return;
            }

            ConstantList.forEach(function(item, i, arr) {
                if(item.CONSTANTSYSNAME == 'FunctionCode'){
                    code = item.VALUE;
                    paramsF['FunctionCode'] = code;
                    resolve();
                    return;
                } else if (i+1 == ConstantList.length) {
                    reject('error');
                    showError(gRB('ErrorGetFunctionCode')+ 'FunctionCode');
                    return;
                }
            });
        });
        resolve();
    });
}

//function getPersonList() {
function getPersonList(){
    return new Promise (function(resolve, reject) {
        var PersonList = [];
        var USERGROUPID;
        if (form.inputParams.userGroupMap && Object.keys(form.inputParams.userGroupMap).length) {
            USERGROUPID = form.inputParams.userGroupMap[form.formParams.approverLevelUnderwriterSysName] || '';
        }
        var params = {
            USERGROUPID: USERGROUPID || 4000
        };
        form.dsCall('[adminws]','admGroupUsers',params).then(function (p){
            var data = p.data || {},
                Result = data.Result || [];

            if(Result.length == 0){
                reject('error');
                showError(gRB('ErrorGetPersonList'));
                return;
            }

            Result.forEach(function(item, i, arr) {
                var promises = [];
                var taskCount = 0;
                var paramsTask = {
                    CurrentUserID: item.USERID,
                    TaskStatusBriefList: ['New','Precessed'],
                    TaskTypeName: 'Review by Approver'
                };

                promises.push(
                    form.dsCall('[corews]','dsTaskBrowseListByParam',paramsTask).then(function (res){
                        var data = res.data || {};
                        taskCount += (data.TOTALCOUNT || 0);
                    })
                );

                var paramsTask2 = {
                    CurrentUserID: item.USERID,
                    TaskStatusName: 'Done',
                    StartDate: function(){
                        var today = new Date();
                        //today.setTime(0);
                        today.setHours(0);
                        today.setMinutes(0);
                        today.setSeconds(0);
                        today.setMilliseconds(0);
                        return today;
                    }(),
                    TaskTypeName: 'Review by Approver'
                };
                promises.push(
                    form.dsCall('[corews]','dsTaskBrowseListByParam',paramsTask2).then(function (res2){
                        var data = res2.data || {};
                        taskCount += (data.TOTALCOUNT || 0);
                    })
                );

                Promise.all(promises).then(() => {
                    PersonList.push({NumberOfApplications: item.LOGIN +','+taskCount});
                    if(i == (arr.length - 1)) {
                        paramsF['PersonList'] = PersonList;
                        resolve();
                    }
                });
            });
        });
    });
}


//function getDocumentList() {
function getDocumentList(){
    return new Promise (function(resolve, reject) {
        var documents = [];
        var params = {
            DOCUMENTID: inputParams.APPLICATIONID || 875003
        };
        form.dsCall('[frontws2]','documentGetAllByPackage',params).then(function (p){
            var data = p.data || {},
                appList = data.Result || [];
            var PersonIDList = [];
            appList.forEach(function(item, i, arr) {
                if(['mortgageLoanAppINT','autoLoanAppINT','consumerLoanAppINT','issueCardAppINT','loanAppCodebtor'].indexOf(item.DOCTYPESYSNAME) != -1){
                    PersonIDList.push({PersonID: Number(item.CLIENTID)});
                }
            });

            var paramsCRM = {
                PersonIDList: PersonIDList
            };

            form.dsCall('[crmws]','dsPersonFindListByID3',paramsCRM).then(function (p){
                var data = p.data || {},
                    Result = data.Result || {},
                    docList = Result.PersonIdentityCardList || [];

                if(docList.length == 0){
                    reject('error');
                    showError(gRB('ErrorGetDocumentList1'));
                    return;
                }

                docList.forEach(function(elem, i, arr) {
                    if(elem.BaseIdentityCardFlag){
                        documents.push({DocumentNumber: elem.Number});
                    } else if (i+1 == docList.length){
                        reject('error');
                        showError(gRB('ErrorGetDocumentList2'));
                        return;
                    }
                });
                paramsF['DocumentList'] = documents;
                resolve();
            });
        });
    });
}
var paramsF = {
    ApplicationId: inputParams.APPLICATIONID
};
function hasEmptyValues(obj) {
    for (let val of Object.values(obj)) {
        if (!val) return true;
    }
    return false;
}

function getResponsiblePerson() {
    debugger;
    paramsF = {
        FunctionCode: null,
        ApplicationId: inputParams.APPLICATIONID,
        Region: null,
        ApproverLevel: null,
        PersonList: null,
        DocumentList: null
    };
    return new Promise (function(resolve, reject) {
        var promiseList = [];
        promiseList.push(getFunctionCode());
        promiseList.push(getRefApprovingRegion());
        promiseList.push(getPersonList());
        promiseList.push(getDocumentList());
        Promise.all(promiseList).then(() => {
                if(!hasEmptyValues(paramsF)){ //проверка на то что у всех обязательных (в точке все) атрибутов объекта есть значения
                    form.dsCall('[fttpbankadtws]','dsLOSIntegrationGetResponsiblePerson',paramsF).then(function (p){
                        var data = p.data || {},
                            IsGroup = data.IsGroup,
                            ApproverId = data.ApproverId || 0,
                            ReturnCode = data.ReturnCode;
                        if(Number(ReturnCode) == 0){
                            form.formParams.StatusSrv = 'success';
                            if(!IsGroup){
                                form.showInformationDialog(gRBT(gRB('infoTextGetResponsiblePerson'), ApproverId), function () {
                                    form.formParams.ApproverIdFromSrv = ApproverId;
                                    resolve();
                                }, [{
                                    caption: gRB('dialog.ok')
                                }]);
                            } else {

                            }
                        } else {
                            form.formParams.StatusSrv = 'error';
                            showError(gRB('errorTextGetResponsiblePerson'));
                            reject();
                        }
                    });
                }
            },
            () => {
                return;
            });
    });
}

function showError(messag) {
    service.showAlert(messag, true);
}