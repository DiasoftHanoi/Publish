function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
var service = registerMethod(service);

var convertDate = service.convertDate;
var lgr = service.lgr;
var nvl = service.nvl;
var gRB = service.gRB;
var inputParams = form.inputParams;
var outputParams = form.outputParams || {};
form.formParams = inputParams.formParams || {};
outputParams.formParams = form.formParams;
form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.isFormEditMode = form.inputParams.EDITMODE;
form.STAGESYSNAME = form.formParams.STAGESYSNAME;

var fieldVerificationList = form.formParams.fieldVerificationList || [];

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
        form['tblChecksInfo'] ? form['tblChecksInfo'].setItems(fieldVerificationList) : undefined;
};

form.getTodayDate = function () {
    return service.convertDate(new Date());
};

form.executeCommand = function(msg){
    service.lgr(msg.event);
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
     service.lgr(msg.params.step);   
    }
    if (msg.event === 'GO_TO_PAGEFLOW'){
        form.startNewPageFlowProcess(msg.caption, msg.params.PAGEFLOW, {
            APPLICATIONID: msg.params.APPLICATIONID,
            EDITMODE: false
        });
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;

    if (!form.isFormEditMode){
        outputParams.VERIFIED = inputParams.VERIFIED;
        return verified;
    }

    try {
        var btnNext =  form['btnNext'] ? 'btnNext' : 'btnSave';
        if (form.validateControlsByIds('*', showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {lgr(e);
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    if (form.isFormEditMode){
        form['tblChecksInfo'] ? form.formParams.fieldVerificationList = form['tblChecksInfo'].getItems() : form.formParams.fieldVerificationList = undefined;
    }
    if (tagName === 'CLOSE') {
        if (!form.isFormEditMode){
            form.sendForm('GO',false);
        }else {
            form.verifyForm(true, tagName);
            service.showDialogCancelConfirm(
                form,
                function () {
                    outputParams.TRANSTYPE = 'SAVEDRAFT';
                    form.sendForm('GO', false);
                }
            )
        }
    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};

form.tblChecksInfoObj = (function (grId) {
    var gridId = grId;

    var options = {
        data: {},
        settings: {
            curDate: service.convertDate(new Date()),
            cmbVisitTypeGridParams:{
                ReferenceGroupName: 'Unsecured Loan Application',
                ReferenceSysName: 'fieldVerificationVisitTypeLOS',
            },
            cmbEncounteredPersonGridParams:{
                ReferenceGroupName: 'Unsecured Loan Application',
                ReferenceSysName: 'fieldVerificationEncounteredPersonTypeLOS',
                ReferenceItemName: "",
                ORDERBY: 'ReferenceItemID',
            }
        },
        
        checkResultsList : form.inputParams.checkResultsList || [],
        
        requiredElements: [
            "cmbVisitTypeGrid",
            "clVisitDate",
            "edVisitTime",
            "rgFieldVerResult",
            "cmbEncounteredPerson",
            "edOtherEncounteredPerson"
        ],
        
        onChangeVisitType: function () {
            if (form.cmbVisitTypeGrid.getValue() && form.cmbVisitTypeGrid.getValue() != 'other') {
                options.data.flagVisitTypeForEncounteredPerson = true;
                if (form.cmbVisitTypeGrid.getValue()) {
                    options.settings.cmbEncounteredPersonGridParams.ReferenceItemName = form.cmbVisitTypeGrid.getValue();
                    delete options.data.fieldVerificationEncounteredPerson;
                    form.cmbEncounteredPerson.refresh();
                } 
            } else {
                options.data.flagVisitTypeForEncounteredPerson = false;
            }
        },
        
        onChangeEncounteredPerson: function () {
            var arr = form.cmbEncounteredPerson.getValue() || [];
            options.data.flagOther = arr.some(function isOther(item) {return item == 'other';});
        },
        
        cancel: function () {
            form[gridId].hideEditor();
            form.btnCheckAdd.enable();
        },
        save: function () {
            var selectedRow = form[gridId].getSelectedRow()[0];
            var encounteredPersonText = "";
            form.cmbEncounteredPerson ? form.cmbEncounteredPerson.getSelectedItems().forEach(function (item, i, arr){
                encounteredPersonText += item.ReferenceItemBrief;
                if (i < arr.length - 1){
                    encounteredPersonText += "; ";
                }
            }) : undefined;
            
            var newRow = {
                fieldVerificationVisitType              : form.cmbVisitTypeGrid.getValue(),
                fieldVerificationVisitTypeText          : form.cmbVisitTypeGrid.getText(),
                fieldVerificationDate                   : form.clVisitDate ? form.clVisitDate.getValue() : undefined,
                fieldVerificationDateText               : form.clVisitDate ? form.clVisitDate.getText() : undefined,
                fieldVerificationTime                   : form.edVisitTime ? form.edVisitTime.getValue() : undefined,
                fieldVerificationTimeText               : form.edVisitTime ? form.edVisitTime.getText() : undefined,
                fieldVerificationResult                 : form.rgFieldVerResult.getValue(),
                fieldVerificationRemark                 : form.edRemarkGrid.getValue(),
                fieldVerificationEncounteredPerson      : form.cmbEncounteredPerson ? form.cmbEncounteredPerson.getValue() : undefined,
                fieldVerificationOtherEncounteredPerson : form.edOtherEncounteredPerson ? form.edOtherEncounteredPerson.getValue() : undefined,
                fieldVerificationEncounteredPersonText  : form.cmbEncounteredPerson ? encounteredPersonText : undefined,
            };

            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['id'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnCheckAdd.enable();
        },
        clearFields: function () {
            delete options.data.fieldVerificationVisitType;
            delete options.data.fieldVerificationTime;
            delete options.data.fieldVerificationDate;
            delete options.data.fieldVerificationResult;
            delete options.data.fieldVerificationRemark;
            delete options.data.fieldVerificationEncounteredPerson;
            options.settings.cmbEncounteredPersonGridParams.ReferenceItemName = "";
            delete options.data.fieldVerificationOtherEncounteredPerson;
        },
        edit: function () {
            form.addAddrMode = 'edit';
            form[gridId].showEditor('edit');
            options.clearFields();
            var selectedRow = form[gridId].getSelectedRow()[0];
            form[gridId].options.data = {
                fieldVerificationVisitType                  : selectedRow["fieldVerificationVisitType"],
                fieldVerificationDate                       : selectedRow["fieldVerificationDate"],
                fieldVerificationTime                       : selectedRow['fieldVerificationTime'],
                fieldVerificationResult                     : selectedRow['fieldVerificationResult'],
                fieldVerificationRemark                     : selectedRow['fieldVerificationRemark'],
                fieldVerificationEncounteredPerson          : selectedRow['fieldVerificationEncounteredPerson'],
                fieldVerificationOtherEncounteredPerson     : selectedRow['fieldVerificationOtherEncounteredPerson'],
            };
            form.btnCheckAdd.disable();
        },
        delete: function () {
            var row = form[gridId].getSelectedRow()[0];
            if (row) {
                form[gridId].deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
            options.clearFields();
            form.btnCheckAdd.enable();
        }
    };

    var obj = {
        gridId: grId,
        refresh: function () {
            form[gridId].refresh();
        },
        addNewRow: function () {
            form.addAddrMode = 'add';
            form[gridId].showEditor('add');
            options.clearFields();
            form.btnCheckAdd.disable();
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (form.isFormEditMode){
                var selRow = form[gridId].getSelectedRow()[0] || {};
                options.items = [
                    {caption: gRB('edit'),   click: form[gridId].options.edit},
                    {caption: gRB('delete'), click: form[gridId].options.delete}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblChecksInfo');