/*DSMETA version = "5.08.01-HF007-22121302" hash = "dc0d974d364aca5ad391c4f342579d60cf8c3dcc"*/
var inputParams = form.inputParams || {};
var outputParams = form.outputParams || {}


var lgr = service.lgr;
var gRB = function (key) {
    return service.nvl(form.localize[key], key);
};
form.gRB = gRB;

form.action = function (tagName) {
    form.outputParams.responsibleID=form.inputParams.responsibleID;
    form.sendForm(tagName);
};

form.onShow = function () {
    if(form.cbResponsible) form.cbResponsible.setValue(form.inputParams.responsibleID);
};

var DepartmentIDList = (!form.inputParams.isSuperUser) ? form.inputParams.userDepartmentIDList : [];
form.Responsible = {
    lkpParams: {
        ROLEID: form.inputParams.ROLEID,
        DepartmentIDList: DepartmentIDList,
        UserAccountStatus: 'ACTIVE'
    }
};

form.getUserEmail= function (item) {
    var id = inputParams.responsibleID;
    var CurrentUserID =inputParams.CurrentUserID; 
    var list = form.cbResponsible.items;
    for (var i = 0; i < list.length; i++) {
        var map = list[i];
        if (map.UserID == id) {
            form.outputParams.newResponsibleEMAIL = map.EMAIL;
        }
        if (map.UserID == CurrentUserID) {
            form.outputParams.currenResponsibleEMAIL = map.EMAIL;
        }        
    }
};

form.onChangechkResponsible=function (){
    if(form.inputParams.chkResponsible){
        form.Responsible.lkpParams.DepartmentIDList=[form.inputParams.DepartmentID];
        form['cbResponsible'].refresh();
    } else if(form.inputParams.isSuperUser){
        form.Responsible.lkpParams.DepartmentIDList=[];
        form['cbResponsible'].refresh();
    } else {
        form.Responsible.lkpParams.DepartmentIDList=form.inputParams.userDepartmentIDList;
        form['cbResponsible'].refresh();
    }    
};

