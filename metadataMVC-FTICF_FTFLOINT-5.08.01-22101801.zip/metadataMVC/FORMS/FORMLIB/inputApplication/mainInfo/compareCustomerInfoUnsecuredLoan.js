/*DSMETA version = "5.08.01-22101801" hash = "d9a8a49c975212e60391405ebb7f30814dc04c26"*/
/* global form */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var convertDate = service.convertDate;
var getTableContent = service.getTableContent;
var gRB = service.gRB;
var nvl = service.nvl;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.isFormEditMode = form.inputParams.EDITMODE || false;

var inputParams = form.inputParams;
var outputParams = form.outputParams;

form.formParams = inputParams.formParams;
outputParams.formParams = form.formParams;

form.compareList = inputParams.compareList || [];

form.onShow = function () {
    service.wizFormNavigatorCommand({
       context: form,
       event: 'CURPAGE_MSG'
    });

    if (!form.isFormEditMode) {
        if (form.btnNext) {
            form.btnNext.setFocus();
        }
        else if (form.btnSave) {
            form.btnSave.setFocus();
        }
        else {
            form.btnCancel.setFocus();
        }
    }
};

var sendMessage = function (message) {
    var PROCESS_RIGHT_LIST = getInputParams("PROCESS_RIGHT_LIST");
    if (PROCESS_RIGHT_LIST) {
        for (var ar in PROCESS_RIGHT_LIST) {
            form.commandRight(ar, message);
        }
    }
};


form.action = function (tag) {
    outputParams.TRANSTYPE = tag;
    if(form.inputParams.EDITMODE) {

    }
    if (tag === 'CLOSE') {
        if(form.inputParams.EDITMODE === false){
            form.sendForm('GO',false);
        }
        else {
            service.showDialogCancelConfirm(
                form,
                form.yesFunc,
                form.noFunc
            )
        }
    }
    else {
        if (tag === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};

form.yesFunc = function() {
    var tag = outputParams.TRANSTYPE;
    outputParams.TRANSTYPE = 'SAVEDRAFT';
    if(form.verifyForm(true, tag)) {
        form.sendForm('GO', false);
    }
};
form.noFunc = function(){
    form.outputParams.TRANSTYPE = 'CLOSE';
    form.sendForm('GO',false);
};

form.verifyForm = function (showFlag, tag) {
    var verified = true;
    var buttonNextSave = (form.isLastWizForm) ? "btnSave" : "btnNext";
    if (tag === 'CLOSE') {
        buttonNextSave = "btnCancel";
    }
    try {
        if ((form.validateControlsByIds("*", showFlag === true ? buttonNextSave : undefined).isShowFormErrors)) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.executeCommand = function(msg){
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
    if (msg.event === 'GO_TO_PAGEFLOW'){
        form.startNewPageFlowProcess(msg.caption, msg.params.PAGEFLOW, {
            APPLICATIONID: msg.params.APPLICATIONID,
            EDITMODE: false
        });
    }
};