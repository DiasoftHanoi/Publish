/*DSMETA version = "5.11.01-24041703" hash = "70359b098609ad5628ef2d9dcd55cc6df090287e"*/
/* global form, service */

form.isFormEditMode = form.inputParams.EDITMODE || false;
var inputParams = form.inputParams;
var outputParams = form.outputParams || {};
form.formParams = form.inputParams.formParams || {};
outputParams.formParams = form.formParams;
form.isFormEditModeMain = form.inputParams.EDITMODE;
form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
//form.formParams.subproductList = form.formParams.subproductList ? form.formParams.subproductList : [];
//form.isSubpsroductPanelInfoCollapsed = /*true;*/ form.formParams.subproductList.length <= 0;
form.formParams.fees = form.formParams.fees ? form.formParams.fees : [];
form.formParams.crossUpProduct = form.formParams.crossUpProduct ? form.formParams.crossUpProduct : [];
form.isfeesPanelInfoCollapsed = /*true;*/ form.formParams.fees.length <= 0;
form.iscrossUpPanelCollapsed = /*true;*/ form.formParams.crossUpProduct.length <= 0;

var lgr = service.lgr;
var nvl = service.nvl;
var gRB = form.getResourceBundle;


form.settings={
    loanTypeConsumer:{
        ReferenceSysName:"loanTypeConsumerLOS",
        LOCALE:"en"
    },
    referenceLoanPurpose:{
         ReferenceSysName:"loanPurpose",
         LOCALE:"en"
    }
};

form.onShow = function () {
    form.setLoanRatio();
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
    if (form.isFormEditModeMain) {
        form.getBPparamValues();
    } 
    form.feesInfo.setItems(form.formParams.fees || []);
    form.crossUpProductInfo.setItems(form.formParams.crossUpProduct || []);

};

form.verifyForm = function (showFlag) {
    var verified = true;
    var buttonNextSave = (form.isLastWizForm) ? "btnSave" : "btnNext";
    try {
        if ((form.validateControlsByIds('*', showFlag === true ? buttonNextSave : undefined).isShowFormErrors)) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    outputParams.VERIFIED = verified;
    console.log('verified ',verified);
    return verified;
};

form.executeCommand = function (msg) {
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE') {
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};

form.yesFunc = function() {
    outputParams.TRANSTYPE = 'SAVEDRAFT';
    if(form.verifyForm(false)) {
        form.sendForm('GO', false);
    }
};
form.noFunc = function(){
    form.outputParams.TRANSTYPE = 'CLOSE';
    form.sendForm('GO',false);
};

form.action = function (tag) {
    outputParams.TRANSTYPE = tag;
    if (form.isFormEditModeMain) {
        outputParams.formParams.fees                            = form.feesInfo.getItems();
        outputParams.formParams.crossUpProduct                  = form.crossUpProductInfo.getItems();
        outputParams.formParams.PRODUCTBRIEFNAME                = form.formParams.bankProductName = (form.cbLoanProduct) ? form.cbLoanProduct.getText() : undefined;
        outputParams.formParams.bankProductBrief                = (form.formParams.bankProductId) ? inputParams.bankProdParamMap[form.formParams.bankProductId]["PRODUCTBRIEFNAME"] : undefined;
        outputParams.formParams.bankProductGroupName            = form.cbLoanProduct.getText();
        outputParams.formParams.loanSubproductName              = (form.cbSubproductsInfo) ? form.cbSubproductsInfo.getText() : undefined;
        outputParams.formParams.loanSubproduct                  = (form.cbSubproductsInfo) ? form.cbSubproductsInfo.getValue() : undefined;
        outputParams.formParams.loanPurpose                     = form.cbLoanPurpose.getText();
        outputParams.formParams.principalRepaymentMethod        = form.cbPrincipalRepaymentMethod.getText();
        outputParams.formParams.interestRepaymentMethod         = form.cbInterestRepaymentMethod.getText();
        outputParams.formParams.creditCurrencyName              = form.cbCreditCurrency.getText();
        outputParams.formParams.disbursmentMethod               = form.cbDisbursmentMethod.getText();
        outputParams.formParams.loanTypeText                    = form.cbLoanType.getText();
        outputParams.formParams.creditExtensionMethod           = form.cbCreditExtensionMethod.getText();

    }
    service.lgr(outputParams);

    if (tag === 'CLOSE') {
        if(form.inputParams.EDITMODE === false){
            form.sendForm('GO',false);
        }
        else {
            service.showDialogCancelConfirm(
                form,
                form.yesFunc,
                form.noFunc
            )
        }
    }
    else {
        if (tag === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }    
};

form.tblFeesInfo = (function (grId) {
    var gridId = grId;

    var options = {
        creditCurrencySysName:form.formParams.creditCurrencySysName,
        cancel: function () {
            form[gridId].hideEditor();
            form.btnDataWorkAdd.enable();
        },
        save: function () {
            var selectedRow = form.feesInfo.getSelectedRow()[0];
            var newRow = {
                feeType             : form.feeType.getValue(),
                value               : form.feeValue.getValue(),
                feeDetail           : form.feeDetail.getValue()
            };

            if (selectedRow['LinkID']) {
                newRow['LinkID'] = selectedRow['LinkID'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['LinkID'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnDataWorkAdd.enable();
        },

        clearFields: function () {
            delete options.data.feeType;
            delete options.data.value;
            delete options.data.feeDetail;
        },

        getOptionsData: function () {
            var selectedRow = form.feesInfo.getSelectedRow()[0];

            form.tblFeesInfo.options.data = {
                feeType           : selectedRow["feeType"],
                value    : selectedRow["value"],
                feeDetail   : selectedRow["feeDetail"]
            };

        },

        edit: function () {
            options.clearFields();
            options.getOptionsData();
            form[gridId].showEditor('edit');
            form.btnDataWorkAdd.disable();
        },
        view : function () {
            options.clearFields();
            options.getOptionsData();
            form[gridId].showEditor('edit');
        },

        delete: function () {
            if (form.feesInfo.getSelectedRow()[0]) {
                form.feesInfo.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
        },

        EDITMODE : form.isFormEditMode,
        data: {}

    };

    var obj = {
        addNewRow: function () {
            options.clearFields();
            form.feesPanel.isCollapsed = false;
            form[gridId].showEditor('add');
            form.btnDataWorkAdd.disable();

        },
        onSelectRow: function () {
            var selRow = form[gridId].getSelectedRow()[0] || {};
            if (form.isFormEditMode) {
                options.items = [
                    {caption: gRB('edit'), click: form.tblFeesInfo.options.edit},
                    {caption: gRB('delete'), click: form.tblFeesInfo.options.delete}
                ];
            }
        },
    };
    obj.options = options;
    return obj;
})('feesInfo');

form.tblcrossUpProductInfo = (function (grId) {
    var gridId = grId;

    var options = {
        creditCurrencySysName:form.formParams.creditCurrencySysName,
        cancel: function () {
            form[gridId].hideEditor();
            form.btnDataWorkAdd.enable();
        },
        save: function () {
            var selectedRow = form.crossUpProductInfo.getSelectedRow()[0];
            var newRow = {
                productType                 : form.productType.getValue(),
                loanPurpose                 : form.loanPurpose.getValue(),
                loanAmount                  : form.loanAmount.getValue(),
                disbursementMethod          : form.disbursementMethod.getValue(),
                disbursmentMethodDetailed   : form.disbursmentMethodDetailed.getValue(),
                loanTerm                    : form.loanTerm.getValue()
            };

            if (selectedRow['LinkID']) {
                newRow['LinkID'] = selectedRow['LinkID'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['LinkID'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnDataWorkAdd.enable();
        },

        clearFields: function () {
            delete options.data.productType;
            delete options.data.loanPurpose;
            delete options.data.loanAmount;
            delete options.data.disbursementMethod;
            delete options.data.disbursmentMethodDetailed;            
            delete options.data.loanTerm; 
        },

        getOptionsData: function () {
            var selectedRow = form.crossUpProductInfo.getSelectedRow()[0];

            form.tblcrossUpProductInfo.options.data = {
                productType                 : selectedRow["productType"],
                loanPurpose                 : selectedRow["loanPurpose"],
                loanAmount                  : selectedRow["loanAmount"],
                disbursementMethod          : selectedRow["disbursementMethod"],
                disbursmentMethodDetailed   : selectedRow["disbursmentMethodDetailed"] ,
                loanTerm                    : selectedRow["loanTerm"] 
            };

        },

        edit: function () {
            options.clearFields();
            options.getOptionsData();
            form[gridId].showEditor('edit');
            form.btnDataWorkAdd.disable();
        },
        view : function () {
            options.clearFields();
            options.getOptionsData();
            form[gridId].showEditor('edit');
        },

        delete: function () {
            if (form.crossUpProductInfo.getSelectedRow()[0]) {
                form.crossUpProductInfo.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
        },

        EDITMODE : form.isFormEditMode,
        data: {}

    };

    var obj = {
        addNewRow: function () {
            options.clearFields();
            form.crossUpPanel.isCollapsed = false;
            form[gridId].showEditor('add');
            form.btnDataWorkAdd.disable();

        },
        onSelectRow: function () {
            var selRow = form[gridId].getSelectedRow()[0] || {};
            if (form.isFormEditMode) {
                options.items = [
                    {caption: gRB('edit'), click: form.tblcrossUpProductInfo.options.edit},
                    {caption: gRB('delete'), click: form.tblcrossUpProductInfo.options.delete}
                ];
            }
            if (!form.isFormEditMode) {
                 options.items = [
                     {caption: gRB('view'), click: form.tblcrossUpProductInfo.options.view}
                 ];
            }
        },
    };
    obj.options = options;
    return obj;
})('crossUpProductInfo');

form.getBPparamValues = function() {

    var PARAMTYPELIST = ["SubProduct","loanPurpose","principalRepaymentMethodLOS","interestRepaymentMethodLOS","currencyLOS","disbursementMethodLOS","subProductNameLOS","creditExtensionMethodLOS"];
    var PRODUCTID = form.formParams.bankProductId;
    if (!PRODUCTID) return;
    var bankProdLocaleList = form.inputParams.bankProdLocaleList || [];    
    //bankProdLocaleList.forEach(function(item) {
      for (var i = 0, count = bankProdLocaleList.length; i < count; i++) {
      var item = bankProdLocaleList[i];
        if(item.bankProductId==PRODUCTID){
            form.formParams.bankProductSysName=item.bankProductSysName;
        }
    };
    var dsCallparams = {
        PRODUCTID: PRODUCTID,
        PARAMTYPELIST: PARAMTYPELIST,
        RETURN_ABSOLUTE_PARAM:true

    };
     
    return form.dsCall('[frontws2]', 'bankProductParamGetListByProductId', dsCallparams).then(function (response){
        inputParams.Subproduct_ITEMS=[];
        inputParams.carClass_ITEMS=[];
        inputParams.vehicleCondition_ITEMS=[];
        inputParams.principalRepaymentMethod_ITEMS=[];
        inputParams.interestRepaymentMethod_ITEMS=[];
        inputParams.loanCurrency_ITEMS=[];
        inputParams.interestRateOption_ITEMS=[];
        inputParams.disbursementMethod_ITEMS=[];
        inputParams.loanPurpose_ITEMS=[];
        inputParams.gracePeriod_ITEMS=[];
        inputParams.creditExtensionMethod_ITEMS=[];
        service.lgr(response);
        for (var i=0; i<response.data.Result.length;i++){
            var items = response.data.Result[i];
            switch (items["PARAMTYPE"]){
                case "SubProduct":
                    inputParams.Subproduct_ITEMS=items["VALUES"];
                    break;
                case "principalRepaymentMethodLOS":
                    inputParams.principalRepaymentMethod_ITEMS =items["VALUES"];
                    break;
                case "interestRepaymentMethodLOS":
                    inputParams.interestRepaymentMethod_ITEMS=items["VALUES"];
                    break;
                case "currencyLOS":
                    inputParams.loanCurrency_ITEMS=items["VALUES"];
                    break;
                case "disbursementMethodLOS":
                    inputParams.disbursementMethod_ITEMS=items["VALUES"];
                    break;
                case "loanPurpose":
                    inputParams.loanPurpose_ITEMS=items["VALUES"];
                    break;
                case "creditExtensionMethodLOS":
                    inputParams.creditExtensionMethod_ITEMS=items["VALUES"];
                    break;
            }
        }

        form.isExistValueItem(inputParams.Subproduct_ITEMS, form.formParams.loanSubproduct, "cbSubproductsInfo");
        form.isExistValueItem(inputParams.principalRepaymentMethod_ITEMS, form.formParams.principalRepaymentMethodSysName, "cbPrincipalRepaymentMethod");
        form.isExistValueItem(inputParams.interestRepaymentMethod_ITEMS, form.formParams.interestRepaymentMethodSysName, "cbInterestRepaymentMethod");
        form.isExistValueItem(inputParams.loanCurrency_ITEMS, form.formParams.creditCurrencySysName, "cbCreditCurrency");
        form.isExistValueItem(inputParams.disbursementMethod_ITEMS, form.formParams.disbursmentMethodSysName, "cbDisbursmentMethod");
        form.isExistValueItem(inputParams.loanPurpose_ITEMS, form.formParams.loanPurposeSysName, "cbLoanPurpose");
        form.isExistValueItem(inputParams.creditExtensionMethod_ITEMS, form.formParams.creditExtensionMethodSysName, "cbCreditExtensionMethod");
    }).catch(function (e){
        form.showErrorDialog('error', function(){}, [{caption: 'OK'}]);
    });
};

form.isExistValueItem = function(list, item, obj) {
    for (var i = 0, count = list.length; i < count; i++) {
        if (list[i].VALUE1 == item) {
            return true;
        }
    }
    if(obj == 'cbSubproductsInfo') {
        form.formParams.loanSubproduct = "";
    }
    else{
    if (obj) {
        form[obj].setValue("");
    }}
    return false;
};

form.setLoanRatio = function() {
    if(form.formParams.bankProductSysName!='product3'){
        var ratio = Math.ceil((form.formParams.loanAmount/form.formParams.requiredCapital*100)*100)/100; 
        ratio = isNaN(ratio) ? "" : ratio;
        form.formParams.loanValueRatio=ratio;
    }
};

form.setLoanAmount = function() {
    if(form.formParams.bankProductSysName!='product3'){    
        var amount = Math.ceil(((form.formParams.requiredCapital - form.formParams.ownedCapital)*100))/100; 
        amount = isNaN(amount) ? "" : amount;
        form.formParams.loanAmount=amount;
    }
};



