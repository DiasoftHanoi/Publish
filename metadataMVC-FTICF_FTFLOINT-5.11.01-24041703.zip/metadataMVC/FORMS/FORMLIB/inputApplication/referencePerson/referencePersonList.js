/*DSMETA version = "5.11.01-24041703" hash = "10011186550b9c3f9e5613d6dd4f963c3a138802"*/
/* global form, service */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;

var outputParams = form.outputParams || {}
outputParams.formParams = form.formParams;

var lgr = service.lgr;
var nvl = service.nvl;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.isFormEditMode = form.inputParams.EDITMODE || false;

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });

    if (!form.isFormEditMode) {
        if (form.btnNext) {
            form.btnNext.setFocus();
        }
        else if (form.btnSave) {
            form.btnSave.setFocus();
        }
        else {
            form.btnCancel.setFocus();
        }
    }
};

form.referencePersonList = inputParams.formParams.referencePersonList;
form.addReferencePerson = function () {
    var caption = gRB('add') + ' ' + "${Person}";
    form.startNewPageFlowProcess(caption,  form.getCurrentProjectSysname() + '/' + 'FORMLIB/inputApplication/referencePerson/referencePerson', {
        wizardParams: inputParams.wizardParams,
        referencePersonList: form.referencePersonList
    },
    false, null,
    function(p){
    });
};

form.EditReferencePerson = function (item) {
    var clientFirstName = item.clientFirstName;
    var clientBirthDate = item.clientBirthDate;
    var clientAge = item.clientAge;
    var addressList = item.addressList;
    var clientGender = item.clientGender;
    var contactList = item.contactList;
    var RelationshiWithBorrower = item.RelationshiWithBorrower;
    var relationshiWithBorrowerOther = item.relationshiWithBorrowerOther;
    var relationshiWithBorrowerBrief = item.relationshiWithBorrowerBrief;
    var LinkID = item.LinkID;
    var caption = gRB('view') + ' ' + "${Person}";
     if(form.isFormEditMode == false) {
         caption = gRB('view') + ' ' + "${Person}";
     }else{
         caption = gRB('edit') + ' ' + "${Person}";
     }
    form.startNewPageFlowProcess(caption,  form.getCurrentProjectSysname() + '/' + 'FORMLIB/inputApplication/referencePerson/referencePerson', {
          wizardParams: inputParams.wizardParams,
          clientFirstName: clientFirstName,
          clientBirthDate: clientBirthDate,
          clientAge: clientAge,
          RelationshiWithBorrower: RelationshiWithBorrower,
          relationshiWithBorrowerOther: relationshiWithBorrowerOther,
          relationshiWithBorrowerBrief: relationshiWithBorrowerBrief,
          addressList: addressList,
          clientGender: clientGender,
          contactList: contactList,
          referencePersonList: form.referencePersonList,
          LinkID : LinkID
    },
    false, null,
    function(p){
    });
};

form.DeleteReferencePerson = function(item){

 var referencePersonList = form.referencePersonList;
 var referencePersonListNew = [];
 if (referencePersonList && referencePersonList.length) {
     for(var i=0; i<referencePersonList.length; i++) {
 		  var RelationshiWithBorrower = referencePersonList[i]['RelationshiWithBorrower'];
 		  var relationshiWithBorrowerBrief = referencePersonList[i]['relationshiWithBorrowerBrief'];
 		  var clientFirstName = referencePersonList[i]['clientFirstName'];
 		  var relationshiWithBorrowerOther = referencePersonList[i]['relationshiWithBorrowerOther'];
 		  var clientBirthDate = referencePersonList[i]['clientBirthDate'];
 		  var clientAge = referencePersonList[i]['clientAge'];
 		  var clientGender = referencePersonList[i]['clientGender'];
 		  var contactList = referencePersonList[i]['contactList'];
 		  var addressList = referencePersonList[i]['addressList'];
 		  var LinkID = referencePersonList[i]['LinkID'];

 		  if(item.LinkID != LinkID) {
 		      referencePersonListNew.push({clientAge: clientAge, clientFirstName: clientFirstName, clientGender: clientGender, clientBirthDate: clientBirthDate, RelationshiWithBorrower: RelationshiWithBorrower, relationshiWithBorrowerBrief: relationshiWithBorrowerBrief, relationshiWithBorrowerOther: relationshiWithBorrowerOther,  LinkID: LinkID, addressList: addressList, contactList: contactList})
 		  }
     }
     form.referencePersonList =  referencePersonListNew;
     form['addReferencePersonTable'].setItems(referencePersonListNew);
     form['addReferencePersonTable'].refresh();
 }

};

form.executeCommand = function (msg) {
    switch (msg.event) {
        case 'REFRESH_PERSON_LIST':
            form['addReferencePersonTable'].setItems(msg.params.referencePersonList);
            form['addReferencePersonTable'].refresh();
            form.referencePersonList = msg.params.referencePersonList;
        break;
        case 'FAB_NAVIGATOR_NAVIGATE':
            outputParams.NEXTPAGE = msg.params.step;
            form.action('DIRECT');
        break;
        default:
            break;
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var btnNext =  form['btnNext'] ? 'btnNext' : 'btnSave';
        if (form.validateControlsByIds('*', showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {lgr(e);
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.ReferencePersonObj = (function (grId){
    var gridId = grId;

    var obj = {
        gridId: grId,
        options : {
		},
        refresh : function (){
        },

		onChangeItems: function () {
        }
    };

    return obj;
})("ReferencePersonObj")

form.onSelectReferencePerson = function (item) {
 var caption = gRB('view');;

 if(form.isFormEditMode == true) {
     caption = gRB('edit');
         form.ReferencePersonObj.options.items = [
             {
                 caption: caption,
                 click:function(){form.EditReferencePerson(item)}
             },
             {
                caption: gRB('delete'),
                click:function(){form.DeleteReferencePerson(item)}
             }
         ];
 }else{
     caption = gRB('view');
         form.ReferencePersonObj.options.items = [
             {
                 caption: caption,
                 click:function(){form.EditReferencePerson(item)}
             }
         ];
     }
};

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    form.formParams.referencePersonList =  form.referencePersonList;
    if (tagName === 'CLOSE') {
        if(form.inputParams.EDITMODE === false){
            form.sendForm('GO',false);
        }else {
            service.showDialogCancelConfirm(
                form,
                function () {
                    form.outputParams.TRANSTYPE = 'SAVEDRAFT';
                    form.verifyForm(false);
                    form.sendForm('GO', false);
                }
            )
        }

    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
}