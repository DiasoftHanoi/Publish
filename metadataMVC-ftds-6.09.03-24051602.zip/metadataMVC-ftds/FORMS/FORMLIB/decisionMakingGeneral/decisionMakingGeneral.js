/* global form, service */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
var service = registerMethod(service);

form.params = form.inputParams.formParams || {};
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.isFormEditMode = form.inputParams.EDITMODE || false;
form.isFormEditModeMain = form.inputParams.EDITMODE;
var inputParams = form.inputParams;
var outputParams = form.outputParams;
form.formParams = inputParams.formParams || {};
form.ChooseUserExeptionAccList = inputParams.ChooseUserExeptionAccList || {};
form.ChooseUserSysName = inputParams.ChooseUserSysName || "";

outputParams.formParams = form.formParams;
inputParams.decisionItems=inputParams.decisionItems.reverse();
var mandatoryResponsible = inputParams.mandatoryResponsible ? inputParams.mandatoryResponsible.toUpperCase() : '';
form.isChooseAUser = mandatoryResponsible ==="NO" ? false : true;
var lgr = service.lgr;
/*var nvl = service.nvl;*/
service.lgr(form.params);

form.requiredElements = [
    "btSolution",
    "cbReasonId",
    "chooseAUserID"
];

form.settings = {
    chooseAUserIDFields:  [
        {
            value: "USERLOGIN",
            caption: "Login",
            width: 3
        },
        {
            value: "EMPLOYEENAME",
            caption: "Name",
            width: 9
        }
    ],
    chooseAUserIDMethodParams: {}
};

form.fillChooseAUser = function () {
    if (form.chooseAUserID){
        if (form.ChooseUserExeptionAccList && form.ChooseUserExeptionAccList.length>0) {
            form.chooseAUserID.setItems(form.ChooseUserExeptionAccList);
            form.chooseAUserID.refresh();
        }else{
            form.chooseAUserID.method="dsUserBrowseListAccountByParam";
            form.chooseAUserID.service="adminws";
            form.chooseAUserID.refresh();
        }
    }
}

form.onShow = function () {
    form.onChangeDecision();
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
};

form.onChangeDecision = function(){
    var RoleSysName = '';
    var GROUPID = '';
    var DepartmentIDList = form.inputParams.DepartmentIDList || [];
    var paramMap = {};
    form.inputParams.ChooseUserSysName = undefined;
    if (form.inputParams.decisionNameMap && Object.keys(form.inputParams.decisionNameMap).length && form.formParams.REFSYSNAME) {
        var currentDecisionMap = form.inputParams.decisionNameMap[form.formParams.REFSYSNAME] || {};
        if (currentDecisionMap && Object.keys(currentDecisionMap).length) {
            RoleSysName = currentDecisionMap['employeeRoleSysName'] || '';
            if (RoleSysName) {
                paramMap["RoleSysName"] = RoleSysName;
            }
            if (form.inputParams.userGroupMap && Object.keys(form.inputParams.userGroupMap).length) {
                GROUPID = form.inputParams.userGroupMap[currentDecisionMap['employeeGroupName']] || '';
                if (GROUPID) {
                    paramMap["GROUPID"] = GROUPID;
                }
            }
        }
        if (DepartmentIDList && DepartmentIDList.length) {
            paramMap["DepartmentIDList"] = DepartmentIDList;
        }
    }
    form.settings.chooseAUserIDMethodParams = JSON.stringify(paramMap);
    
    setTimeout(function(){form.fillChooseAUser();}, 200);//ngif не много не успевает отработать 
};

form.verifyForm = function (showFlag) {
    var verified = true;
    var buttonNextSave = (form.isLastWizForm) ? "btnSave" : "btnNext";
    try {
        console.log('verifyForm');
        console.log('r ',form.requiredElements.join(','));
        if ((form.validateControlsByIds(form.requiredElements.join(','), showFlag === true ? buttonNextSave : undefined).isShowFormErrors)) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    outputParams.VERIFIED = verified;
    console.log('verified ',verified);
    return verified;
};
form.executeCommand = function (msg) {
	switch (msg.event) {
        case 'FAB_NAVIGATOR_NAVIGATE':
            outputParams.NEXTPAGE = msg.params.step;
            form.action('DIRECT');
            break;
        case 'GO_TO_PAGEFLOW':
            form.startNewPageFlowProcess(msg.caption, msg.params.PAGEFLOW, {
                APPLICATIONID: msg.params.APPLICATIONID,
                EDITMODE: false
            });
            break;
        case 'processingStage':
            form.startNewPageFlowProcess(msg.caption, "FTFLOINTMVC/COMMON/APPLICATION/PROCESSING/applicationProcessing", {
                APPLICATIONID: form.inputParams.APPLICATIONID
            });
            break;
        case 'attachedDocuments':
            form.startNewPageFlowProcess(msg.caption, "FTFLOINTMVC/COMMON/APPLICATION/applicationListAttachment", {
                APPLICATIONID: form.inputParams.APPLICATIONID
            });
            break;
            
    }
};

form.yesFunc = function() {
    outputParams.TRANSTYPE = 'SAVEDRAFT';
    if (form.verifyForm()) {
        form.sendForm('GO', false);
    }
};

form.action = function (tag) {
    outputParams.TRANSTYPE = tag;
    form.outputParams.formParams.RefuseReason = form.cbReasonId ? form.cbReasonId.getText() : undefined;
    form.outputParams.formParams.ChooseUser = form.chooseAUserID ? form.chooseAUserID.getText() : undefined;
    form.outputParams.formParams.CURRENTUSERID = form.chooseAUserID ? form.chooseAUserID.getValue() : undefined;
    if (tag === 'CLOSE') {
        service.showDialogCancelConfirm(
            form,
            form.yesFunc,
            form.noFunc
        )
    }
    else {
        form.sendForm('GO', false);
    }
};
form.noFunc = function(){
    if (inputParams.FORMLIST && inputParams.FORMLIST.length > 0) {
        form.sendForm('GO',false);      // Если форма в мастере
    } else {
        form.sendForm('CANCEL', false); // Если форма отдельно в decisionMakingINT
    }
};
