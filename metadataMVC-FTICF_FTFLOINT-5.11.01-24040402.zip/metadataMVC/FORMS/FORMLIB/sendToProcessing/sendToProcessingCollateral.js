/*DSMETA version = "5.11.01-24040402" hash = "7ddb03539f1b1f05c1ab91268f7ce9aca9cd00ed"*/
var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams || {};

var outputParams = form.outputParams || {};
outputParams.formParams = form.formParams || {};

var lgr = service.lgr;
var nvl = service.nvl;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

var linkedAppParams = inputParams.PARAMS || {};
linkedAppParams.DOCUMENTTYPEID = inputParams.DOCUMENTTYPEID;
linkedAppParams.MAINAPPLICATIONID = inputParams.APPLICATIONID;
linkedAppParams.EDITMODE = true;

form.showFlow = false;
form.showApproverLevel = false;
form.showCustomerGroup = false;
form.showPaymentAccountNumber = false;

form.settings = {
    approverLevelAll: [],
    approverLevel_ITEMS: [],
    customerGroupAll: [],
    customerGroup_ITEMS: [],
    Flow: {
        ReferenceSysName: 'flowTypeLOS',
        ORDERBY: 'ReferenceItemCode'
    }
};

form.onShow = function () {
    form.getBPConditionParamValues();
    form.prepareData();
};

form.executeCommand = function(msg){
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var btnNext =  form['btnNext'] ? 'btnNext' : 'btnSave';
        if (form.validateControlsByIds('*', showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {lgr(e);
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tagName) {
    outputParams.STAGEDETAILS = form.formParams.STAGEDETAILS;
    outputParams.paymentDate = form.formParams.paymentDate;
    outputParams.paymentAccountNumber = form.formParams.paymentAccountNumber;

    outputParams.flowSysName = form.cbFlow ? form.formParams.flowSysName : null;
    outputParams.flow = form.cbFlow ? form.cbFlow.getText()  : null;

    outputParams.approverLevelSysName = form.cbApproverLevel ? form.formParams.approverLevelSysName : null;
    outputParams.approverLevel = form.cbApproverLevel ? form.cbApproverLevel.getText()  : null;

    outputParams.productCustomerGroupSysName = form.cbProductCustomerGroup ? form.formParams.productCustomerGroupSysName : null;
    outputParams.productCustomerGroup = form.cbProductCustomerGroup ? form.cbProductCustomerGroup.getText()  : null;

    outputParams.TRANSTYPE = tagName;

    if (tagName === 'CLOSE' || tagName === 'PREV') {
        form.sendForm('CLOSE', false);
    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};

form.tblCollateralListObj = (function (grId) {
    var gridId = grId;
    var options = {
        edit: function () {
            var selectedRow = form.tblCollateralListTable.getSelectedRow()[0];
            linkedAppParams.EDITMODE = true;
            var params = {
                COLLATERALMODE   : "EDIT",
                formParams  : selectedRow,
                extraParams : linkedAppParams,
                MAINAPPLICATIONID : inputParams.APPLICATIONID,
                APPLICATIONID : (selectedRow) ? selectedRow.DOCUMENTID : "",
                mainCollateralTypeFlag : form.getMainCollateralType(inputParams.collateralList, selectedRow),
                STAGESYSNAME : inputParams.STAGESYSNAME
            };
            form.actionEditCollateralApp(params);
        },
        view: function () {
            var selectedRow = form.tblCollateralListTable.getSelectedRow()[0];
            if (form.btnCollateralListAdd)
                form.btnCollateralListAdd.disable();
            var params = {
                COLLATERALMODE   : "VIEW",
                formParams  : selectedRow,
                extraParams : linkedAppParams,
                MAINAPPLICATIONID : inputParams.APPLICATIONID,
                APPLICATIONID : (selectedRow) ? selectedRow.DOCUMENTID : "",
                STAGESYSNAME : inputParams.STAGESYSNAME
            };
            form.actionEditCollateralApp(params);
        }
    };
    var obj = {
        gridId: grId,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            var selectedRow = form.tblCollateralListTable.getSelectedRow()[0];
            if (selectedRow.typeCollateral == "Main") {
                options.items.push({caption: form.getResourceBundle('edit'), click: this.options.edit});
            }
            options.items.push({caption: form.getResourceBundle('view'), click: this.options.view});
        }
    };
    obj.options = options;
    return obj;
})('tblCollateralList');

form.actionEditCollateralApp = function(params) {

    form.startNewPageFlowProcess("${collateral}",  form.getCurrentProjectSysname() + '/' + 'FORMLIB/inputCollateralApp/inputCollateralInformation', params, true, null, function(p){});
};

form.getMainCollateralType = function (list, row) {
    if (list) {
        for (var i = 0, countI = list.length; i < countI; i++) {
            if (list[i].sysnameTypeCollateral == "main") {
                if (row != undefined) {
                    if (list[i].LinkID == row.LinkID) {
                        continue;
                    }
                }
                return true;
            }
        }
    }
    return false;
};

form.prepareData = function(){
        form.dsCall('[refws]', 'dsreferenceitembrowselistbyparam', {
            ReferenceSysName:"approverLevelLOS"
        }).then(function(p){
            let list = p.data.Result;
            if (list){
                form.settings.approverLevelAll = [];
                for (var i = 0; i < list.length; i++){
                    form.settings.approverLevelAll.push({
                        code: list[i].ReferenceItemCode,
                        text: list[i].ReferenceItemBrief,
                        params: list[i].ReferenceItemComment ? JSON.parse(list[i].ReferenceItemComment) : {}
                    });

                }
                form.prepareComboValues(form.settings.approverLevelAll, "approverLevel_ITEMS", "cbApproverLevel");
            }
        });

        form.dsCall('[refws]', 'dsreferenceitembrowselistbyparam', {
            ReferenceSysName:"productCustomerGroupLOS"
        }).then(function(p){
            let list = p.data.Result;
            if (list){
                form.settings.customerGroupAll = [];
                for (var i = 0; i < list.length; i++){
                    form.settings.customerGroupAll.push({
                        code: list[i].ReferenceItemCode,
                        text: list[i].ReferenceItemBrief,
                        params: list[i].ReferenceItemComment ? JSON.parse(list[i].ReferenceItemComment) : {}
                    });
                }
                form.prepareComboValues(form.settings.customerGroupAll, "customerGroup_ITEMS", "cbProductCustomerGroup");
            }
        });
};

form.getBPConditionParamValues = function(){
    var PRODUCTID = form.formParams.bankProductId;
    if (!PRODUCTID) return;

    var PARAMTYPELIST = ["flowVisibilityLOS","approverLevelVisibilityLOS","customerGroupVisibilityLOS","paymentAccountNumberVisibilityLOS"];
    var dsCallparams = {
        PRODUCTID: PRODUCTID,
        PARAMTYPELIST: PARAMTYPELIST,
        RETURN_ABSOLUTE_PARAM:true
    };

    return form.dsCall('[frontws2]', 'bankProductParamGetListByProductId', dsCallparams).then(function (response){
        service.lgr(response);
        var resList = response.data.Result || [];
        for (var i=0; i<resList.length;i++){
            var items = resList[i];
            switch (items["PARAMTYPE"]){
                case "flowVisibilityLOS":
                    form.showFlow = true;
                    break;
                case "approverLevelVisibilityLOS":
                    form.showApproverLevel = true;
                    break;
                case "customerGroupVisibilityLOS":
                    form.showCustomerGroup = true;
                    break;
                case "paymentAccountNumberVisibilityLOS":
                    form.showPaymentAccountNumber = true;
                    break;
            }
        }
    }).catch(function (e){
        form.showErrorDialog('error', function(){}, [{caption: 'OK'}]);
    });
};

form.prepareComboValues = function(list, shortListName, componentName){
    setTimeout(function () {
        form.settings[shortListName] = [];
        for (var i = 0; i < list.length; i++){
            let params = list[i].params || {};
            let isAvaliable = true;
            for (let k in params){
                if (params.hasOwnProperty(k) && params[k]){
                    let arr = params[k] || [];
                    if (arr.length && arr.indexOf(form.formParams[k]) == -1){
                        isAvaliable = false;
                        break;
                    }
                }
            }
            if (isAvaliable){
                form.settings[shortListName].push(list[i]);
            }
        }
        if (form[componentName]){
            form[componentName].refresh();
        }}, 100);
};