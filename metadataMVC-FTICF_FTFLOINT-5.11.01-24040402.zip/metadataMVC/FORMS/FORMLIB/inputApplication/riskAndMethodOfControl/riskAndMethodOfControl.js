/*DSMETA version = "5.11.01-24040402" hash = "9273806cf559722c56878e8766948bd456429ea7"*/
/* global form, service */


function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
var service = registerMethod(service);
var gRB = service.gRB;
form.riskToPayBackLoanText =(  form.inputParams.formParams.riskToPayBackLoan        === undefined ? gRB('noDate'): form.inputParams.formParams.riskToPayBackLoan )  + " — "+
                            (  form.inputParams.formParams.riskToPayBackLoanComment === undefined ? gRB('noDate'): form.inputParams.formParams.riskToPayBackLoanComment );

form.riskOfCollateralText  =(  form.inputParams.formParams.riskOfCollateral         === undefined ? gRB('noDate'): form.inputParams.formParams.riskOfCollateral )  + " — "+
                            (  form.inputParams.formParams.riskOfCollateralComment  === undefined ? gRB('noDate'): form.inputParams.formParams.riskOfCollateralComment );

form.otherRisksText        =(  form.inputParams.formParams.otherRisks               === undefined ? gRB('noDate'): form.inputParams.formParams.otherRisks )  + " — "+
                            (  form.inputParams.formParams.otherRisksComment        === undefined ? gRB('noDate'): form.inputParams.formParams.otherRisksComment );

var convertDate = service.convertDate;
var getTableContent = service.getTableContent;


form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.isFormEditMode = form.inputParams.EDITMODE || false;
form.isFormEditModeMain = form.inputParams.EDITMODE;

var inputParams = form.inputParams;
var outputParams = form.outputParams;

form.formParams = inputParams.formParams || {};
outputParams.formParams = form.formParams;


var lgr = service.lgr;
var nvl = service.nvl;
service.lgr(form.inputParams.formParams);
form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
};
form.requiredElements = [
    "rbRiskToPayBackLoan",
    "edRiskToPayBackLoanComment",
    "rbRiskOfCollateral",
    "edRiskOfCollateralComment",
    "rbOtherRisks",
    "edOtherRisksComment",

    "edCheckPurpose",
    "edBusinessActivities",
    "edCreditPractice",
    "edCollateralCheck",
    "edCollateralRevaluation",

    "edLegalProceedings",
    "edLevelOfCooperation",
    "edRighteousCharacteristic",
    "edGeneralCommentAboutCustomer",
    "edLegalAndRelativStatus"
];
inputParams.riskToPayBackLoan_ITEMS = [{
    value: 'low',
    text: gRB('low')
}, {
    value: 'medium',
    text: gRB('medium')
}, {
    value: 'high',
    text: gRB('high')
}
];

form.verifyForm = function (showFlag, tag) {

    var verified = true;
    var buttonNextSave = (form.isLastWizForm) ? "btnSave" : "btnNext";
    if (tag === 'CLOSE') {
        buttonNextSave = "btnCancel";
    }

    try {
        console.log('verifyForm');
        console.log('r ',form.requiredElements.join(','));
        if ((form.validateControlsByIds(form.requiredElements.join(','), showFlag === true ? buttonNextSave : undefined).isShowFormErrors)) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    outputParams.VERIFIED = verified;
    console.log('verified ',verified);
    return verified;
};

form.executeCommand = function (msg) {

    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE') {
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};

form.yesFunc = function() {
    outputParams.TRANSTYPE = 'SAVEDRAFT';
    form.sendForm('GO', false);
};

form.action = function (tag) {

    outputParams.TRANSTYPE = tag;
    if (form.isFormEditModeMain) {
        outputParams.formParams.riskToPayBackLoanSysName                = form.rbRiskToPayBackLoan.getValue();
        outputParams.formParams.riskToPayBackLoan                       = gRB(form.rbRiskToPayBackLoan.getValue());
        outputParams.formParams.riskOfCollateralSysName                 = form.rbRiskOfCollateral.getValue();
        outputParams.formParams.riskOfCollateral                        = gRB(form.rbRiskOfCollateral.getValue());
        outputParams.formParams.otherRisksSysName                       = form.rbOtherRisks.getValue();
        outputParams.formParams.otherRisks                              = gRB(form.rbOtherRisks.getValue());
    }
    if (tag === 'CLOSE') {
        if(form.inputParams.EDITMODE === false){
            form.sendForm('GO',false);
        }else{
            form.verifyForm(true, tag);
            service.showDialogCancelConfirm(
                form,
                form.yesFunc
            )
        }
    }
    else {
        if (tag === 'NEXT' && !form.verifyForm(true) ) {
            return;
        }else{
            form.verifyForm(false);
        }
        form.sendForm('GO', false);

    }
}