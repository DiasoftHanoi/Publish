/*DSMETA version = "5.08.01-22060701" hash = "32ef9c3dcc8aeed9c8f83b4aba0ce461b88c831b"*/
function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var lgr = service.lgr;
var nvl = service.nvl;
var gRB = service.gRB;

form.formParams = form.inputParams.formParams || {};
form.showDecisionMaking = form.inputParams.showDecisionMaking;
var outputParams = form.outputParams;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.requiredElements = [
    "decisionMakingGeneralTemplate"
];

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    if (tagName === 'CLOSE') {
        if (!form.showDecisionMaking){
            form.sendForm('NEXT',false);
        }else {
            form.verifyForm(true, tagName);
            service.showDialogCancelConfirm(
                form,
                function () {
                    outputParams.TRANSTYPE = 'SAVEDRAFT';
                    form.sendForm('NEXT', false);
                },
                function () {
                    outputParams.TRANSTYPE = 'CLOSE';
                    form.sendForm('NEXT', false);
                }
            )
        }
    } else {
        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('NEXT', false);
    }
};

form.attachmentTemplateData = {
    parentForm: form,
    fabPageFlowService: fabPageFlowService,
    isEnableButtonComplete : true
};

form.decisionTemplateData = {
    parentForm: form,
    fabPageFlowService: fabPageFlowService
};

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
};

form.executeCommand = function (msg) {
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE') {
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
    if (msg.event === 'GO_TO_PAGEFLOW'){
        form.startNewPageFlowProcess(msg.caption, msg.params.PAGEFLOW, {
            APPLICATIONID: msg.params.APPLICATIONID,
            EDITMODE: false
        });
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var btnNext = (form.isLastWizForm) ? "btnSave" : "btnNext";
        if (form.applicationListAttachmentTemplate.subjectPnl2) {
            throw {
                type: 'logic',
                msg: gRB('dialog.attachAllError')
            };
        }
        if (form.validateControlsByIds(form.requiredElements.join(','), showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {lgr(e);
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok') 
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};