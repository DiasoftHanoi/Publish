/*DSMETA version = "5.08.01-22060701" hash = "032e1f0931843cadb09605bba3074159063279ee"*/
////////////////////////////////////////////////////////////////////
function registerMethod(initService){
	var service={};
	for (var ar in initService){
		if (initService.hasOwnProperty(ar)){
			if (ar.indexOf('Service')>-1 || typeof (initService[ar]) != 'function'){
				service[ar]=initService[ar];
			}else{
				var fn=initService[ar].toString();
				var sIdx=fn.search(/\(/)+1;
				var eIdx=fn.search(/\)\{/);
				var args=fn.substring(sIdx,eIdx)
				eval("service."+ar+"=function("+args+")"+fn.substring(eIdx+1,fn.length));
			}
		}
	}
	return service;
}
////////////////////////////////////////////////////////////////////
form.baseTab = fabPageFlowService.getCurrentTabObj();
service=registerMethod(service);
var nvl=service.nvl;
var gRB=service.gRB;
var gRBT=service.gRBT;
var getInputParams=service.getInputParams;
var setOutputParams=service.setOutputParams;
var lgr=service.lgr;
var getNewMap=service.getNewMap;
var getNewList=service.getNewList;
var sendForm=service.sendForm;
var dsCall2=service.dsCall2;
var getSettingValue=service.getSettingValue;
var showAlert=service.showAlert;
var sendMessage=service.sendMessage;
form.executeCommand = service.commonExecuteCommand


form.onFileChange=function(){
	lgr("onFileChange",arguments);
	form.uploadFlag=false;
}
form.onFileUpload=function(p){
	lgr("onFileUpload",arguments);
	form.uploadFlag=true;
	var data=p;
	if (data){
		var map={
			HASHCODE:data.tempKey,
			DISKFILENAME:data.value,
			FILENAME:data.fileName,
			FILETYPE:data.fileType,
			FILESIZE:data.fileSize
		}
		setOutputParams("uploadFile",map);
	}
}
form.onFileInvalid=function(){
	lgr("onFileInvalid",arguments);
	form.uploadFlag=false;
	form.showError(form.uploader.popover.error.content, function () {}, [{
			caption : "OK"
		}
	]);
}

form.onNext=function(){
	setOutputParams('ATTACHTYPENAME',form.attachmentType.getValue());
	form.sendForm("EXECUTE", true);
}
form.onCancel=function(){
	form.sendForm("CANCEL",false);
}