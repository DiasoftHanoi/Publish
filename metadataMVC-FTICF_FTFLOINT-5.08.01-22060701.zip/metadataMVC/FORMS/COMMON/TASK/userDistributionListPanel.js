/*DSMETA version = "5.08.01-22060701" hash = "288e10c5e89a2f3cebd3cd74811dda20114c0d01"*/
function registerMethod(initService){
    var service={};
    for (var ar in initService){
        if (initService.hasOwnProperty(ar)){
            if (ar.indexOf('Service')>-1 || typeof (initService[ar]) != 'function'){
                service[ar]=initService[ar];
            }else{
                var fn=initService[ar].toString();
                var sIdx=fn.search(/\(/)+1;
                var eIdx=fn.search(/\)\{/);
                var args=fn.substring(sIdx,eIdx)
                eval("service."+ar+"=function("+args+")"+fn.substring(eIdx+1,fn.length));
            }
        }
    }
    return service
}
service=registerMethod(service);

var inputParams = form.inputParams || {};
var outputParams = form.outputParams || {}
form.searchParams = inputParams.searchParams || {};

var lgr = service.lgr;
var nvl = service.nvl;
var gRB = function(key){
    return service.nvl(form.localize[key],key);
};
form.gRB = gRB;

form.onSearch = function(){
    var params = angular.copy(form.searchParams);
    form.command({
        event:'SEARCH',
        params: params
    });

};

form.onClearSearchParams = function(){
    delete form.searchParams.userState;
    delete form.searchParams.filterUserID;
};

form.params = {
    ITEMS: [{
            text: gRB('taskList.Active'),
            value: 'ACTIVE'
        },
        {
            text: gRB('taskList.Inactive'),
            value: 'INACTIVE'
        }
    ],
    Users: {
            ROLEID: form.searchParams.ROLES.length ? form.searchParams.ROLES[0].ROLEID : -1,
            EmployeeStatus: 'ACTIVE'
    }    
};