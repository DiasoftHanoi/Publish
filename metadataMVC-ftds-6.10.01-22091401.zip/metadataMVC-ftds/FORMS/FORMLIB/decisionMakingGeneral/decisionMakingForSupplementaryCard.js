/* global form, service */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
var service = registerMethod(service);
var strToBool = service.strToBool;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.isFormEditMode = strToBool(form.inputParams.EDITMODE);
var inputParams = form.inputParams;
var outputParams = form.outputParams;
form.formParams = inputParams.formParams || {};
outputParams.formParams = form.formParams;
form.formStageParams = inputParams.formStageParams || {};
outputParams.formStageParams = form.formStageParams;
form.secondSupplementatyCard=form.formParams.secondSupplementatyCard || {};

form.setCommentRequired = function () {
    return (form.formParams.REFSYSNAME == 'reject');
};

var lgr = service.lgr;
service.lgr(form.params);

form.templateData = form;

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
    if (form.isFormEditMode) {
        form.getBPparamValues();
    }
};

form.getBPparamValues = function(){

    var PARAMTYPELIST = [
        "minTerm",
        "maxTerm",
        "minCreditLimit",
        "maxCreditLimit"
    ];
    var PRODUCTID = form.formStageParams.bankProductId;
    if (!PRODUCTID) return;
    var dsCallparams = {
        PRODUCTID: PRODUCTID,
        PARAMTYPELIST: PARAMTYPELIST,
        RETURN_ABSOLUTE_PARAM:true
    };

    return form.dsCall('[frontws2]', 'bankProductParamGetListByProductId', dsCallparams).then(function (response){

        service.lgr(response);
        for (var i=0; i<response.data.Result.length;i++){
            var items = response.data.Result[i];
            switch (items["PARAMTYPE"]){
                case "minTerm":
                    inputParams.minTerm_ITEMS = items["VALUES"];
                    break;
                case "maxTerm":
                    inputParams.maxTerm_ITEMS = items["VALUES"];
                    break;
                case "minCreditLimit":
                    inputParams.minCreditLimit_ITEMS = items["VALUES"];
                    break;
                case "maxCreditLimit":
                    inputParams.maxCreditLimit_ITEMS = items["VALUES"];
                    break;
            }
        }
        if(form.cbCardType){
            form.formParams.bankProductNameStage=form.cbCardType.getText();
        }

    }).catch(function (e){
        form.showErrorDialog('error', function(){}, [{caption: 'OK'}]);
    });
};

form.verifyForm = function (showFlag) {
    var verified = true;
    var buttonNextSave = (form.isLastWizForm) ? "btnSave" : "btnNext";
    try {
        if ((form.validateControlsByIds(form.requiredElements.join(','), showFlag === true ? buttonNextSave : undefined).isShowFormErrors)) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    outputParams.VERIFIED = verified;
    return verified;
};
form.executeCommand = function (msg) {
	switch (msg.event) {
        case 'FAB_NAVIGATOR_NAVIGATE':
            outputParams.NEXTPAGE = msg.params.step;
            form.action('DIRECT');
            break;
        case 'GO_TO_PAGEFLOW':
            form.startNewPageFlowProcess(msg.caption, msg.params.PAGEFLOW, {
                APPLICATIONID: msg.params.APPLICATIONID,
                EDITMODE: false
            });
            break;
        case 'processingStage':
            form.startNewPageFlowProcess(msg.caption, "FTFLOINTMVC/COMMON/APPLICATION/PROCESSING/applicationProcessing", {
                APPLICATIONID: form.inputParams.APPLICATIONID
            });
            break;
        case 'attachedDocuments':
            form.startNewPageFlowProcess(msg.caption, "FTFLOINTMVC/COMMON/APPLICATION/applicationListAttachment", {
                APPLICATIONID: form.inputParams.APPLICATIONID
            });
            break;
            
    }
};

form.yesFunc = function() {
    outputParams.TRANSTYPE = 'SAVEDRAFT';
    if (form.verifyForm()) {
        form.sendForm('GO', false);
    }
};

form.action = function (tag) {
    outputParams.TRANSTYPE = tag;
    form.formStageParams.bankProductName = (form.cbCardType) ? form.cbCardType.getText() : "";
     if (form.edCreditLimit) {
       form.formStageParams.secondSupplementatyCard.approvedLimit = form.edCreditLimit.getText();
     }

    if (tag === 'CLOSE') {
        service.showDialogCancelConfirm(
            form,
            form.yesFunc,
            form.noFunc
        )
    }
    else {
        form.sendForm('GO', false);

    }
};
form.noFunc = function(){
    if (inputParams.FORMLIST && inputParams.FORMLIST.length > 0) {
        form.sendForm('GO',false);      // Если форма в мастере
    } else {
        form.sendForm('CANCEL', false); // Если форма отдельно в decisionMakingINT
    }
};
