form.outputParams = {};

form.formParams = form.inputParams;
form.outputParams = form.formParams;

form.onShow = function () {

};

form.action = function (tag) {
    form.sendForm(tag,false);
};