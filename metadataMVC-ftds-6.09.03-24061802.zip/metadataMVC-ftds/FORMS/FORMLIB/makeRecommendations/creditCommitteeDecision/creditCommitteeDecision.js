/* global form, service */
function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);
var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;
form.formParams.userGroupList_ITEM= inputParams.formParams.userGroupList_ITEM || [];

form.getUserGroupList=function(){
    for (var i = 0; i < form.formParams.userGroupList.length; i++) {
        var items1 = form.formParams.userGroupList[i]["Children"];
        for (var j = 0; j < items1.length; j++) {
            var items2 = items1[j];
            if (items2["NAME"] === "Credit Committee") {
                for (var k = 0; k < items2["Children"].length; k++) {
                    var itm = {};
                    itm["value"] = items2["Children"][k]["NODEID"];
                    itm["text"] = items2["Children"][k]["NAME"];
                    form.formParams.userGroupList_ITEM.push(itm);
                }
            }
        }
    }
};

form.getUserGroupList();
form.isShowCode = form.formParams.CODE !== '' ? true : false;
var outputParams = form.outputParams || {};
outputParams.formParams = form.formParams;
var employeeRoleSysName = form.formParams.employeeRoleSysName;
var lgr = service.lgr;
var nvl = service.nvl;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.isFormEditMode = form.inputParams.EDITMODE || 'true';
form.pnlParticipantIsCollapsed = !form.formParams.participantList || form.formParams.participantList.length == 0;

form.onShow = function () {

    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
    form.tblParticipantObj.setItems(form.formParams.participantList || []);
    if(form.formParams.memberList!==null && (form.formParams.memberList || []).length>0){
        form.tblMembersObj.setItems(form.formParams.memberList || []);
    }else{
        form.getMembers(true);
    }

    if (form.isFormEditMode == 'false') {
        form.edStartTimeCreditCommittee.setText(form.formParams.startTimeCreditCommittee.replace(/(\d\d)(\d\d)/, '$1:$2'));
        form.edEndTimeCreditCommittee.setText(form.formParams.endTimeCreditCommittee.replace(/(\d\d)(\d\d)/, '$1:$2'));
    }
};
form.dateTimeSplitObj= {
    onChangeStart: function () {
        var val = form.clStartDateCreditCommittee.getValue();
    },
    checkTimeStart: function () {
        var time = form.formParams.startTimeCreditCommittee;
        if (time != undefined) {
            if (time.length > 1) {
                if (time.substring(0, 2) > 23) {
                    form.edStartTimeCreditCommittee.setValue("");
                }
            }
            if (time.length > 2) {
                if (time.substring(2, 4) > 59) {
                    form.edStartTimeCreditCommittee.setValue("");
                }
            }
        }
    },
    checkTimeEnd:function(){
        var time = form.formParams.endTimeCreditCommittee;
        if (time != undefined) {
            if (time.length > 1) {
                if (time.substring(0, 2) > 23) {
                    form.edEndTimeCreditCommittee.setValue("");
                }
            }
            if (time.length > 2) {
                if (time.substring(2, 4) > 59) {
                    form.edEndTimeCreditCommittee.setValue("");
                }
            }
        }
    }

};

form.executeCommand = function (msg) {
    switch (msg.event) {
        case 'FAB_NAVIGATOR_NAVIGATE':
            outputParams.NEXTPAGE = msg.params.step;
            form.action('DIRECT');
        break;
        default:
            break;
    }
};
form.templateData = {
    inputParams: form.inputParams,
    parentForm: form
};

form.settings = {
    cbDivisionRiskValuation:JSON.stringify( {
        ReferenceSysName: 'divisionRiskValuationLOS',
        ORDERBY: 'ReferenceItemID'
    }),
    cbCreditCommitteeMeetingMethod:JSON.stringify( {
        ReferenceSysName: 'meetingMethodLOS',
        ORDERBY: 'ReferenceItemID'
    }),
    cbCreditCommitteeGroup:JSON.stringify( {
        ReferenceSysName: 'creditCommitteeLOS',
        ORDERBY: 'ReferenceItemID'
    })

};
form.getMembers=function(flag){
    var GROUPID;
    if(flag){
        GROUPID=form.formParams.creditCommitteeGroupSysName;
    }else{
        GROUPID = form.cbCreditCommitteeGroup.getValue();
    }
    if (!GROUPID || form.formParams.creditCommitteeGroupSysName===undefined) return;

    service.pageflowCall2(form.getCurrentProjectSysname(), 'COMMON/decisionMaking/getPosition',
        {
            GROUPID : GROUPID
        },
        function (p) {
            form.tblMembersObj.setItems(p.memberList || []);
        },
        form
    );

};
form.tblMembersObj = (function(grId){

    var gridId = grId;
    var options = {
        responsibleType: {
            methodParams: JSON.stringify({
                //RoleSysName : employeeRoleSysName
                //DepartmentIDList : inputParams.DepartmentIDList
            }),
            lookupFields: [
                {
                    value: "USERLOGIN",
                    caption: gRB("User.login"),
                    width: 3
                },
                {
                    value: "EMPLOYEENAME",
                    caption: gRB("User.name"),
                    width: 9
                }
            ]
        },
        presentOrAbsentList : [{
            value: 'present',
            text: gRB('Members.present')
        }, {
            value: 'absent',
            text: gRB('Members.absent')
        }
        ],
        data: {},
        clearFields: function () {
            options.data.presentOrAbsentSysName = 'present';
            delete options.data.comment;
        },
        cancelFields:function(){
            options.clearFields();
            form[gridId].hideEditor();
        },
        saveFields:function(){
            var selectedRow = form.tblMembers.getSelectedRow()[0];
            selectedRow["presentOrAbsentSysName"] =  form.btPresentOrAbsent.getValue();
            selectedRow["presentOrAbsent"]        =  form.btPresentOrAbsent.getValue()==='present'?gRB('Members.present'):gRB('Members.absent');
            selectedRow["comment"]                = form.edComment.getValue();
           // var newRow['id'] = selectedRow['id'];
            form[gridId].hideEditor();
            form[gridId].updateRow(obj.selectedId, selectedRow);
        },
        edit: function () {
            options.clearFields();
            var selectedRow = form.tblMembers.getSelectedRow()[0];
            form[gridId].showEditor('edit');
            form.tblMembersObj.options.data = {
                memberName             : selectedRow["memberName"],
                positionMember         : selectedRow["positionMember"],
                presentOrAbsentSysName : selectedRow["presentOrAbsentSysName"],
                presentOrAbsent        : selectedRow["presentOrAbsent"],
                comment                : selectedRow["comment"]
            };
        },
        delete: function () {
            if (form.tblMembers.getSelectedRow()[0]) {
                form.tblMembers.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
        }
    };

    var obj = {
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (form.isFormEditMode == 'true') {
                var selRow = form[gridId].getSelectedRow()[0] || {};
                options.items = [
                    {caption: gRB('edit'),   click: form.tblMembersObj.options.edit}
                   // {caption: gRB('delete'), click: form.tblMembersObj.options.delete}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblMembers');

form.tblParticipantObj = (function(grId){

    var gridId = grId;
    var options = {
        requiredElements : [
            "edParticipantName",
            "edParticipantName"
        ],

        data: {},
        clearFields: function () {
            delete options.data.participantName;
            delete options.data.participantNameSysName;
            delete options.data.manualInput;
            delete options.data.positionParticipantManual;
            delete options.data.comment;
        },
        cancelFields:function(){
            options.clearFields();
            form[gridId].hideEditor();
            form.btnAdd.enable();
        },
        saveFields:function(){
            var selectedRow = form.tblParticipant.getSelectedRow()[0];
            var newRow ={
                participantName             : form.chkManualInput.isChecked() ? form.edParticipantName.getValue() : form.edParticipantName.getText(),
                participantNameSysName      : form.chkManualInput.isChecked() ? undefined : form.edParticipantName.getValue(),
                manualInput                 : form.chkManualInput.getValue(),
                positionParticipantManual   : form.edPositionParticipant.getValue(),
                comment                     : form.edComment.getValue()

            };
            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['id'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnAdd.enable();
        },
        edit: function () {
            options.clearFields();
            var selectedRow = form.tblParticipant.getSelectedRow()[0];
            form[gridId].showEditor('edit');
            form.tblParticipantObj.options.data = {
                participantName               : selectedRow["participantName"],
                participantNameSysName        : selectedRow["participantNameSysName"],
                manualInput                   : selectedRow["manualInput"],
                positionParticipantManual     : selectedRow["positionParticipantManual"],
                comment                       : selectedRow["comment"],
            };
            form.btnAdd.disable();
        },
        delete: function () {
            if (form.tblParticipant.getSelectedRow()[0]) {
                form.tblParticipant.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
            form.btnAdd.enable();
        }
    };

    var obj = {
        addNewRow: function () {
            form.pnlParticipant.isCollapsed = false;
            form[gridId].showEditor('add');
            options.clearFields();
            form.btnAdd.disable();
        },
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (form.isFormEditMode == 'true') {
                var selRow = form[gridId].getSelectedRow()[0] || {};
                options.items = [
                    {caption: gRB('edit'),   click: form.tblParticipantObj.options.edit},
                    {caption: gRB('delete'), click: form.tblParticipantObj.options.delete}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblParticipant');

form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var save =  form['save'];

        if (form.validateControlsByIds('*', showFlag === true ? save : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.yesFunc = function() {

    outputParams.TRANSTYPE = 'SAVEDRAFT';
    if (form.verifyForm()) {
        form.sendForm('GO', false);
    }
};
form.Responsible = {
    responsibleType: {
        methodParams: JSON.stringify({
            RoleSysName : employeeRoleSysName,
            DepartmentIDList : inputParams.DepartmentIDList
        }),
        lookupFields: [
            {
                value: "USERLOGIN",
                caption: "Login",
                width: 3
            },
            {
                value: "LASTNAME",
                caption: "Name",
                width: 9
            }
        ]
    }
};
form.GetIncomeListText=function(value){
    var str="fieldCheck."+value;
    return form.getResourceBundle(str);
};
form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
    if(form.isFormEditMode==='true'){
        form.formParams.divisionRiskValuation                   = form.cbDivisionRiskValuation.getText();
        form.formParams.divisionRiskValuationSysName            = form.cbDivisionRiskValuation.getValue();
        form.formParams.creditCommitteeMeetingMethodSysName     = form.cbCreditCommitteeMeetingMethod.getValue();
        form.formParams.creditCommitteeMeetingMethod            = form.cbCreditCommitteeMeetingMethod.getText();
        form.formParams.creditCommitteeGroup                    = form.cbCreditCommitteeGroup.getText();
        form.formParams.memberList                              = form.tblMembersObj.getItems();
        form.formParams.participantList                         = form.tblParticipantObj.getItems();

    }
    if (tagName === 'CLOSE') {
        if(form.isFormEditMode === 'false'){
            form.sendForm('GO',false);
        }else{
            service.showDialogCancelConfirm(
                form,
                form.yesFunc
            )
        }
    } else {
        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};

form.getRefSysNameText= function(value){
    for(var i=0;i<form.formParams.decisionItems.length;i++){
        var itm = form.formParams.decisionItems[i];
        if(itm["value"]==value){
             return itm["text"];
        }
    }
    return null;
};
