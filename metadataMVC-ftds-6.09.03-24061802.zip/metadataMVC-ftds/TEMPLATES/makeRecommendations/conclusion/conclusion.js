template.formParams = template.data.parentForm.inputParams.formParams || {};
template.settings = {
    cbDivisionRiskValuation:JSON.stringify( {
        ReferenceSysName: 'divisionRiskValuationLOS',
        ORDERBY: 'ReferenceItemID'
    }),
};
template.isShowCode=template.formParams.CODE!==''?true:false;
template.isFormEditMode = (template.data.parentForm.inputParams.EDITMODE==true || template.data.parentForm.inputParams.EDITMODE=='true') ? 'true' : 'false';

