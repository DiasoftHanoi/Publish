/*DSMETA version = "5.08.01-HF009-23110205" hash = "d9d5761a865f3740ea7b2ca412c79fbcc2eed529"*/
function ftfwfCopyFilesById(UploadRule){
	var keys = getNewList();
	number = 0;
	logger.info("##### STORAGE=" + STORAGE);
	for (var i = 0, cnt = ATTACHE_LIST.size(); i < cnt; i++) {
		var attach = ATTACHE_LIST.get(i);
		if (attach.get('ATTFILEPATH') != null && attach.get('ATTFILEPATH') != 'undefined') {
            keys.add(formAttachMap(attach,UploadRule));
		}
		if (keys.size()==10){
			copyFilesById(keys, 'ECM_SharePoint'/*+new String(STORAGE)*/);
			logger.info("##### keys partial=" + keys);
			keys = getNewList();
		}
	}

	logger.info("##### keys final=" + keys);
	if (keys.size() > 0) copyFilesById(keys, 'ECM_SharePoint'/*+new String(STORAGE)*/);
}

function formAttachMap(item,UploadRule){
	var map = new java.util.HashMap();
	var attach = item;
	var ATTFILEPATH = ''+attach.get("ATTFILEPATH");
	//map.put("fileId", attach.get("ATTNAME"));
	map.put("fileInfoId", attach.get("ATTFILEPATH"));
	//map.put("storage", "FILE");
	logger.debug("ATTACHTYPENAME = "+attach.get("ATTACHTYPENAME"));
	map.put("fileName", getFileName(attach));

//	var contentType = getContentType(attach.get("ATTACHTYPENAME")+'', UploadRule);
/*	if (contentType != null) {
		map.put("contentType", contentType);
	}
*/ 
	var customProperties = getCustomProperties(attach, contentType, UploadRule);
	if (customProperties != null) {
		map.put("customProperties", customProperties);
	}
	return map;
}

function getCustomProperties(attach){
	    var customProperties = getNewMap();
		var jsonmetadata = '';

		var ColumnName = '"ColumnName":"Branch_ID",';
		var ColumnDataType = '"ColumnDataType":"string",';
		var ColumnValue = '"ColumnValue":"' + getInputParams("BRANCHID") + '"';
		jsonmetadata += '{' + ColumnName + ColumnDataType + ColumnValue + '}';

		var ColumnName = '"ColumnName":"USER_ID",';
		var ColumnDataType = '"ColumnDataType":"string",';
		var ColumnValue = '"ColumnValue":"' + getInputParams("USER_ID") + '"';
		jsonmetadata += '{' + ColumnName + ColumnDataType + ColumnValue + '}';

		var ColumnName = '"ColumnName":"Loan_ID",';
		var ColumnDataType = '"ColumnDataType":"string",';
		var ColumnValue = '"ColumnValue":"' + getInputParams("Loan_ID") + '"';
		jsonmetadata += '{' + ColumnName + ColumnDataType + ColumnValue + '}';

		var ColumnName = '"ColumnName":"Document_type",';
		var ColumnDataType = '"ColumnDataType":"string",';
		var ColumnValue = '"ColumnValue":"' + getInputParams("Document_type") + '"';
		jsonmetadata += '{' + ColumnName + ColumnDataType + ColumnValue + '}';

		var ColumnName = '"ColumnName":"DocumentName",';
		var ColumnDataType = '"ColumnDataType":"string",';
		var ColumnValue = '"ColumnValue":"' + getInputParams("DocumentName") + '"';
		jsonmetadata += '{' + ColumnName + ColumnDataType + ColumnValue + '}';


		var ColumnName = '"ColumnName":"Sub_Product_ID",';
		var ColumnDataType = '"ColumnDataType":"string",';
		var ColumnValue = '"ColumnValue":"' + getInputParams("Branch_ID") + getInputParams("USER_ID") + getInputParams("Sub_Product_ID")  + getInputParams("Loan_ID") + '"';
		jsonmetadata += '{' + ColumnName + ColumnDataType + ColumnValue + '}';

		var ColumnName = '"ColumnName":"Folder_path",';
		var ColumnDataType = '"ColumnDataType":"string",';
		var ColumnValue = '"ColumnValue":"' + getInputParams("Folder_path") + '"';
		jsonmetadata += '{' + ColumnName + ColumnDataType + ColumnValue + '}';

		jsonmetadata = '[' + jsonmetadata + ']';
		customProperties.put("jsonmetadata", jsonmetadata);

		return customProperties;
}

function getFileName(attach,UploadRule){
	
		var fileName = '';
		var CIF = ExtCode;
		if (attach.get('ExtCode')) {
			CIF = attach.get('ExtCode');
		}
		var attachType = attach.get('ATTACHTYPENAME') + '';
		var ATTNAME = attach.get('ATTNAME') + '';
		var extension = (ATTNAME && ATTNAME.lastIndexOf('.') > -1) ? ATTNAME.substring(ATTNAME.lastIndexOf('.')) : '';
		var sdf = new java.text.SimpleDateFormat("dd.MM.yyyy");
		var creationDate = (attach.containsKey("CREATIONDATE") && attach.get("CREATIONDATE") != null) ? sdf.format(attach.get("CREATIONDATE")) : '';
		var expirationDate = (attach.containsKey("ENDDATE") && attach.get("ENDDATE") != null) ? sdf.format(attach.get("ENDDATE")) : '';
		logger.debug("attachType in filename = " + attachType);

		switch (attachType) {
			case 'E-Statement':
				fileName = 'E-Statement';
				break;                                                              // Пока нет такого аттача
			case 'KTP':
				fileName = CIF + '_KTP';
				break;
			case 'SAKTP':
				fileName = CIF + '_KTP';
				break;
			case 'Tax ID':
				fileName = CIF + '_Tax ID';
				break;
			case 'Photo':
				fileName = CIF + '_Self-Photo';
				break;
			case 'clientFoto':
				fileName = CIF + '_Self-Photo';
				break;
			case 'clientPhoto':
				fileName = CIF + '_Self-Photo';
				break;
			case 'clientSignature': {
				fileName = CIF + '_Specimen Signature' + (ParticipantType == '2' ? '_0' + number : '');
				number = ParticipantType == '2' ? number + 1 : number;
				break;
				}
			case 'KCTT': {
				fileName = CIF + '_Specimen Signature' + (ParticipantType == '2' ? '_0' + number : '');
				number = ParticipantType == '2' ? number + 1 : number;
				break;
				}
			case 'SAKCTT': {
				fileName = CIF + '_Specimen Signature' + (ParticipantType == '2' ? '_0' + number : '');
				number = ParticipantType == '2' ? number + 1 : number;
				break;
				}
			case 'companyLogo':
				fileName = CIF + '_Company Stamp';// + (ParticipantType == '2' ? '_0' + number : ''); refer to stamp below
				break;
			case 'Company Stamp': {
				fileName = CIF + '_Company Stamp' + (ParticipantType == '2' ? '_0' + number : '');
				number = ParticipantType == '2' ? number + 1 : number;
				break;
				}     // Пока нет такого аттача
			case 'SIUP':
				fileName = CIF + '_SIUP' + (expirationDate != '' ? '_' + expirationDate :'');
				break;
			case 'TDP':
				fileName = CIF + '_TDP' + (expirationDate != '' ? '_' + expirationDate :'');
				break;
			case 'PASSPORT':
				fileName = CIF + '_Passport' + (expirationDate != '' ? '_' + expirationDate :'');
				break;
			case 'KIMS/KITAP/KITAS':
				fileName = CIF + '_KITAS' + (expirationDate != '' ? '_' + expirationDate :'');
				break;

			case 'FPR_BO_individual':
				fileName = CIF + '_' + attachType + '_BO_' + creationDate;
				break;
			case 'FPR_BO_non_individual':
				fileName = CIF + '_' + attachType + '_BO_' + creationDate;
				break;

			//common name
			default:
				fileName = getCustomerFormName(attach, attachType, creationDate);
				break;

			/*default:
				fileName = CIF + '_' + attachType + '_' + creationDate;
				break;*/
		}
		fileName = fileName + extension
	
	return fileName;
}

function getCustomerFormName(attach, attachType, attachCreationDate){
	var CIF = ExtCode;
	if (attach.get('ExtCode') != null) {
		CIF = attach.get('ExtCode');
	}
	var localFileName = (CIF!='' ? CIF+'_' : '')+(AccountNumber!='' ? AccountNumber+'_' : '') +attachType+'_'+attachCreationDate;
	return localFileName;
}
