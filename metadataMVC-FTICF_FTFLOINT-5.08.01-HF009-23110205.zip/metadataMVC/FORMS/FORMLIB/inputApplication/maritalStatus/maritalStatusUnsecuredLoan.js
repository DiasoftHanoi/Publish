/*DSMETA version = "5.08.01-HF009-23110205" hash = "50fbe721dc5e3da8c50ab30ec6bde21c63168b52"*/
/* global form, service */

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;
form.formParams.clientInAppMap = inputParams.formParams.clientInAppMap || {};

var outputParams = form.outputParams || {};
outputParams.formParams = form.formParams;
outputParams.formParams.clientInAppMap = form.formParams.clientInAppMap;

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\s*\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);
var lgr = service.lgr;
var nvl = service.nvl;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.isFormEditMode = form.inputParams.EDITMODE || false;

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
    form.tblLiabilities.setItems(form.formParams.Liabilities || []);
    if (inputParams.currencyList.length == 1){
        form.tblLiabilitiesObj.options.settings.cmbCurrency.enabled = false;
    }
};

form.executeCommand = function(msg){
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
    if (msg.event === 'GO_TO_PAGEFLOW'){
        form.startNewPageFlowProcess(msg.caption, msg.params.PAGEFLOW, {
            APPLICATIONID: msg.params.APPLICATIONID,
            EDITMODE: false
        });
    }
};

form.settings = {
    educationLevelParams : {
        ReferenceGroupName: 'Unsecured Loan Application',
        ReferenceSysName: 'EducationConsLOS',
        ORDERBY: 'ReferenceItemID'
    },
    houseOwnershipParams : {
        ReferenceGroupName: 'Unsecured Loan Application',
        ReferenceSysName: 'housingOwnershipConsLOS',
        ORDERBY: 'ReferenceItemID'
    },
    transportationParams : {
        ReferenceGroupName: 'Unsecured Loan Application',
        ReferenceSysName: 'transportationOwnershipConsLOS',
        ORDERBY: 'ReferenceItemID'
    },
    customerMobileDeviceParams : {
        ReferenceGroupName: 'Unsecured Loan Application',
        ReferenceSysName: 'mobileDeviceTypeConsLOS',
        ORDERBY: 'ReferenceItemID'
    }
};

form.tblLiabilitiesObj = (function (grId) {
    var gridId = grId;
    var options = {
        settings: {
            cmbCurrency: {
                enabled: true
            }
        },
        currencyList: inputParams.currencyList,

        cancel: function () {
            options.clearFields();
            form[gridId].hideEditor();
            form.btnLiabilitiesAdd.enable();
        },
        save: function () {
            var selectedRow = form.tblLiabilities.getSelectedRow()[0];
            var newRow = {
                borrowerName              : form.edBorrowerName.getValue(),
                bankName                  : form.edBankName.getValue(),
                loanType                  : form.edLoanType.getValue(),
                outstandingAmount         : form.edCurrentOutstandingBalance.getValue(),
                currencyOutstandingAmount : form.cmbOutstandingCurrency.getValue(),
                monthlyPaymentAmt         : form.edMonthlyPayable.getValue(),
                currencyMonthlyPaymentAmt : form.cmbLoanCurrency.getValue(),
                remainingMonthsRepay      : form.edRemainingMonthsRepay.getValue()
            };
            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);
            } else {
                newRow['id'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnLiabilitiesAdd.enable();
        },
        clearFields: function () {
            delete options.borrowerName;
            delete options.bankName;
            delete options.loanType;
            delete options.outstandingAmount;
            (form.cmbOutstandingCurrency && form.cmbOutstandingCurrency.getItems().length > 1) ?  delete options.currencyOutstandingAmount : undefined;
            delete options.monthlyPaymentAmt;
            (form.cmbLoanCurrency && form.cmbLoanCurrency.getItems().length > 1) ?  delete options.currencyMonthlyPaymentAmt : undefined;
            delete options.remainingMonthsRepay;
        },
        edit: function () {
            options.clearFields();
            var selectedRow = form.tblLiabilities.getSelectedRow()[0];
            form[gridId].showEditor('edit');
            options.borrowerName              = selectedRow["borrowerName"];
            options.bankName                  = selectedRow["bankName"];
            options.loanType                  = selectedRow['loanType'];
            options.outstandingAmount         = selectedRow['outstandingAmount'];
            options.currencyOutstandingAmount = selectedRow['currencyOutstandingAmount'];
            options.monthlyPaymentAmt         = selectedRow['monthlyPaymentAmt'];
            options.currencyMonthlyPaymentAmt = selectedRow['currencyMonthlyPaymentAmt'];
            options.remainingMonthsRepay      = selectedRow['remainingMonthsRepay'];
            form.btnLiabilitiesAdd.disable();
        },
        delete: function () {
            if (form.tblLiabilities.getSelectedRow()[0]) {
                form.tblLiabilities.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
            form.btnRevenueAdd.enable();
        }
    };

    var obj = {
        gridId: grId,
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        addNewRow: function () {
            form[gridId].showEditor('add');
            options.clearFields();
            form.btnLiabilitiesAdd.disable();
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (form.isFormEditMode == true) {
                options.items = [
                    {caption: gRB('edit'),   click: form.tblLiabilities.options.edit},
                    {caption: gRB('delete'), click: form.tblLiabilities.options.delete}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblLiabilities');

form.verifyForm = function (showFlag, tag) {
    var verified = true;
    try {
        var btnNext =  form['btnNext'] ? 'btnNext' : 'btnSave';
        if (tag === 'CLOSE') {
            btnNext = "btnCancel";
        }
        if (form.validateControlsByIds('pnlEducation,pnlFamilyInformation,,pnlLoansBorrowerHouseholdMembers', showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {lgr(e);
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;
     if(form["cmbEducationTypeBrief"]) {
        outputParams.formParams.clientInAppMap.EducationTypeBriefText = form.cmbEducationTypeBrief.getText();
     }
    if(form["cmbHouseOwnership"]) {
        outputParams.formParams.houseOwnershipName = form.cmbHouseOwnership.getText();
    }
    if(form["cmbTransportation"]) {
        outputParams.formParams.transportationOwnershipName = form.cmbTransportation.getText();
    }
    if(form["cmbCustomerMobileDevice"]) {
        outputParams.formParams.customerMobileDeviceName = form.cmbCustomerMobileDevice.getText();
    }
    if (form.isFormEditMode) {
        outputParams.formParams.Liabilities = nvl(form.tblLiabilities.getItems(), []);
    }
    if (tagName === 'CLOSE') {
        if(form.inputParams.EDITMODE === false){
            form.sendForm('GO',false);
        }else {
            form.verifyForm(true, tagName);
            service.showDialogCancelConfirm(
                form,
                function () {
                    form.outputParams.TRANSTYPE = 'SAVEDRAFT';
                    form.sendForm('GO', false);
                }
            )
        }
    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};