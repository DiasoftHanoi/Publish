DROP INDEX K02_DMS_CHECK ON dbo.DMS_CHECK ;

ALTER TABLE DMS_CHECK
ALTER COLUMN CHECKNAME NVARCHAR(255);

CREATE NONCLUSTERED INDEX K02_DMS_CHECK ON dbo.DMS_CHECK (  CHECKNAME ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ];
	 
	 
update DMS_CHECK set CHECKNAME = N'Kiểm tra độ tuổi khách hàng' where CHECKSYSNAME = 'checkCustomerAge';
update DMS_CHECK set CHECKNAME = N'Kiểm tra độ tuổi khách hàng' where CHECKSYSNAME = 'checkCustomerAgeCard';
update DMS_CHECK set CHECKNAME = N'Kiểm tra khách hàng quá hạn (nhóm 2 trở lên)' where CHECKSYSNAME = 'checkOverdue2Group';
update DMS_CHECK set CHECKNAME = N'Kiểm tra nơi ở hiện tại của khách hàng' where CHECKSYSNAME = 'checkCurrentResidence';
update DMS_CHECK set CHECKNAME = N'Kiểm tra quốc tịch và nơi cư trú của khách hàng' where CHECKSYSNAME = 'checkCitizenship';
update DMS_CHECK set CHECKNAME = N'Thông báo email tự động cho khách hàng' where CHECKSYSNAME = 'autoNotificationClientINT';
update DMS_CHECK set CHECKNAME = N'checkContinue' where CHECKSYSNAME = 'checkContinue';
update DMS_CHECK set CHECKNAME = N'checkSendToReconsideration' where CHECKSYSNAME = 'checkSendToReconsideration';
update DMS_CHECK set CHECKNAME = N'Kết quả của giai đoạn hiện tại' where CHECKSYSNAME = 'currentStageResultAutoINT';
update DMS_CHECK set CHECKNAME = N'CheckRoutingHOBranch' where CHECKSYSNAME = 'checkRoutingHOBranch';
update DMS_CHECK set CHECKNAME = N'Kiểm tra quyết định của Hội đồng tín dụng' where CHECKSYSNAME = 'CheckMMCDecision';
update DMS_CHECK set CHECKNAME = N'Scoring' where CHECKSYSNAME = 'dmsScoring';
update DMS_CHECK set CHECKNAME = N'Kiểm tra DTI' where CHECKSYSNAME = 'dmsCheckDTI';
update DMS_CHECK set CHECKNAME = N'Kiểm tra các hồ sơ đang hoạt động hiện có' where CHECKSYSNAME = 'checkExistingActiveApplications';
update DMS_CHECK set CHECKNAME = N'Kiểm tra các hồ sơ bị từ chối 6 tháng' where CHECKSYSNAME = 'checkRejectedApplications6months';
update DMS_CHECK set CHECKNAME = N'Xác minh tất cả các kết quả kiểm tra' where CHECKSYSNAME = 'dmsCheckResultsRouting';
update DMS_CHECK set CHECKNAME = N'Thông báo khách hàng tự động ' where CHECKSYSNAME = 'customerAutoNotification';
update DMS_CHECK set CHECKNAME = N'Kiểm tra liên kết giữa khách hàng và hồ sơ' where CHECKSYSNAME = 'checkDocumentCheck';
update DMS_CHECK set CHECKNAME = N'Tạo hoặc sửa đổi cá nhân' where CHECKSYSNAME = 'processCreateOrModifyPerson';
update DMS_CHECK set CHECKNAME = N'Kiểm tra tuổi' where CHECKSYSNAME = 'checkAgeDL';
update DMS_CHECK set CHECKNAME = N'Kiểm tra thiết bị di động' where CHECKSYSNAME = 'checkAgeCFMortgage';
update DMS_CHECK set CHECKNAME = N'Kiểm tra số tiền cho vay' where CHECKSYSNAME = 'checkLoanAmount';
update DMS_CHECK set CHECKNAME = N'Kiểm tra số tiền thu nhập' where CHECKSYSNAME = 'checkIncomeAmount';
update DMS_CHECK set CHECKNAME = N'Kiểm tra mục đích khoản vay: Thanh toán khoản vay khác' where CHECKSYSNAME = 'checkLoanPurposeCF';
update DMS_CHECK set CHECKNAME = N'Kiểm tra mục đích khoản vay: bao gồm các tùy chọn' where CHECKSYSNAME = 'checkLoanPurposeCFNotOnly';
update DMS_CHECK set CHECKNAME = N'Kiểm tra mã nội bộ bán hàng' where CHECKSYSNAME = 'checkSalesInternalCode';
update DMS_CHECK set CHECKNAME = N'Kiểm tra thời hạn cho vay' where CHECKSYSNAME = 'checkLoanTermCF';
update DMS_CHECK set CHECKNAME = N'Kiểm tra thành viên hộ gia đình' where CHECKSYSNAME = 'checkNumberHouseholdMembers';
update DMS_CHECK set CHECKNAME = N'Kiểm tra phí thuê nhà hoặc khoản thanh toán bất động sản' where CHECKSYSNAME = 'checkRentalMortgagePayment';
update DMS_CHECK set CHECKNAME = N'Kiểm tra trình độ học vấn' where CHECKSYSNAME = 'checkEducationLevelDL';
update DMS_CHECK set CHECKNAME = N'Kiểm tra thời gian làm việc' where CHECKSYSNAME = 'checkEmploymentDurationCF';
update DMS_CHECK set CHECKNAME = N'Kiểm tra loại thu nhập chính' where CHECKSYSNAME = 'checkMainIncomeTypeCF';
update DMS_CHECK set CHECKNAME = N'Kiểm tra tổng thu nhập hộ gia đình' where CHECKSYSNAME = 'checkTotalHouseholdIncomeCF';
update DMS_CHECK set CHECKNAME = N'Kiểm tra ngành nghề' where CHECKSYSNAME = 'checkActivitySphere';
update DMS_CHECK set CHECKNAME = N'Kiểm tra tổng kinh nghiệm' where CHECKSYSNAME = 'checkTotalExperience';
update DMS_CHECK set CHECKNAME = N'Kiểm tra kinh nghiệm hiện tại và tổng kinh nghiệm' where CHECKSYSNAME = 'checkCurrentAndTotalExperience';
update DMS_CHECK set CHECKNAME = N'Kiểm tra vị trí công tác' where CHECKSYSNAME = 'checkEmploymentPositionCF';
update DMS_CHECK set CHECKNAME = N'Kiểm tra thời hạn cư trú' where CHECKSYSNAME = 'checkDurationOfResidenceCF';
update DMS_CHECK set CHECKNAME = N'Kiểm tra thành phố của địa chỉ hiện tại với thành phố đang làm việc' where CHECKSYSNAME = 'checkAddressCityCF';
update DMS_CHECK set CHECKNAME = N'Tải dữ liệu lên ABS bên ngoài (Flexcube)' where CHECKSYSNAME = 'dmsExternalABSUploadDataINT';
update DMS_CHECK set CHECKNAME = N'Kiểm tra định tuyến F2 hoặc N' where CHECKSYSNAME = 'CheckRoutingF2N';
update DMS_CHECK set CHECKNAME = N'Kiểm tra định tuyến sau kiểm soát' where CHECKSYSNAME = 'checkRoutingAfterControls';
update DMS_CHECK set CHECKNAME = N'checkRoutingAfterDocumentSupplement' where CHECKSYSNAME = 'checkRoutingAfterDocumentSupplement';
update DMS_CHECK set CHECKNAME = N'checkLoanPurposeCFNotOnly' where CHECKSYSNAME = 'checkLoanPurposeCFNotOnly';
update DMS_CHECK set CHECKNAME = N'Kiểm tra mục đích vay CF' where CHECKSYSNAME = 'checkLoanPurposeCF';
update DMS_CHECK set CHECKNAME = N'Scoring' where CHECKSYSNAME = 'scoringCheck';
