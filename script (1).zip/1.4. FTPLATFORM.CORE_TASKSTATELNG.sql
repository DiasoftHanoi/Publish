INSERT INTO CORE_TASKSTATELNG (STATESYSNAME, LOCALE, STATENAME, DESCRIPTION) 
VALUES 
	('CANCELLED', 'vi', N'Đã hủy', N'Đã hủy'),
	('DECLINED', 'vi', N'Suy giảm', N'Suy giảm'),
	('DELAYED', 'vi', N'Trì hoãn', N'Trì hoãn'),
	('DONE', 'vi', N'Xong', N'Xong'),
	('EXPIRED', 'vi', N'Hết hạn', N'Hết hạn'),
	('FAILED', 'vi', N'Thất bại', N'Thất bại'),
	('NEW', 'vi', N'Mới', N'Mới'),
	('PROCESSED', 'vi', N'Xử lý', N'Xử lý');