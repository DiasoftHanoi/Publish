update  FRNT_SMTRANSLNG set NAME = N'Chỉnh sửa hồ sơ' 
where NAME in (N'VI Chỉnh sửa hồ sơ') ;

update FRNT_SMTRANSLNG set name = N'Xoá' 
where NAME in (N'Ứng dụng xóa chủ đề') ;

update FRNT_SMTRANSLNG set name = N'Sửa' 
where NAME in (N'Ứng dụng chỉnh sửa chủ đề') ;

update FRNT_SMTRANSLNG set name = N'Xem' 
where NAME in (N'Ứng dụng xem chủ đề') ;


update FRNT_SMSTATELNG set NAME = N'Một bước kiểm soát' where STATEID in (15050, 9039, 9048, 9052) and LOCALE = 'vi'
update FRNT_SMSTATELNG set NAME = N'Hai bước kiểm soát' where STATEID in (15051, 9040, 9049, 9053) and LOCALE = 'vi'