update FRNT_MENUITEMLNG set ITEMNAME = N'Vay mua xe' , DESCRIPTION = N'Vay mua xe'
where MENUITEMID in (select MENUITEMID from FRNT_MENUITEM where [SYSNAME] = 'autoLoanAppINT') and locale = 'vi';

update FRNT_MENUITEMLNG set ITEMNAME = N'Thẻ tín dụng' , DESCRIPTION = N'Thẻ tín dụng'
where MENUITEMID in (select MENUITEMID from FRNT_MENUITEM where [SYSNAME] = 'issueCardAppINT') and locale = 'vi';

update FRNT_MENUITEMLNG set ITEMNAME = N'Vay mua bất động sản' , DESCRIPTION = N'Vay mua bất động sản'
where MENUITEMID in (select MENUITEMID from FRNT_MENUITEM where [SYSNAME] = 'mortgageLoanAppINT') and locale = 'vi';

update FRNT_MENUITEMLNG set ITEMNAME = N'Vay tiêu dùng/SXKD' , DESCRIPTION = N'Vay tiêu dùng/SXKD'
where MENUITEMID in (select MENUITEMID from FRNT_MENUITEM where [SYSNAME] = 'consumerLoanAppINT') and locale = 'vi';