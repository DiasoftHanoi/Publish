/* 
update REF_REFITEMLNG set FULLVALUE = N'Phí định giá TSBĐ', SHORTVALUE = N'Phí định giá TSBĐ'
where REFITEMID in (select REFITEMID from REF_REFITEM where CODE in ('evaluationCost')
		and REFERENCEID in (select REFERENCEID from REF_REFERENCE where REFSYSNAME  in ('loanFees'))) 
and locale = 'vi';

update REF_REFITEMLNG set FULLVALUE = N'Phí trả nợ trước hạn', SHORTVALUE = N'Phí trả nợ trước hạn'
where REFITEMID in (select REFITEMID from REF_REFITEM where CODE in ('prepaymentCharge')
		and REFERENCEID in (select REFERENCEID from REF_REFERENCE where REFSYSNAME  in ('loanFees'))) 
and locale = 'vi';

update REF_REFITEMLNG set FULLVALUE = N'Phí khác', SHORTVALUE = N'Phí khác'
where REFITEMID in (select REFITEMID from REF_REFITEM where CODE in ('other') 
		and REFERENCEID in (select REFERENCEID from REF_REFERENCE where REFSYSNAME  in ('loanFees'))) 
and locale = 'vi';
*/


insert into REF_REFITEMLNG (REFITEMID, FULLVALUE, SHORTVALUE, RICOMMENT, LOCALE)
select REFITEMID, FULLVALUE, SHORTVALUE, RICOMMENT, case LOCALE
	when 'en' then 'vi' end as LOCALE 
	from REF_REFITEMLNG
		where REFITEMID in (32012, 32013, 3140)
		and LOCALE in ('en');
		
insert into REF_REFITEMLNG (REFITEMID, FULLVALUE, SHORTVALUE, RICOMMENT, LOCALE)
select REFITEMID, FULLVALUE, SHORTVALUE, RICOMMENT, case LOCALE
	when 'en' then 'vi' end as LOCALE 
	from REF_REFITEMLNG
		where REFITEMID in (select REFITEMID from  REF_REFITEM 
			where REFERENCEID in (select REFERENCEID from REF_REFERENCE 
				where REFSYSNAME in ('ccOnlineLimit', 'cardTypeLOS', 'modifiedAttributes')))
		and LOCALE in ('en');		

update REF_REFITEMLNG 
	set SHORTVALUE = N'Bảo mật' 
where SHORTVALUE in (N'bảo mật');

----####
update REF_REFERENCELNG set LOCALE = 'del' where locale = 'vi';

insert into REF_REFERENCELNG (REFERENCEID, REFERENCENAME, REFDESCRIPTION, LOCALE)
select REFERENCEID, REFERENCENAME, REFDESCRIPTION, case LOCALE
	when 'en' then 'vi' end as LOCALE 
	from REF_REFERENCELNG
		where LOCALE in ('en');	

----###
insert into REF_REFITEMLNG (REFITEMID, FULLVALUE,SHORTVALUE,RICOMMENT,LOCALE)
select REFITEMID, FULLVALUE,SHORTVALUE,RICOMMENT,case LOCALE
	when 'en' then 'vi' end as LOCALE 
from REF_REFITEMLNG
where REFITEMID in (28125, 29011, 29012, 29013, 29014, 29015, 29016, 29017, 29018, 29019, 29020, 29021, 29022, 29023, 29024, 29025, 29026, 29027, 29028, 35011, 212016);