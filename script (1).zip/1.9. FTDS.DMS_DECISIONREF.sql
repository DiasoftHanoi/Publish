DROP INDEX K01_DMS_DECREF ON dbo.DMS_DECISIONREF;

ALTER TABLE DMS_DECISIONREF
ALTER COLUMN REFNAME NVARCHAR(255);

CREATE NONCLUSTERED INDEX K01_DMS_DECREF ON dbo.DMS_DECISIONREF (  REFNAME ASC  )  
	 WITH (  PAD_INDEX = OFF ,FILLFACTOR = 100  ,SORT_IN_TEMPDB = OFF , IGNORE_DUP_KEY = OFF , STATISTICS_NORECOMPUTE = OFF , ONLINE = OFF , ALLOW_ROW_LOCKS = ON , ALLOW_PAGE_LOCKS = ON  )
	 ON [PRIMARY ];


update FTDS.dbo.dms_decisionref set REFNAME = N'Đồng ý' where REFSYSNAME = 'approve';
update FTDS.dbo.dms_decisionref set REFNAME = N'Đồng ý vượt cấp' where REFSYSNAME = 'approveEscalation';
update FTDS.dbo.dms_decisionref set REFNAME = N'Đồng ý có điều kiện' where REFSYSNAME = 'approveWithConditions';
update FTDS.dbo.dms_decisionref set REFNAME = N'Huỷ hồ sơ' where REFSYSNAME = 'cancelApp';
update FTDS.dbo.dms_decisionref set REFNAME = N'Hoàn thành' where REFSYSNAME = 'complete';
update FTDS.dbo.dms_decisionref set REFNAME = N'Tiếp tục' where REFSYSNAME = 'continue';
update FTDS.dbo.dms_decisionref set REFNAME = N'Bổ sung tài liệu' where REFSYSNAME = 'documentSupplement';
update FTDS.dbo.dms_decisionref set REFNAME = N'F0: CA phê duyệt' where REFSYSNAME = 'f_flow';
update FTDS.dbo.dms_decisionref set REFNAME = N'Chi nhánh phê duyệt' where REFSYSNAME = 'f0_flow';
update FTDS.dbo.dms_decisionref set REFNAME = N'F1: HO phê duyệt' where REFSYSNAME = 'f1_flow';
update FTDS.dbo.dms_decisionref set REFNAME = N'F2: HO phê duyệt' where REFSYSNAME = 'f2_flow';
update FTDS.dbo.dms_decisionref set REFNAME = N'F: HO phê duyệt' where REFSYSNAME = 'f3_flow';
update FTDS.dbo.dms_decisionref set REFNAME = N'Phê duyệt cấp A' where REFSYSNAME = 'levelA';
update FTDS.dbo.dms_decisionref set REFNAME = N'Phê duyệt cấp B' where REFSYSNAME = 'levelB';
update FTDS.dbo.dms_decisionref set REFNAME = N'Phê duyệt cấp C' where REFSYSNAME = 'levelC';
update FTDS.dbo.dms_decisionref set REFNAME = N'N: HO phê duyệt' where REFSYSNAME = 'n_flow';
update FTDS.dbo.dms_decisionref set REFNAME = N'Chưa hoàn thành' where REFSYSNAME = 'notComplete';
update FTDS.dbo.dms_decisionref set REFNAME = N'Từ chối' where REFSYSNAME = 'reject';
update FTDS.dbo.dms_decisionref set REFNAME = N'Từ chối hồ sơ' where REFSYSNAME = 'rejectApp';
update FTDS.dbo.dms_decisionref set REFNAME = N'Từ chối vượt cấp' where REFSYSNAME = 'rejectEscalation';
update FTDS.dbo.dms_decisionref set REFNAME = N'Trả lại bước nhập liệu' where REFSYSNAME = 'returnToDataEntry';
update FTDS.dbo.dms_decisionref set REFNAME = N'Trả lại bước bổ sung' where REFSYSNAME = 'returnToSupplement';
update FTDS.dbo.dms_decisionref set REFNAME = N'Trả lại cho TTĐ' where REFSYSNAME = 'returnToUnderwriter';
update FTDS.dbo.dms_decisionref set REFNAME = N'Gửi đến CGPD' where REFSYSNAME = 'sendToApprover';
update FTDS.dbo.dms_decisionref set REFNAME = N'Gửi đến chi nhánh phê duyệt' where REFSYSNAME = 'sendToBranchApproval';
update FTDS.dbo.dms_decisionref set REFNAME = N'Gửi đến HO phê duyệt' where REFSYSNAME = 'sendToHOApproval';
update FTDS.dbo.dms_decisionref set REFNAME = N'Gửi đến TTĐ' where REFSYSNAME = 'sendToUnderwriter';
update FTDS.dbo.dms_decisionref set REFNAME = N'Nộp hồ sơ' where REFSYSNAME = 'submitApp';
