INSERT INTO DOC_DOCPROCTYPE (DOCPROCTYPEID, DOCUMENTTYPE, [SYSNAME], PAGEFLOWNAME) 
VALUES
	 (1500, 1103, N'routingF2_N', NULL),
	 (1501, 1104, N'routingF2_N', NULL),
	 (1502, 1105, N'routingF2_N', NULL),
	 (1503, 1107, N'routingF2_N', NULL),
	 (1504, 1108, N'routingF2_N', NULL);

INSERT INTO DOC_DOCPROCTYPELNG (DOCPROCTYPEID, NAME, LOCALE) 
VALUES
	 (1500, N'Routing', N'en'), 
	 (1500, N'Định tuyến', N'vi'),
	 (1501, N'Routing', N'en'), 
	 (1501, N'Định tuyến', N'vi'),
	 (1502, N'Routing', N'en'), 
	 (1502, N'Định tuyến', N'vi'),
	 (1503, N'Routing', N'en'), 
	 (1503, N'Định tuyến', N'vi'),
	 (1504, N'Routing', N'en'), 
	 (1504, N'Định tuyến', N'vi');