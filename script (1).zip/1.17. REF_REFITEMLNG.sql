INSERT INTO REF_REFITEMLNG (REFITEMID,FULLVALUE,SHORTVALUE,RICOMMENT,LOCALE) 
VALUES
	 (3162, null, N'Một bước kiểm soát', null, 'vi'),
	 (3163, null, N'Hai bước kiểm soát', null, 'vi'),
	 (125011, null, N'Không bước kiểm soát', null, 'vi');

insert into REF_REFERENCELNG (REFERENCEID, REFERENCENAME, REFDESCRIPTION, LOCALE)
select REFERENCEID, REFERENCENAME, REFDESCRIPTION, case LOCALE
	when 'en' then 'vi' end as LOCALE 
	from REF_REFERENCELNG where REFERENCEID in (select REFERENCEID from REF_REFERENCE where REFSYSNAME in ('controlMethodLOS'))
	
;
