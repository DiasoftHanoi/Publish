<<<<<<< HEAD
/* global form, service */

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;

var outputParams = form.outputParams || {};
outputParams.formParams = form.formParams;






var lgr = service.lgr;
var nvl = service.nvl;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
};


form.executeCommand = function (msg) {
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE') {
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var btnNext = form['btnNext'] ? 'btnNext' : 'btnSave';
        if (form.validateControlsByIds('*', showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        lgr(e);
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                    caption: gRB('dialog.ok')
                }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.onCheckedReport=function(checked,item){
    lgr("onCheckedReport",arguments);
    var selReports=nvl(form.reportObj.selected,[])
    form.printDocumentBtn[selReports.length>0 ? "enable" : 'disable']();

}
/*
form.onSelectRow = function(checked,item){
  debugger;
    var selReports=nvl(form.reportObj.selected,[]);

    var itemList=[];
    for (var i=0;i< selReports.length;i++){
        var itm = selReports[i];
        if(itm==item["REPORTID"]){
            selectItem=itm;
        }
    }

    itemList.push(item["REPORTID"])
    form.onCheckedReport(true,itemList);
    var a =0;
}*/
form.showModalWindow4=function (project,process,params,callback){
   // debugger;
    fabPageFlowService.startModalPageFlowProcess('api/pageflow/' + project+ '/' +process, params)
        .then(function (p) {
            if (callback) callback(p);
        })
        ['catch'](function (p) {
        service.lgr('catch',arguments);
        if (callback) callback(p);
    })
        ['finally'](function (result) {
        service.lgr('finally',arguments);
    });
}
form.printDocument=function(){
    var selReports=nvl(form.reportObj.selected,[]);
    if (selReports.length>0){
        form.printDocumentBtn.disable();
        var name = form.getCurrentProjectSysname();
        service.pageflowCall2(form.getCurrentProjectSysname(), 'COMMON/REPORTS/reportGenerator',
            {
                APPLICATIONID:form.formParams.APPLICATIONID,
                REPORTIDS:selReports
            },
            function (p) {
                lgr('onAfterGenerateReports', p);

                form.printDocumentBtn.enable();
                if (!p['ErrorMessage']){
                    form.showModalWindow4(name,"COMMON/REPORTS/reportViewer",  p);
                }
            },
            form
        );
    }
}
form.reportObj={
    remoteMethod:{
        filterParams:{
            CheckRights:'TRUE',
           // USERACCOUNTID:getInputParams('USERACCOUNTID'),
            ROLEIDS:form.formParams.ROLEIDS,
           // USERGROUPIDS:getInputParams('USERGROUPIDS'),
            STATEID:form.formParams.STATEID
        }
    }
}
form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;

    if (tagName === 'CLOSE') {
        form.sendForm('GO',false);

    }
}
=======
/* global form, service */

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;

var outputParams = form.outputParams || {};
outputParams.formParams = form.formParams;






var lgr = service.lgr;
var nvl = service.nvl;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
};
form.lkpParams = {
    partnerType: 'partnerType_builder'
};

form.executeCommand = function (msg) {
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE') {
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var btnNext = form['btnNext'] ? 'btnNext' : 'btnSave';
        if (form.validateControlsByIds('*', showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        lgr(e);
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                    caption: gRB('dialog.ok')
                }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.onCheckedReport=function(checked,item){
    lgr("onCheckedReport",arguments);
    var selReports = form.reportsList.getSelectedRows();
    //var selReports=form.reportObj.selected ? form.reportObj.selected:[];
    form.printDocumentBtn[selReports.length>0 ? "enable" : 'disable']();

}
/*
form.onSelectRow = function(checked,item){
  debugger;
    var selReports=nvl(form.reportObj.selected,[]);

    var itemList=[];
    for (var i=0;i< selReports.length;i++){
        var itm = selReports[i];
        if(itm==item["REPORTID"]){
            selectItem=itm;
        }
    }

    itemList.push(item["REPORTID"])
    form.onCheckedReport(true,itemList);
    var a =0;
}*/
form.showModalWindow4=function (project,process,params,callback){
   // debugger;
    fabPageFlowService.startModalPageFlowProcess('api/pageflow/' + project+ '/' +process, params)
        .then(function (p) {
            if (callback) callback(p);
        })
        ['catch'](function (p) {
        service.lgr('catch',arguments);
        if (callback) callback(p);
    })
        ['finally'](function (result) {
        service.lgr('finally',arguments);
    });
}
form.printDocument=function(){
    var selReports=nvl(form.reportObj.selected,[]);
    if (selReports.length>0){
        form.printDocumentBtn.disable();
        var name = form.getCurrentProjectSysname();
        service.pageflowCall2(form.getCurrentProjectSysname(), 'COMMON/REPORTS/reportGenerator',
            {
                APPLICATIONID:form.formParams.APPLICATIONID,
                REPORTIDS:selReports
            },
            function (p) {
                lgr('onAfterGenerateReports', p);

                form.printDocumentBtn.enable();
                if (!p['ErrorMessage']){
                    form.showModalWindow4(name,"COMMON/REPORTS/reportViewer",  p);
                }
            },
            form
        );
    }
}
form.reportObj={
    remoteMethod:{
        filterParams:{
            CheckRights:'TRUE',
           // USERACCOUNTID:getInputParams('USERACCOUNTID'),
            ROLEIDS:form.formParams.ROLEIDS,
           // USERGROUPIDS:getInputParams('USERGROUPIDS'),
            STATEID:form.formParams.STATEID
        }
    }
}
form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;

    if (tagName === 'CLOSE') {
        form.sendForm('GO',false);

    }
}
>>>>>>> 5.01.02-SNAPSHOT
