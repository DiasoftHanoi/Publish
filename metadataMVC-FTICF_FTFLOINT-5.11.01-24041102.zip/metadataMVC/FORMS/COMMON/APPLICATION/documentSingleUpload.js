/*DSMETA version = "5.11.01-24041102" hash = "84a9ae99f20a402b39fd7a96bc19821b7d9331df"*/
form.formParams = form.inputParams;
form.outputParams = form.formParams;

var lgr = service.lgr;

form.action = function(tag){
    form.outputParams.ACTION = tag;
    form.sendForm(tag);
}

form.uploadFlag = false;

form.onFileChange=function(){
    lgr("onFileChange",arguments);
    form.uploadFlag=false;
}
form.onFileUpload=function(p){
    lgr("onFileUpload",arguments);
    form.uploadFlag=true;
    var data=p;
    if (data){
        var map={
            HASHCODE:data.tempKey,
            DISKFILENAME:data.value,
            FILENAME:data.fileName,
            FILETYPE:data.fileType,
            FILESIZE:data.fileSize,
            fileInfoId:data.fileInfoId
        }
        form.formParams.uploadFile = data;
    }
}
form.onFileInvalid=function(){
    lgr("onFileInvalid",arguments);
    form.uploadFlag=false;
    form.showError(form.uploader.popover.error.content, function () {}, [{
        caption : "OK"
    }
    ]);
}