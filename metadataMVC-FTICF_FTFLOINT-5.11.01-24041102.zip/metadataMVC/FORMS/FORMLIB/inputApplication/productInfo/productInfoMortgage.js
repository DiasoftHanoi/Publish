/*DSMETA version = "5.11.01-24041102" hash = "e2e9bd49a103b77a9654d58a60f74a4991adcfb0"*/
/* global form, service */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

form.isFormEditMode = form.inputParams.EDITMODE || false;
var inputParams = form.inputParams;
var outputParams = form.outputParams || {};
form.params = form.inputParams.formParams || {};

outputParams.formParams = form.params;
form.isFormEditModeMain = form.inputParams.EDITMODE;
form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
var gRB = service.gRB;

form.referenceRealty = {ReferenceSysName:"realEstateTypeLOS"};
inputParams.isCertificateOwnership_ITEMS= [{
        value: 'true',
        text: '${yes}'
    }, {
        value: 'false',
        text: '${no}'
    }
];

if(form.params.isCertificateOwnership!='true' && form.params.isCertificateOwnership!='false'){
    form.params.isCertificateOwnership='true';
}

var lgr = service.lgr;
var nvl = service.nvl;
service.lgr(form.params);

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
    form.periodListInfo.setItems(form.params.periodList || []);
    form.setLoanRatio();
    if (form.isFormEditModeMain) {
        form.getBPparamValues(XMLHttpRequest);
    }    
};

form.getBPparamValues = function(flag){
    
    var PARAMTYPELIST = ["loanPurpose","subProductNameLOS","principalRepaymentSchedulerLOS","principalRepaymentMethodLOS","interestRepaymentMethodLOS","currencyLOS","creditExtensionMethodLOS"];
    var PRODUCTID = form.cbLoanProduct.getValue();
    if(!flag){
        form.cbLoanPurpose.setValue('');
        form.cbSubproductName.setValue('');
        form.cbPrincRepayment.setValue('');
        form.cbInterestRepaymentSchedule.setValue('');
        form.cbInterestRepayment.setValue('');
        form.cbCreditCurrency.setValue('');
        form.cbCreditExtensionMethod.setValue('');
    }
   
    inputParams.principalRepaymentSchedule_ITEMS=[];
    inputParams.loanCurrency_ITEMS=[];
    inputParams.interestRepaymentMethod_ITEMS=[];
    inputParams.principalRepaymentMethod_ITEMS=[];
    inputParams.SubproductName_ITEMS=[];
    inputParams.loanPurpose_ITEMS=[];
    inputParams.creditExtensionMethod_ITEMS=[];
    
    if (!PRODUCTID) return;
    service.lgr(form.params.LOCALE);
    var dsCallparams = {
        PRODUCTID: PRODUCTID,
        PARAMTYPELIST: PARAMTYPELIST,
        RETURN_ABSOLUTE_PARAM:true
    };
     
    return form.dsCall('[frontws2]', 'bankProductParamGetListByProductId', dsCallparams).then(function (response){
        service.lgr(response);
        for (var i=0; i<response.data.Result.length;i++){
            var items = response.data.Result[i];
            switch (items["PARAMTYPE"]){

                case "loanPurpose":
                    inputParams.loanPurpose_ITEMS=items["VALUES"];
                    break;
                case "subProductNameLOS":
                    inputParams.SubproductName_ITEMS=items["VALUES"];
                    break;
                case "principalRepaymentSchedulerLOS":
                    inputParams.principalRepaymentSchedule_ITEMS=items["VALUES"];
                    break;
                case "principalRepaymentMethodLOS":
                    inputParams.principalRepaymentMethod_ITEMS=items["VALUES"];
                    break;
                case "interestRepaymentMethodLOS":
                    inputParams.interestRepaymentMethod_ITEMS=items["VALUES"];
                    break;
                case "currencyLOS":
                    inputParams.loanCurrency_ITEMS=items["VALUES"];
                    break;
                case "creditExtensionMethodLOS":
                    inputParams.creditExtensionMethod_ITEMS=items["VALUES"];
                    break;

            }
        }
        if(!flag) form.params.creditCurrencySysName='VND';
    }).catch(function (e){
        form.showErrorDialog('error', function(){}, [{caption: 'OK'}]);
    });
}; 

form.getBPConditionParamValues = function(dsCallparams){
    var PRODUCTID = form.cbLoanProduct.getValue();
    if (!PRODUCTID) return;
    var CONDITIONVALUES = {
        loanPurpose:form.cbLoanPurpose.getValue()
    };
    var dsCallparams = {
        PRODUCTID: PRODUCTID,
        ReturnAsHashMap:"TRUE",
        CONDITIONVALUES:CONDITIONVALUES
    };
   
    return form.dsCall('[frontws2]', 'bankProductListGetParamByConditionSet', dsCallparams).then(function (response){
        service.lgr(response);
        if (response.data.loanPurposeForCapital == "true") {
            form.cbLoanPurpCapital.show();
        } else {
        form.cbLoanPurpCapital.hide();    
        }
        if(response.data["requst"]==="Household"){
            form.params.requstFor="Household";
        }
        else{
            form.params.requstFor="Individual";
        }
    }).catch(function (e){
        form.showErrorDialog('error', function(){}, [{caption: 'OK'}]);
    });
};
form.setLoanRatio = function() {
    var ratio = Math.ceil((form.params.loanAmount/form.params.costOfObject*100)*100)/100; 
    ratio = isNaN(ratio) ? "" : ratio;

    form.params.loanRatio=ratio;
    form.loanRatio.setText(ratio);
};
form.setLoanAmount = function() {
    var amount = Math.ceil(((form.params.costOfObject - form.params.firstPayment)*100))/100; 
    amount = isNaN(amount) ? "" : amount;
    form.params.loanAmount=amount;
};
form.notEmtyValues = function(params) {

   var i =0; while (i<params.length) {
   var curVal = params[i];
      if (curVal != '' && curVal != undefined && curVal != null)  {
          return false;
          break;
      }
   i++;
   }
   
   return true;

};
form.isCollaps = (form.params.periodList || []).length > 0 ?  false : true ;
form.isCollapsAdditionalRates =form.notEmtyValues([form.params.promoInterestRate,form.params.amplitudeInterestRate,form.params.commission,form.params.insuranceFee,form.params.otherFees]); 

form.requiredElements = ["cbLoanProduct","cbLoanPurpose","btOwner","edRelOwner","cbPrincRepayment",
"cbInterestRepayment","edObjCost","edOwnedCapital","cbCreditCurrency","edLoanAmount","loanRatio","edLoanTerm","edInterestRate","cbDisbursMethod","edDisbursMethodOther"];
form.verifyForm = function (showFlag) {
    var verified = true;
    var buttonNextSave = (form.isLastWizForm) ? "btnSave" : "btnNext";
    try {
        console.log('verifyForm');
        console.log('r ',form.requiredElements.join(','));
        if ((form.validateControlsByIds(form.requiredElements.join(','), showFlag === true ? buttonNextSave : undefined).isShowFormErrors)) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    outputParams.VERIFIED = verified;
    console.log('verified ',verified);
    return verified;
};

form.executeCommand = function (msg) {
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE') {
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};

form.yesFunc = function() {
    outputParams.TRANSTYPE = 'SAVEDRAFT';
    if (form.verifyForm()) {
        form.sendForm('GO', false);
    }
};

form.action = function (tag) {
    outputParams.TRANSTYPE = tag;
    if (form.isFormEditModeMain) {
        outputParams.formParams.bankProductId =   form.params.bankProductId;
        outputParams.formParams.bankProductName = form.cbLoanProduct.getText();
        
        outputParams.formParams.loanPurposeSysName =   form.params.loanPurposeSysName;
        outputParams.formParams.loanPurpose =          form.cbLoanPurpose.getText();
        
        outputParams.formParams.subProductName =   form.params.subProductName;
        
        outputParams.formParams.loanPurposeDetail = form.params.loanPurposeDetail;

        outputParams.formParams.realtyTypeSysName = form.params.realtyTypeSysName;
        outputParams.formParams.realtyType = form.cbRealtyType.getText();

        outputParams.formParams.withdrawalTerm = form.params.withdrawalTerm;
        outputParams.formParams.paymentDate = form.params.paymentDate;
        outputParams.formParams.principalRepaymentMethodSysName = form.params.principalRepaymentMethodSysName;
        outputParams.formParams.principalRepaymentMethod = form.cbPrincRepayment.getText();
        outputParams.formParams.costOfObject = form.params.costOfObject;
        outputParams.formParams.firstPayment = form.params.firstPayment;
        outputParams.formParams.creditCurrencySysName = form.params.creditCurrencySysName;
        outputParams.formParams.creditCurrencyName = form.cbCreditCurrency.getText();
        outputParams.formParams.loanAmount = form.params.loanAmount;
        outputParams.formParams.loanTerm = form.params.loanTerm;
        outputParams.formParams.interestRate = form.params.interestRate;
        outputParams.formParams.commission = form.params.commission;
        outputParams.formParams.principalRepaymentSchedule=form.cbInterestRepayment.getText();
        outputParams.formParams.interestRepaymentSchedule=form.cbInterestRepaymentSchedule.getText();
        outputParams.formParams.periodList=form.periodListInfo.getItems();
        outputParams.formParams.creditExtensionMethodSysName = form.params.creditExtensionMethodSysName;
        outputParams.formParams.creditExtensionMethod = form.cbCreditExtensionMethod.getText();
    }
    service.lgr(outputParams);
        if (tag === 'CLOSE') {
            if(form.inputParams.EDITMODE === false){
                form.sendForm('GO',false);
            }else {
                service.showDialogCancelConfirm(
                    form,
                    form.yesFunc
                )
            }
        }
        else {
            if (tag === 'NEXT' && !form.verifyForm(true)) {
                return;
            } else {
                form.verifyForm(false);
            }
            form.sendForm('GO', false);
        }
};
form.clearElement = function (el) {
   if(form.params[el]) form.params[el]='';
};

form.tblPeriodListInfo = (function (grId) {
    var gridId = grId; 
    var options = {
        cancel: function () {
            form[gridId].hideEditor();
            form.btnDataWorkAdd.enable();
        },
        save: function () {
            var selectedRow = form.periodListInfo.getSelectedRow()[0];
            var newRow = {
                typeSysName          : form.cbType.getValue(),
                type          : form.cbType.getText(),
                months        : form.months.getValue(),
                comment     : form.comment.getValue()
            };

            if (selectedRow['LinkID']) {
                newRow['LinkID'] = selectedRow['LinkID'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['LinkID'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnDataWorkAdd.enable();
        },
        clearFields: function () {
            delete options.data.typeSysName;
            delete options.data.months;
            delete options.data.comment;
        },
        getOptionsData: function () {
            var selectedRow = form.periodListInfo.getSelectedRow()[0];

            form.tblPeriodListInfo.options.data = {
                typeSysName           : selectedRow["typeSysName"],
                months    : selectedRow["months"],
                comment   : selectedRow["comment"],
            };
         
        }, 
        edit: function () {
            options.clearFields();
            options.getOptionsData();            
            form[gridId].showEditor('edit');
            form.btnDataWorkAdd.disable();
        },
        delete: function () {
            if (form.periodListInfo.getSelectedRow()[0]) {
                form.periodListInfo.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
        },
        referencePeriodTypeLOS: {ReferenceSysName:"periodTypeLOS"},
        data: {}

    };
    
    var obj = {
        addNewRow: function () {
            options.clearFields();
            form.PeriodsPanel.isCollapsed = false;
            form[gridId].showEditor('add');
            
            
            form.btnDataWorkAdd.disable();
            
        },
        onSelectRow: function () {
            var selRow = form[gridId].getSelectedRow()[0] || {};
            if (form.isFormEditMode) {
                options.items = [
                    {caption: gRB('edit'), click: form.tblPeriodListInfo.options.edit},
                    {caption: gRB('delete'), click: form.tblPeriodListInfo.options.delete}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('periodListInfo');

form.setConstraintFirstAmount = function () {
    if(form.params && form.params.costOfObject && form.params.costOfObject*1>0){
        if(form.edOwnedCapital) form.edOwnedCapital.setMaxAmount(form.params.costOfObject*1) ;
    }
};