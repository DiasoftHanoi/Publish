/*DSMETA version = "5.11.01-24041705" hash = "28d0fc270073da5fa7e0ab7d93495ac0555e8497"*/
var lgr = service.lgr;
var nvl = service.nvl;

form.formParams = form.inputParams.formParams || {}

form.action = function (tagName) {
    form.sendForm(tagName)
}

form.attachmentTemplateData = {
    parentForm: form,
    fabPageFlowService: fabPageFlowService
}