/*DSMETA version = "5.11.01-24041705" hash = "d4b3e37fed303af1c3c398f08430f50b37340e55"*/
service.getInputParams=function (key){
    return form.inputParams[key];
};

service.gRB=function(key){
    return   service.nvl(form.localize[key],key);
};

service.dsCall2=function (a, b, c, d){
	form.dsCall(a, b, c).then(d);
};

service.gRBT = function(key){
    var str = gRB(key);
    if (str != null && str!=key && arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            str = str.replace("%" + i + "$", String(arguments[i]));
        }
    } else {
        str = key;
    }
    return str;
};

service.sendMessage=function(message){
    var PROCESS_RIGHT_LIST=service.getInputParams("PROCESS_RIGHT_LIST");
    if (PROCESS_RIGHT_LIST){
        for (var ar in PROCESS_RIGHT_LIST){
            form.commandRight(ar, message);
        }
    }
};

service.convertToDate=function(date,mask){
    var dateMask=service.nvl(service.dateMask,service.gRB('dateMask'));
    mask=service.nvl(mask,dateMask);
    if (typeof date =="string"){
        var masks=[
            mask,
            "YYYY-MM-DDTHH:mm:ss.SSSSZ"
        ];
        var res=moment(date,masks,true);
        if (!res.isValid()) return null;
        return res.toDate();
    }
    return date;
};
////////////////////////////////////////////////////////////////////////////////
service.getSettingValue = function (sysname, valkey, evalJSON){
    valkey = service.nvl(valkey, "VALUE");
    var SettingsList = service.nvl(form.inputParams.SettingsList, []);
    for (var i = 0; i < SettingsList.length; i++) {
        var SettingsMap = SettingsList[i];

        if (SettingsMap["SYSNAMECONSTANT"] + "" == sysname) {
            var PARAMS = service.nvl(SettingsMap["PARAMS"], {});
            var valueData = PARAMS[valkey];
            if (evalJSON) {
                for (var j = 0; j < valueData.length; j++) {
                    if (valueData[j]["ADDVALUE"] != "" && typeof valueData[j]["ADDVALUE"] == 'string') {

                        valueData[j]["ADDVALUE"] = eval("window._tmp = " + valueData[j]["ADDVALUE"]);
                    }
                }
            }
            return valueData;
        }
    }
    return null;
};

////////////////////////////////////////////////////////////////////////////////
service.showAlert = function (message,isError,func){
	var f = func || function(){};
	if (isError) {
		return form.showErrorDialog(message,f,[{caption:service.gRB('OK')}]);
	} else {
		return form.showWarningDialog(message,f,[{caption:service.gRB('OK')}]);
	}
};
////////////////////////////////////////////////////////////////////
service.getSelectedRow2 = function (table){
	var selRows=service.nvl(table.getSelectedRow(),[]);
	return selRows.length>0 ? selRows[0] : null;
};
////////////////////////////////////////////////////////////////////
service.addRow2 = function (el, data){
	el.addRow(data);
};
////////////////////////////////////////////////////////////////////
service.deleteSelectedRow2 = function (table){
	var selRow=service.getSelectedRow2(table);
	if (selRow){
		table.deleteRow(selRow[table.itemIdField]);
	}
	return true;
};
////////////////////////////////////////////////////////////////////
service.deleteRow = function (table,i){
	table.deleteRow(i);
	return true;
};
////////////////////////////////////////////////////////////////////////////////
service.getTableContent = function (table){
	return service.nvl(table.getItems(),[]);
};
////////////////////////////////////////////////////////////////////////////////
service.setTableRows = function (el, list){
	el.setItems(list)
};
////////////////////////////////////////////////////////////////////////////////
service.updateSelectedRow2 = function (el, data){
	var selRow = service.getSelectedRow2(el);
	if (selRow){
		el.updateRow(selRow[el.itemIdField],angular.extend(selRow,data));
	}
};
////////////////////////////////////////////////////////////////////////////////
service.updateRow2 = function (el,idx,data){
	var list=service.nvl(el.listGridItems,[]);
	for (var i=0;i<list.length;i++){
		if (list[i][el.itemIdField]===idx){
			angular.extend(list[i],data);
		}
	}
    el.refresh("updateRow");
};
////////////////////////////////////////////////////////////////////
service.getSelectionRowNumber = function (table){
	var itemIdField = table.itemIdField;
	var selID = service.nvl(service.getSelectedRow2(table),{})[itemIdField];
	var listGrid = service.nvl(table.listGrid, []);
	for (var i = 0; i < listGrid.length; i++) {
		if (listGrid[i][itemIdField] == selID) {
			return i;
		}
	}
	return null;
};
////////////////////////////////////////////////////////////////////
service.setInputParams=function(key, data){
	form.inputParams[key] = data;
};
////////////////////////////////////////////////////////////////////////////////
service.setOutputParams=function(){
	if (typeof arguments[0]=="object"){
		angular.extend(form.outputParams,arguments[0]);
	}
	form.outputParams[arguments[0]] = arguments[1];
};
////////////////////////////////////////////////////////////////////////////////
service.getNewList=function(){return []};
////////////////////////////////////////////////////////////////////////////////
service.getNewMap=function(){return {}};
//////////////////////////////////////////
service.downloadFileByLink=function(code){ console.log('downloadFileByLink');
    var isChrome = navigator.userAgent.toLowerCase().indexOf('chrome') > -1;
    var isSafari = navigator.userAgent.toLowerCase().indexOf('safari') > -1;
    var sUrl='/webmvc/_download?key='+code;
    //If in Chrome or Safari - download via virtual link click
    if (isChrome || isSafari) {
        //Creating new link node.
        var link = document.createElement('a');
        link.href = sUrl;
        if (link.download !== undefined){
            //Set HTML5 download attribute. This will prevent file from opening if supported.
        }
        //Dispatching click event.
        if (document.createEvent) {
            var e = document.createEvent('MouseEvents');
            e.initEvent('click' ,true ,true);
            link.dispatchEvent(e);
            return true;
        }
    }
    // Force file download (whether supported by server).
    window.open('/webmvc/_download?key='+code);
};
////////////////////////////////////////////////////////////////////////////////
service.setActiveTab=function(project, process, params, refreshFlag, title){
    form.startNewPageFlowProcess(title,  project + '/' + process, params, refreshFlag);
};