form.formParams = form.inputParams.clientDataMap || {};
service.lgr(form.formParams);

var IdentityCardList = form.formParams.PersonIdentityCardList;
if (IdentityCardList && IdentityCardList.length) {
    for(var i=0; i<IdentityCardList.length; i++){
	    if(IdentityCardList[i]['BaseIdentityCardFlag']==true && IdentityCardList[i]['ActiveFlag']==true){
		    form.formParams.clientMainDocType = IdentityCardList[i]['IdentityCardTypeName'];
		    form.formParams.clientMainDocSeries = IdentityCardList[i]['Series'];
		    form.formParams.clientMainDocNumber = IdentityCardList[i]['Number'];
		    break;
	    }
    }
}