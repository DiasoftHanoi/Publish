/* global form, service */
function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;

var outputParams = form.outputParams || {}
outputParams.formParams = form.formParams;

var lgr = service.lgr;
var nvl = service.nvl;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.isFormEditMode = form.inputParams.EDITMODE || false;


form.onShow = function () {

    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
    form.tblRawMaterialsObj.setItems(form.inputParams.stageMap.rawMaterialsList || []);
    form.tblMachinesObj.setItems(form.inputParams.stageMap.machinesList || []);
    form.tblEmployeesObj.setItems(form.inputParams.stageMap.employeesList || []);
    form.tblProductsObj.setItems(form.inputParams.stageMap.productsList || []);
};
form.pnlRawMaterialsCollapsed = (form.inputParams.stageMap.rawMaterialsList || []).length <= 0;
form.pnlMachinesCollapsed     = (form.inputParams.stageMap.machinesList || []).length <= 0;
form.pnlEmployeesCollapsed    = (form.inputParams.stageMap.employeesList || []).length <= 0;
form.pnlProductsCollapsed     = (form.inputParams.stageMap.productsList || []).length <= 0;

form.executeCommand = function (msg) {
    switch (msg.event) {
        case 'FAB_NAVIGATOR_NAVIGATE':
            outputParams.NEXTPAGE = msg.params.step;
            form.action('DIRECT');
        break;
        default:
            break;
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;
    try {
        var save =  form['save'];

        if (form.validateControlsByIds('*', showFlag === true ? save : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};

form.yesFunc = function() {
    outputParams.TRANSTYPE = 'SAVEDRAFT';
    if (form.verifyForm()) {
        form.sendForm('GO', false);
    }
};

form.tblRawMaterialsObj = (function(grId){
    var gridId = grId;
    var options = {
        requiredElements : [
            "edRawMaterialsType"
        ],

        rawMaterialsList: form.inputParams.stageMap.rawMaterialsList,
        data: {},
        clearFields: function () {
            delete options.data.type;
            delete options.data.quantity;
            delete options.data.value;
            delete options.data.vendor;
        },
        cancelFields:function(){
            options.clearFields();
            form[gridId].hideEditor();
            form.btnRawMaterialsAdd.enable();
        },
        saveFields:function(){
            var selectedRow = form.RawMaterialsListId.getSelectedRow()[0];
            var newRow ={
                type           : form.edRawMaterialsType.getValue(),
                quantity       : form.edRawMaterialsQuantity.getValue(),
                value          : form.edValue.getValue(),
                vendor         : form.edVendor.getValue()
            };
            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['id'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnRawMaterialsAdd.enable();
        },
        edit: function () {
            options.clearFields();
            var selectedRow = form.RawMaterialsListId.getSelectedRow()[0];
            form[gridId].showEditor('edit');
            form.tblRawMaterialsObj.options.data = {
                type       : selectedRow["type"],
                quantity   : selectedRow["quantity"],
                value      : selectedRow["value"],
                vendor     : selectedRow["vendor"]
            };
            form.btnRawMaterialsAdd.disable();
        },
        delete: function () {
            if (form.RawMaterialsListId.getSelectedRow()[0]) {
                form.RawMaterialsListId.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
            form.btnRawMaterialsAdd.enable();
        },
    };

    var obj = {
        addNewRow: function () {
            form.pnlRawMaterials.isCollapsed = false;
            form[gridId].showEditor('add');
            options.clearFields();
            form.btnRawMaterialsAdd.disable();
        },
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (form.isFormEditMode === true) {
                var selRow = form[gridId].getSelectedRow()[0] || {};
                options.items = [
                    {caption: gRB('edit'),   click: form.tblRawMaterialsObj.options.edit},
                    {caption: gRB('delete'), click: form.tblRawMaterialsObj.options.delete}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('RawMaterialsListId');

form.tblMachinesObj = (function(grId){
    var gridId = grId;
    var options = {
        requiredElements : [
            "edMachinesType"
        ],

        machinesList: form.inputParams.stageMap.machinesList,
        data: {},
        clearFields: function () {
            delete options.data.type;
            delete options.data.quantity;
            delete options.data.remainingValue;
            delete options.data.place;
            delete options.data.productionYear;
        },
        cancelFields:function(){
            options.clearFields();
            form[gridId].hideEditor();
            form.btnMachinesAdd.enable();
        },
        saveFields:function(){
            var selectedRow = form.MachinesListId.getSelectedRow()[0];
            var newRow ={
                type           : form.edMachinesType.getValue(),
                quantity       : form.edMachinesQuantity.getValue(),
                remainingValue : form.edRemainingValue.getValue(),
                place          : form.edPlace.getValue(),
                productionYear : form.edProductionYear.getValue()
            };
            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['id'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnMachinesAdd.enable();
        },
        edit: function () {
            options.clearFields();
            var selectedRow = form.MachinesListId.getSelectedRow()[0];
            form[gridId].showEditor('edit');
            form.tblMachinesObj.options.data = {
                type           : selectedRow["type"],
                quantity       : selectedRow["quantity"],
                remainingValue : selectedRow["remainingValue"],
                place          : selectedRow["place"],
                productionYear : selectedRow["productionYear"]
            };
            form.btnMachinesAdd.disable();
        },
        delete: function () {
            if (form.MachinesListId.getSelectedRow()[0]) {
                form.MachinesListId.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
            form.btnMachinesAdd.enable();
        },
    };

    var obj = {
        addNewRow: function () {
            form.pnlMachines.isCollapsed = false;
            form[gridId].showEditor('add');
            options.clearFields();
            form.btnMachinesAdd.disable();
        },
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (form.isFormEditMode === true) {
                var selRow = form[gridId].getSelectedRow()[0] || {};
                options.items = [
                    {caption: gRB('edit'),   click: form.tblMachinesObj.options.edit},
                    {caption: gRB('delete'), click: form.tblMachinesObj.options.delete}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('MachinesListId');

form.tblEmployeesObj = (function(grId){
    var gridId = grId;
    var options = {
        requiredElements : [
            "edPositionCheck"
        ],

        employeesList: form.inputParams.stageMap.employeesList,
        data: {},
        clearFields: function () {
            delete options.data.positionCheck;
            delete options.data.quantity;
            delete options.data.averageIncome;
            delete options.data.averageEmploymentDuration;
        },
        cancelFields:function(){
            options.clearFields();
            form[gridId].hideEditor();
            form.btnEmployeesAdd.enable();
        },
        saveFields:function(){
            var selectedRow = form.EmployeesListId.getSelectedRow()[0];
            var newRow ={
                positionCheck             : form.edPositionCheck.getValue(),
                quantity                  : form.edEmployeesQuantity.getValue(),
                averageIncome             : form.edAverageIncome.getValue(),
                averageEmploymentDuration : form.edAverageEmploymentDuration.getValue()
            };
            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['id'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnEmployeesAdd.enable();
        },
        edit: function () {
            options.clearFields();
            var selectedRow = form.EmployeesListId.getSelectedRow()[0];
            form[gridId].showEditor('edit');
            form.tblEmployeesObj.options.data = {
                positionCheck             : selectedRow["positionCheck"],
                quantity                  : selectedRow["quantity"],
                averageIncome             : selectedRow["averageIncome"],
                averageEmploymentDuration : selectedRow["averageEmploymentDuration"]
            };
            form.btnEmployeesAdd.disable();
        },
        delete: function () {
            if (form.EmployeesListId.getSelectedRow()[0]) {
                form.EmployeesListId.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
            form.btnEmployeesAdd.enable();
        },
    };

    var obj = {
        addNewRow: function () {
            form.pnlEmployees.isCollapsed = false;
            form[gridId].showEditor('add');
            options.clearFields();
            form.btnEmployeesAdd.disable();
        },
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (form.isFormEditMode === true) {
                var selRow = form[gridId].getSelectedRow()[0] || {};
                options.items = [
                    {caption: gRB('edit'),   click: form.tblEmployeesObj.options.edit},
                    {caption: gRB('delete'), click: form.tblEmployeesObj.options.delete}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('EmployeesListId');

form.tblProductsObj = (function(grId){
    var gridId = grId;
    var options = {
        requiredElements : [
            "edProductsType"
        ],

        productsList: form.inputParams.stageMap.productsList,
        data: {},
        clearFields: function () {
            delete options.data.type;
            delete options.data.quantity;
            delete options.data.cost;
            delete options.data.ultimateCustomer;
        },
        cancelFields:function(){
            options.clearFields();
            form[gridId].hideEditor();
            form.btnProductsAdd.enable();
        },
        saveFields:function(){
            var selectedRow = form.ProductsListId.getSelectedRow()[0];
            var newRow ={
                type             : form.edProductsType.getValue(),
                quantity         : form.edProductsQuantity.getValue(),
                cost             : form.edCost.getValue(),
                ultimateCustomer : form.edUltimateCustomer.getValue()
            };
            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                form[gridId].hideEditor();
                form[gridId].updateRow(obj.selectedId, newRow);

            } else {
                newRow['id'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnProductsAdd.enable();
        },
        edit: function () {
            options.clearFields();
            var selectedRow = form.ProductsListId.getSelectedRow()[0];
            form[gridId].showEditor('edit');
            form.tblProductsObj.options.data = {
                type             : selectedRow["type"],
                quantity         : selectedRow["quantity"],
                cost             : selectedRow["cost"],
                ultimateCustomer : selectedRow["ultimateCustomer"]
            };
            form.btnProductsAdd.disable();
        },
        delete: function () {
            if (form.ProductsListId.getSelectedRow()[0]) {
                form.ProductsListId.deleteRow(obj.selectedId);
                form[gridId].refresh();
            }
            form.btnProductsAdd.enable();
        },
    };

    var obj = {
        addNewRow: function () {
            form.pnlProducts.isCollapsed = false;
            form[gridId].showEditor('add');
            options.clearFields();
            form.btnProductsAdd.disable();
        },
        refresh: function () {
            form[gridId].refresh();
        },
        onChangeItems: function () {
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            if (form.isFormEditMode === true) {
                var selRow = form[gridId].getSelectedRow()[0] || {};
                options.items = [
                    {caption: gRB('edit'),   click: form.tblProductsObj.options.edit},
                    {caption: gRB('delete'), click: form.tblProductsObj.options.delete}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('ProductsListId');

form.action = function (tagName) {
   outputParams.TRANSTYPE = tagName;

   if (form.isFormEditMode) {
      outputParams.stageMap = inputParams.stageMap;
      outputParams.stageMap.rawMaterialsList = form.tblRawMaterialsObj.getItems();
      outputParams.stageMap.machinesList     = form.tblMachinesObj.getItems();
      outputParams.stageMap.employeesList    = form.tblEmployeesObj.getItems();
      outputParams.stageMap.productsList     = form.tblProductsObj.getItems();

      if (tagName === 'CLOSE') {
         if(form.isFormEditMode === false){
            form.sendForm('GO',false);
         }else{
            service.showDialogCancelConfirm(
                form,
                form.yesFunc
            )
         }
      } else {
         if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
         } else {
            form.verifyForm(false);
         }
         form.sendForm('GO', false);
      }
   } else {
       form.outputParams.VERIFIED = true;
       form.sendForm('GO', false);
   }

};

