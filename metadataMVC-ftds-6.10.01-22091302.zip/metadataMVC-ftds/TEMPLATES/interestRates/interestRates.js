template.formParams = template.data;
template.productGroupParamMap = template.formParams.productGroupParamMap || {};
template.inputParams = template.data.inputParams;
template.strToNum = service.strToNum;