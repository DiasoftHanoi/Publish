/* global form */

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;
var outputParams = form.outputParams || {};
outputParams.formParams = form.formParams;
form.notData = 'нет данных';
var strToNum = service.strToNum;
form.strToNum = service.strToNum;
var gRB = service.gRB;

form.templateData = form.formParams;

form.productGroupParamMap = form.formParams.productGroupParamMap || {};
//form.formParams.notStandardLTV = form.formParams.notStandardLTV != null ? service.formatAmount(strToNum(form.formParams.notStandardLTV), 2) : service.formatAmount(strToNum(form.formParams.standardLTV), 2);

form.onShow = function () {
    form.calculationLTV();
};

form.executeCommand = function (msg) {
    //form.sendForm(msg.event);
    switch (msg.event) {
        case 'appParticipants':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/FORMLIB/participantsDeal/viewParticipantsDealList_fullApp", {
                APPLICATIONID: form.formParams.DOCUMENTID,
                extraParams: {
                    showVersionFlag: true,
                    isLoanOfficerRole: false,
                    EDITMODE: false
                }
            });
            break;                
        case 'relatedBorrGroup':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/COMMON/APPLICATION/applicationRelatedBorrowers", {
                APPLICATIONID: form.formParams.DOCUMENTID
            });
            break;
        case 'processingStage':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/COMMON/APPLICATION/PROCESSING/applicationProcessing", {
                APPLICATIONID: form.formParams.DOCUMENTID
            });
            break;
        case 'attachedDocuments':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/COMMON/APPLICATION/applicationListAttachment", {
                APPLICATIONID: form.formParams.DOCUMENTID
            });
            break;
        case 'linkedDocuments':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/COMMON/APPLICATION/LINKEDAPP/applicationLinked", {
                APPLICATIONID: form.formParams.DOCUMENTID
            });
            break;
        case 'reports':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/COMMON/APPLICATION/applicationClientReports", {
                APPLICATIONID: form.formParams.DOCUMENTID
            });
            break;
        case 'analysisResult':
            form.startNewPageFlowProcess(form.getResourceBundle("analysisResult.caption"), "FTFLOANSMVC/loanApp/mortgageLoanApp/viewDecisionCC/analysisResults", {
                SHOWRESULT: false,
                APPLICATIONID: form.formParams.DOCUMENTID,
                PAGEHEADER: form.getResourceBundle("analysisResult.caption")
            });
            break;
        case 'reservationFeatures':
            form.startNewPageFlowProcess(form.getResourceBundle("analysisResult.pageHeader"), "FTFLOANSMVC/COMMON/APPLICATION/applicationAnalysisResult", {
                APPLICATIONID: form.formParams.DOCUMENTID,
                PAGEHEADER: form.getResourceBundle("analysisResult.pageHeader")
            });
            break;
        case 'viewPledge':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/loanApp/mortgageLoanApp/inputPledgeFullInformation/pledgeFullList", {
                APPLICATIONID: form.formParams.DOCUMENTID,
                isDecisionView: true
            });
            break;  
                case 'viewMatrixOffers':
            form.startNewPageFlowProcess(msg.caption, "FTFLOANSMVC/loanApp/mortgageLoanApp/matrixOffers/viewMatrixOffers", {
                APPLICATIONID: form.formParams.DOCUMENTID
            });
            break;
            
    }
};

form.calculationLTV = function () {
    var params = {
        formulaSysNameLTV: form.productGroupParamMap.formulaCalculatorCalcLTV? form.productGroupParamMap.formulaCalculatorCalcLTV.VALUE1 : gRB('noValue'),
        formulaSysNameLTVMSK: form.productGroupParamMap.formulaCalculatorCalcLTVWithMaternityCapital? form.productGroupParamMap.formulaCalculatorCalcLTVWithMaternityCapital.VALUE1 : null,
        propertyCost: Number(form.formParams.propertyCost),
        downPayment: Number(form.formParams.downPayment),
        creditAmount: Number(form.formParams.maxCreditAmountCC),
        maternityCapitalAmount: Number(form.formParams.maternityCapitalAmount)
    };
    form.startProcess('FTFLOANSMVC/COMMON/CALC/PROODUCTINFO/calculateLTV', {
        paramsLTV: params,
		formParams: form.formParams,
        APPLICATIONID: form.inputParams.APPLICATIONID
    }, function(){}, true).then(function (response){
        if (response.lastErrorFlag){
            throw response.lastErrorMessage;
        }
        form.formParams.calculateLTV = response.calcLTV ? response.calcLTV.toFixed(2): 0;
        form.formParams.calculateLTVBeforeMaternityCapital = response.calcLTVMSK ? response.calcLTVMSK.toFixed(2): 0;


    }).catch(function (err){
        form.showErrorDialog(err+'', function(){}, [{caption: form.getResourceBundle('dialog.ok')}]);
    });
};


form.formSettings = {
    DECISIONTYPE_ITEMS: form.inputParams.decisionItems,
    /*[
     {value: 'positive', text: 'Положительное'},
     {value: 'negative', text: 'Отрицательное'},
     {value: 'torework', text: 'Вернуть на доработку'}
     ],*/
    isShowRefuseReason: false
};
form.REFUSEREASON_ITEMS = form.inputParams.reasonListNew;

form.onChangeDecisionType = function (value) {
    if (form.rbDecisionType.value != null) {
        form.bNext.enabled = true;
    }
    if (value == "negative" || value == "decline") {
        form.formSettings.isShowRefuseReason = true;
    } else {
        form.formSettings.isShowRefuseReason = false;
    }
};
form.action = function (tag) {
    if (tag == "NEXT") {
        if (!form.verifyForm(false)) {
            return;
        }
        var calculateLTVBeforeMaternityCapital = form.formParams.calculateLTVBeforeMaternityCapital;
        var standardLTVWithMaternityCapital = form.formParams.standardLTVWithMaternityCapital;
        var calculateLTV = form.formParams.calculateLTV;
        var standardLTV = form.formParams.standardLTV;
        var message = '';

        if (calculateLTVBeforeMaternityCapital && standardLTVWithMaternityCapital) {
            if (strToNum(calculateLTVBeforeMaternityCapital) > strToNum(standardLTVWithMaternityCapital)) {
                message = 'Значение К/З мск составляет ' + strToNum(calculateLTVBeforeMaternityCapital).toFixed(2) + '% и превышает нормативное значение, установленное в размере ' + strToNum(standardLTVWithMaternityCapital).toFixed(2) + '%.';
            }
        }

        if (calculateLTV && standardLTV) {
            if (strToNum(calculateLTV) > strToNum(standardLTV)) {
                message += (message ? '\n' : '') + 'Значение К/З составляет ' + (strToNum(calculateLTV)).toFixed(2) + '% и превышает нормативное значение, установленное в размере ' + strToNum(standardLTV).toFixed(2) + '%.';
            }
        }
        form.outputParams.EXIT_TYPE = 'SAVE';
        form.formParams.SuspensiveConditionList=form.suspensiveConditionPnl.tabSuspensiveCondition.getItems();
        form.formParams.AddConditionList=form.additionalConditionsPnl.tabAddCondition.getItems();
        if (message != '') {
            form.showInformationDialog(message, function () {
                if (form.refuseReason)
                    form.outputParams.refuseDescription = form.refuseReason.getText();
                form.sendForm(tag, false);
            }, [{caption: 'OK'}]);
        } else {
            if (form.refuseReason)
                form.outputParams.refuseDescription = form.refuseReason.getText();
            form.sendForm(tag, false);
        }
    } else {
            form.outputParams.EXIT_TYPE = 'CLOSE';
        form.sendForm(tag, false);
    }
};

form.requiredControls = function () {
    return ([
        'rbDecisionType'
    ].join(',')) +
            (form.formSettings.isShowRefuseReason ? ',refuseReason' : "");
};
form.verifyForm = function (showFlag) {
    var veri_fied = true;
    try {
        console.log('verifyForm');
        if (form.validateControlsByIds(form.requiredControls(), showFlag ? 'bNext' : undefined).isShowFormErrors) {
            throw  {type: 'fields', msg: ''};
        }

    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{caption: gRB('dialog.ok')}]);
        }
        veri_fied = false;
    }
    return veri_fied;
};