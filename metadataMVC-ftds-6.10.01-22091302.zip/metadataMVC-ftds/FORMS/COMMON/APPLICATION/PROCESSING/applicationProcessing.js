function registerMethod(initService) {
	var service = {};
	for (var ar in initService) {
		if (initService.hasOwnProperty(ar)) {
			if (ar.indexOf('Service') > -1 || typeof(initService[ar]) != 'function') {
				service[ar] = initService[ar];
			} else {
				var fn = initService[ar].toString();
				var sIdx = fn.search(/\(/) + 1;
				var eIdx = fn.search(/\)\{/);
				var args = fn.substring(sIdx, eIdx)
					eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
			}
		}
	}
	return service;
}
service = registerMethod(service);

var getInputParams = service.getInputParams;
var lgr = service.lgr;
var showAlert = service.showAlert;
var gRBT = service.gRBT;
var gRB = service.gRB;
var nvl = service.nvl;

form.application = nvl(getInputParams('application'), {});

form.onSelectStage = function (item) {
	lgr('onSelectStage', arguments);
	var params = {
		STAGEID : item.STAGEID,
		CheckRights : "TRUE",
		USERACCOUNTID : getInputParams('USERACCOUNTID'),
		ROLEIDS : getInputParams('ROLEIDS'),
		USERGROUPIDS : getInputParams('USERGROUPIDS')
	}
	if (!form.processingObj.options['ID' + item.STAGEID]) {
		form.dsCall('[frontws2]', 'docProcessingGetById', params).then(function (p) {
			lgr('fillDetails', p);
			p = p['data']['Result'];

			form.processingObj.options['ID' + item.STAGEID] = p;
			if (p["BUSINESS_ERROR"]) {
				showAlert(p["BUSINESS_ERROR"]);
			}
		})
	}


}


form.executeCommand = function (message) {
	switch (message.event) {
		case 'TRANS_DIRECT':
			service.sendForm("CLOSE", false);
			break;	
		default:
			break;
	}
}

form.preparePath=function(str,project){
	str+="";
	var data=str.split("[");
	if (data.length>1){
		var data2=data[1].split("]");
		return {project:data2[0],pageflow:data2[1]}
	}else{
		return {project:service.nvl(project,form.getCurrentProjectSysname()),pageflow:str}
	}
}

form.processingObj = {
	remoteMethod : {
		filterParams : {
			DOCUMENTID : getInputParams('APPLICATIONID'),
			DISABLE_CLOB : 'TRUE',
			CheckRights : 'TRUE',
			USERACCOUNTID : getInputParams('USERACCOUNTID'),
			ROLEIDS : getInputParams('ROLEIDS'),
			USERGROUPIDS : getInputParams('USERGROUPIDS')
		}
	},
	cols : [{
			value : 'STAGEDATE',
			type : 'datetime',
			caption : gRB('creationDate'),
			width : 25
		}, {
			value : 'STAGENAME',
			type : 'text',
			caption : gRB('Name'),
			width : 25
		}, {
			value : 'STAGERESULT',
			type : 'text',
			caption : gRB('Result'),
			width : 25
		}, {
			value : 'PERFORMER',
			type : 'text',
			caption : gRB('Performer'),
			width : 25
		}
	],

	options : {
		checkStage : function (item) {
			var rg = new RegExp('ошибка', 'ig');
			return (item.STAGERESULT.search(rg) > -1);
		},
		onShowStage : function (item) {
			lgr('onShowStage', item);
			var PAGEFLOWNAME=nvl(item.PAGEFLOWNAME,"");
			if (PAGEFLOWNAME!=""){
				var pathData = form.preparePath(item.PAGEFLOWNAME,getInputParams('PROJECT'));
				service.setActiveTab(
					pathData.project,
					pathData.pageflow, {
					STAGEID : item.STAGEID,
					APPLICATIONID : getInputParams('APPLICATIONID')
				},
					true,
					gRBT('viewApplicationStage', item.STAGENAME, form.application.DOCUMENTNUMBER))
			}
		}
	}
}

form.onShowStage= form.processingObj.options.onShowStage;