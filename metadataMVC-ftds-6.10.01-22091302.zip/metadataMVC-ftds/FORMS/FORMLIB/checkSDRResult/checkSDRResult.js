/* global form, service */

var inputParams = form.inputParams || {};
form.formParams = inputParams.formParams;

var outputParams = form.outputParams || {}
outputParams.formParams = form.formParams;

var lgr = service.lgr;
var nvl = service.nvl;

var editModeFlag = (inputParams.EDITMODE == 'YES') || (inputParams.EDITMODE == 'true');

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);
form.ClientSDRResultsMap = form.formParams.ClientSDRResultsMap || {}

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
};

form.executeCommand = function(msg){
    if (msg.event === 'FAB_NAVIGATOR_NAVIGATE'){
        outputParams.NEXTPAGE = msg.params.step;
        form.action('DIRECT');
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;

    if (!form.editModeFlag){
        outputParams.VERIFIED = inputParams.VERIFIED;
        return verified;
    }

    try {
        var btnNext =  form['btnNext'] ? 'btnNext' : 'btnSave';
        if (form.validateControlsByIds('*', showFlag === true ? btnNext : undefined).isShowFormErrors) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {lgr(e);
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    outputParams.VERIFIED = verified;
    return verified;
};

form.action = function (tagName) {
    outputParams.TRANSTYPE = tagName;

    if (tagName === 'CLOSE') {
        service.showDialogCancelConfirm(
            form,
            function (){
                form.outputParams.TRANSTYPE = 'SAVEDRAFT';
                form.verifyForm(false);
                form.sendForm('GO', false);
            }
        )
    } else {

        if (tagName === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
}