/*DSMETA version = "5.11.01-24041004" hash = "a92cfd626c459f09772ae3aef36983c18f1eb8e5"*/
function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var log = service.lgr;


form.params = form.inputParams.rowData;
form.params.certificateIssueDatRealEstate = utils.convertDate(form.params.certificateIssueDatRealEstate);
form.params.registrationDateCar = utils.convertDate(form.params.registrationDateCar);

 form.isRealEstate = function() {
    if (form.params.sysnameTypeAssets == "realEstate") {
    return true;    
	};
return false;
};
form.isVehicle = function() {
    if (form.params.sysnameTypeAssets == "vehicle") {
    return true;    
    };
return false;
};