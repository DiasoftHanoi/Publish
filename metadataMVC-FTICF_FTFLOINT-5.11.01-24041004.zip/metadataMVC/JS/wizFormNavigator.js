/*DSMETA version = "5.11.01-24041004" hash = "66b3954387c40c235f0509a5fb46c251df52dc74"*/
service.wizFormNavigatorCommand = wizFormNavigatorCommand;

function wizFormNavigatorCommand(param){
    var rightMsg = param.params || {};

    rightMsg.event = param.event;
    rightMsg.curpage = param.context.inputParams.CURPAGE;
    rightMsg.forms = param.context.inputParams.FORMS;
    rightMsg.formList = param.context.inputParams.FORMLIST;
    rightMsg.verified = param.context.outputParams.VERIFIED;

    var project = param.context.getCurrentProjectSysname();
    if (param.context.inputParams.WIZARDPROJECT){
        project = param.context.inputParams.WIZARDPROJECT;
    }
    param.context.commandRight(project+'/FORMLIB/formWizardNavigator/formWizardNavigator', rightMsg);
}

service.isLastWizForm = isLastWizForm;

function isLastWizForm(form){
    var forms = service.nvl(form.inputParams.FORMLIST, []);
    var curpage = service.strToNum(form.inputParams.CURPAGE);

    if ((forms.length > 0) && (forms[forms.length-1]["WIZFORMID"] == curpage)){
        return true;
    }
    return false;
}

service.isFirstWizForm = isFirstWizForm;

function isFirstWizForm(form){
    var forms = service.nvl(form.inputParams.FORMLIST, []);
    var curpage = service.strToNum(form.inputParams.CURPAGE);

    if ((forms.length > 0) && (forms[0]["WIZFORMID"] == curpage)){
        return true;
    }
    return false;
}