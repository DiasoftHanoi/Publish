/*DSMETA version = "5.11.01-24040505" hash = "e1cb042f13da3be9a5da414217b17488efa890e4"*/
var inputParams = form.inputParams || {};
var outputParams = form.outputParams || {}


var lgr = service.lgr;
var gRB = function (key) {
    return service.nvl(form.localize[key], key);
};
form.gRB = gRB;

form.action = function (tagName) {
    form.outputParams.USRSETTINGVALUE = form.inputParams.USRSETTINGVALUE;
    form.outputParams.tagName = tagName;
    form.sendForm(tagName);
};

form.onShow = function () {
    if (form.cbResponsible)
        form.cbResponsible.setValue(form.inputParams.USRSETTINGVALUE == 'ACTIVE' ? 'INACTIVE' : 'ACTIVE');
};
form.settng = {
    ITEMS: [{
            text: gRB('taskList.Active'),
            value: 'ACTIVE'
        },
        {
            text: gRB('taskList.Inactive'),
            value: 'INACTIVE'
        }
    ]
};

