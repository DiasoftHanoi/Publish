/*DSMETA version = "5.11.01-24040505" hash = "aaf712ec333d32986c0637c40af8fc4b4a63c0d7"*/
/* global form, service */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var inputParams = form.inputParams || {};
var outputParams = form.outputParams || {};
form.formParams = inputParams;

var lgr = service.lgr;
var nvl = service.nvl;
var gRB = service.gRB;

form.gRB = gRB;

form.action = function (tagName) {
    form.sendForm(tagName);
};

form.onApplicationAction=function(data, item){
    form.taskList.setSelectedRow(undefined);
    form.taskListObj.options.horizontalMenuItems = null;
    var pathkey = form.getCurrentProjectSysname() + '/COMMON/STATEMACHINE/callPageflowByTransfer';
    form.startNewPageFlowProcess(
        data.caption+'. Application №'+item['DOCUMENTNUMBER'],
        pathkey,
        {
            APPLICATIONID:     item.ObjectID,
            MAINAPPLICATIONID: item.ObjectID,
            TRANSITIONID:      data.TRANSITIONID
        },
        true,
        undefined,
        function(){
            if(form.taskList){
                form['taskList'].refresh();
            }
        }
    )
};

form.onSelectTask = function (item) {
    if (item instanceof Object && !Object.keys(item).length) {
        return;
    }
    form.taskListObj.options.horizontalMenuItems = [];
    var params = {
        APPLICATIONID : item.ObjectID
    };
    //var statusDone = nvl(gRB("taskList.statusDONE"), "DONE");
    var statusDone = "DONE";
    form.taskListObj.options['ID' + item.TaskID] = undefined;
    if (item.TaskStatusBrief && item.TaskStatusBrief.toUpperCase() == statusDone) {
        return;
    }
    form.startProcess(
        form.getCurrentProjectSysname()+'/COMMON/APPLICATION/getTransferList',
        params,
        function (p) {
            lgr('fillTransfers', p);
            var transfersList = nvl(p['transfersList'],{});
            var resActions=[];
            if (transfersList && transfersList.length) {
            for (var i=0;i<transfersList.length;i++){
                    form.taskListObj.options.horizontalMenuItems.push({
                        caption:transfersList[i]["NAME"],
                        click:function(){form.onApplicationAction(this, item)},
                        TRANSITIONID:transfersList[i]["TRANSITIONID"],
                        SYSNAME: transfersList[i]["SYSNAME"]
                    })
                }
            }
        }
    );

    var hItems = [];
    if (item.TaskStatusBrief && item.TaskStatusBrief.toUpperCase() !== statusDone) {
        params = {
            caption: form.getResourceBundle("taskList.removeFixing"),
            click: function () {
                var item = form['taskList'].getSelectedRow()[0];
                var TaskID = item["TaskID"];
                if (TaskID) {
                    var params = {
                        TASKID: TaskID
                    };
                    form.dsCall('[corews]', 'FINDTASKBYID', params).then(function (p) {
                        var res = nvl(p['data'], {});
                        var currentTaskStatus = nvl(res["STATUS"], "");
                        if (currentTaskStatus && currentTaskStatus.toUpperCase() == statusDone) {
                            form['taskList'].refresh();
                            form.showErrorDialog(gRB('taskList.checkStatusErrMsg'));
                            return;
                        } else {
                            service.showCustomDialogCancelConfirm(
                                form, form.getResourceBundle("taskList.removeFixing") + '?',
                                function () {
                                    var row = form['taskList'].getSelectedRow()[0];
                                    var params = {
                                        TASKID: row.TaskID,
                                        CURRENTUSERID: 0,
                                        CHANGEAUTHOR: form.inputParams.USERID,
                                        STATUS: 'NEW'
                                    };
                                    form.dsCall('[corews]', 'changeTaskParam', params).then(function () {
                                        form['taskList'].refresh()
                                    });
                                    return;
                                },
                                function () {
                                    return;
                                }, [{
                                    caption: gRB('dialog.yes')
                                }, {
                                    caption: gRB('dialog.no')
                                }]
                            );
                        }
                    });
                }
            }
        };
        if (item.CurrentUserID != 0 && item.CurrentUserID != null  && form.inputParams.isTaskAdmin)
            hItems.push(params);
        if ((form.inputParams.isTaskAdmin && taskListObj.filterParams.showOnly == 'subordinate') || form.inputParams.isSuperUser) {
            hItems.push({
                caption: form.getResourceBundle("taskList.assign_ChangeResponsible"),
                click: function () {
                    var item = form['taskList'].getSelectedRow()[0];
                    var TaskID = item["TaskID"];
                    if (TaskID) {
                        var params = {
                            TASKID: TaskID
                        };
                        form.dsCall('[corews]', 'FINDTASKBYID', params).then(function (p) {
                            var res = nvl(p['data'], {});
                            var currentTaskStatus = nvl(res["STATUS"], "");
                            if (currentTaskStatus && currentTaskStatus.toUpperCase() == statusDone) {
                                form['taskList'].refresh();
                                form.showErrorDialog(gRB('taskList.checkStatusErrMsg'));
                                return;
                            } else {
                                var row = form['taskList'].getSelectedRow()[0];
                                row.isSuperUser = form.inputParams.isSuperUser;
                                row.userDepartmentIDList = form.inputParams.userDepartmentIDList;
                                var currentUserID = row.CurrentUserID + "";
                                form.dsCall("[corews]", "dsUserBrowseListSessionByParam", params).then(function (p) {
                                    var res = nvl(p["data"], {});
                                    var usersOfSessionList = nvl(res["Result"], {});
                                    var flagStartProcess = false;
                                    for (var i = 0, countI = usersOfSessionList.length; i < countI; i++) {
                                        var userID = usersOfSessionList[i]["UserID"] + "";
                                        if (currentUserID == userID) {
                                            flagStartProcess = true;
                                            form.showQuestionDialog(gRB("changeResponsibleInSessionErrMsg"),
                                                function (response){
                                                    switch (response.buttonIndex){
                                                        case 0:
                                                            form.startModalPageFlowProcess(form.getCurrentProjectSysname() + '/COMMON/TASK/taskChangeResponsible', row).then(function (result) {
                                                            if (result) {
                                                                form['taskList'].refresh();
                                                                }
                                                            });
                                                            break;
                                                        case 1:
                                                            return;
                                                            break;
                                                    }
                                                },
                                                [
                                                    {caption: gRB('dialog.ok')},
                                                    {caption: gRB('dialog.cancel')}
                                                ]
                                            )
                                        }
                                    }
                                    if (flagStartProcess === false) {
                                        form.startModalPageFlowProcess(form.getCurrentProjectSysname() + '/COMMON/TASK/taskChangeResponsible', row).then(function (result) {
                                        if (result) {
                                            form['taskList'].refresh();
                                            }
                                        });
                                    }
                                    
                                });
                            }
                        });
                    }
                }
            });
        }

        if (form.inputParams.isTaskAdmin && item.isDelegateTypeTask == true) {
            hItems.push({
                caption: form.getResourceBundle("taskList.delegate"),
                click: function () {
                    var row = form['taskList'].getSelectedRow()[0];
                    form.startModalPageFlowProcess(form.getCurrentProjectSysname() + '/COMMON/TASK/taskDelegate', row).then(function (result) {
                        if (result) {
                            form['taskList'].refresh();
                        }
                    });
                }
            });
        }
    }
    form.taskListObj.options.horizontalMenuItems = hItems;

};

var taskListObj = (function (gridId) {
    var gridId = gridId;
    return {
        options: {
            gRB: service.gRB,
            nvl: service.nvl,
            getTimeFromLastModificationDate: function (item) {
                var date = new Date();

                date.setTime(new Date() - new Date(item.LastModificationDate));
                var hours = 0;
                if (date.getUTCDate() > 1) {
                    hours += 24 * (date.getUTCDate() - 1);
                }
                hours += date.getUTCHours();
                return hours + " ${hours} " + date.getUTCMinutes() + " ${minutes}";
            },
            flagList: form.inputParams.flagList,
            taskLightView: form.inputParams.taskLightView,
            horizontalMenuItems: [],
            checkTaskLightView : function(item){
                return !(!!this.taskLightView[item.TaskTypeBrief] && item.PerformerKind == 3 && !item.CurrentUserID);
            },
            isTaskLightView : function(item){
                return !(!!this.taskLightView[item.TaskTypeBrief]);
            }            
        },
        columns: [
            {
                value: 'TaskStatusName',
                type: 'text',
                caption: "${TaskStatusName}",
                width: 15
            },
            {
                value: 'CreationDate',
                type: 'date',
                caption: "${CreationDate}",
                width: 7
            },
            {
                value: 'LastModificationDate',
                type: 'date',
                caption: "${LastModificationDate}",
                width: 7
            },
            {
                value: 'TaskTypeName',
                type: 'text',
                caption: "${TaskTypeName}",
                width: 15
            },
            {
                value: 'options.checkTaskLightView(item) ? item.Comment : "XXXX"',
                type: 'expression',
                caption: "${Comment}",
                sortable: false,
                width: 15
            },
            {
                value: 'CurrentUserName',
                type: 'text',
                caption: "${CurrentUserName}",
                sortable: false,
                width: 20
            },
            {
                value: 'ExpirationDate',
                type: 'date',
                caption: "${ExpirationDate}",
                width: 10
            },
            {
                value: 'options.checkTaskLightView(item) ? item.DOCUMENTNUMBER : "XXXX"',
                type: 'expression',
                caption: "${AppNum}",
                sortable: false,
                width: 10
            }

        ],
        filterParams: inputParams.searchParams,
        element: form[gridId]
    };
})('taskList');
form.taskListObj = taskListObj;
form.executeCommand = function (message) {
    switch (message.event) {
        case 'SEARCH':
            taskListObj.filterParams = message.params;
            form['taskList'].refresh();
            break;
    }
};