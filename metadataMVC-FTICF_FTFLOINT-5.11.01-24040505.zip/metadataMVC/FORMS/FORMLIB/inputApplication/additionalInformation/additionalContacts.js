/*DSMETA version = "5.11.01-24040505" hash = "773cb4726ebf1fa13f75809cecc09a0f4261ee06"*/
function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var inputParams = form.inputParams;
var outputParams = form.outputParams || {};
var STATENAME = inputParams.STATENAME;

var gRB = service.gRB;

form.onShow = function () {
    form.tblAdditionalContactsObj.setItems(inputParams.additionalContactsList || []);
};

form.executeCommand = function(msg){

};

form.tblAdditionalContactsObj = (function (grId) {
    var gridId = grId;
    var options = {
        data: {
            contactType: gRB("additionalContacts.contactType"),
            additionalContactStage: STATENAME
        },

        requiredElements: [
            "edContactType",
            "edContactOwner",
            "edContactValue",
        ],
        
        cancel: function () {
            form[gridId].hideEditor();
            form.btnContactAdd.enable();
        },
        save: function () {
            var selectedRow = form[gridId].getSelectedRow()[0];
            var newRow = {
                contactType             : options.data.contactType,
                value                   : options.data.contactValue,
                contactOwner            : options.data.contactOwner,
                commentary              : options.data.contactCommentary,
                additionalContactStage  : options.data.additionalContactStage
            };

            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                form[gridId].hideEditor();
                form[gridId].updateRow(selectedRow['id'], newRow);

            } else {
                newRow['id'] = new Date().getTime();
                form[gridId].hideEditor();
                form[gridId].addRow(newRow);
            }
            form.btnContactAdd.enable();
        },
        clearFields: function () {
            delete options.data.contactValue;
            delete options.data.contactCommentary;
            delete options.data.contactOwner;
            options.data.additionalContactStage = STATENAME;
        },
        edit: function () {
            form.addAddrMode = 'edit';
            form[gridId].showEditor('edit');
            options.clearFields();
            var selectedRow = form[gridId].getSelectedRow()[0];
            form[gridId].options.data = {
                contactType: selectedRow['contactType'],
                contactValue: selectedRow["value"],
                contactOwner: selectedRow["contactOwner"],
                contactCommentary: selectedRow['commentary'],
                additionalContactStage:  selectedRow['additionalContactStage']
            };
            form.btnContactAdd.disable();
        },
        delete: function () {
            var row = form[gridId].getSelectedRow()[0];
            if (row) {
                form[gridId].deleteRow(row['id']);
                form[gridId].refresh();
            }
            options.clearFields();
            form.btnContactAdd.enable();
        }
    };

    var obj = {
        gridId: grId,
        refresh: function () {
            form[gridId].refresh();
        },
        addNewRow: function () {
            form.addAddrMode = 'add';
            form[gridId].showEditor('add');
            options.clearFields();
            form.btnContactAdd.disable();
        },
        setItems: function (items) {
            form[gridId].setItems(items);
        },
        getItems: function () {
            return form[gridId].getItems();
        },
        onSelectRow: function () {
            options.items = [];
            var selRow = form[gridId].getSelectedRow()[0] || {};
            if (selRow['additionalContactStage'] == form.inputParams.STATENAME) {
                options.items = [
                    {caption: gRB('edit'), click: form[gridId].options.edit},
                    {caption: gRB('delete'), click: form[gridId].options.delete}
                ];
            }
        }
    };
    obj.options = options;
    return obj;
})('tblAdditionalContacts');

form.action = function (tagName) {
    outputParams.additionalContactsList = form.tblAdditionalContactsObj.getItems();
    if (tagName === 'CLOSE') {
            service.showDialogCancelConfirm(
                form
            )
    } else{
        form.outputParams.TRANSTYPE = 'SAVE';
        form.sendForm('GO', false);
    }
};