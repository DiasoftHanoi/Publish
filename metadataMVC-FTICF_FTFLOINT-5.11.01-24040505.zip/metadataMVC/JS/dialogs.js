/*DSMETA version = "5.11.01-24040505" hash = "bd9847157082ebc7b6a3442659b522e8da38c303"*/
service.showDialogCancelConfirm = showDialogCancelConfirm;

function showDialogCancelConfirm(form, yesFunc, noFunc){
    var gRB = form.getResourceBundle;

    form.showQuestionDialog(
        form.inputParams.APPLICATIONID ? gRB('dialog.confirmCancelAndModify') : gRB('dialog.confirmCancelAndSave'),

        function (response){
            switch (response.buttonIndex){
                case 0:
                    if (yesFunc){
                        yesFunc();
                    } else {
                        form.outputParams.TRANSTYPE = 'SAVE';
                        form.sendForm('GO',false);
                    }
                    break;
                case 1:
                    if (noFunc){
                        noFunc();
                    } else {
                        form.outputParams.TRANSTYPE = 'CLOSE';
                        form.sendForm('GO',false);
                    }
                    break;
            }
        },
        [
            {caption: gRB('dialog.yes')},
            {caption: gRB('dialog.no')},
            {caption: gRB('dialog.cancel')}
        ]
    )
}

service.showCustomDialogCancelConfirm = function (form, question, yesFunc, noFunc, buttons){
    var gRB = form.getResourceBundle;

    form.showQuestionDialog(
        question,
        function (response){
            switch (response.buttonIndex){
                case 0:
                    if (yesFunc){
                        yesFunc();
                    } else {
                        form.outputParams.TRANSTYPE = 'SAVE';
                        form.sendForm('GO',false);
                    }
                    break;
                case 1:
                    if (noFunc){
                        noFunc();
                    } else {
                        form.outputParams.TRANSTYPE = 'CLOSE';
                        form.sendForm('GO',false);
                    }
                    break;
            }
        },
        buttons!=null ? buttons : [
            {caption: gRB('dialog.yes')},
            {caption: gRB('dialog.no')},
            {caption: gRB('dialog.cancel')}
        ]
    )
};