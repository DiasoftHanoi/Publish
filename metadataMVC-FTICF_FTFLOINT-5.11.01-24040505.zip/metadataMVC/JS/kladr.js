/*DSMETA version = "5.11.01-24040505" hash = "5fd34281c4ebb6f69e946fd65d0b545b5932e67f"*/
service.addressInString = function (id){
	var nvl=service.nvl;
	var address = form[id].getValue();
	var regionType = service.getShortName("1", address["RegionType"]);
	var districtType = service.getShortName("2", address["DistrictType"]);
	var cityType = service.getShortName("3", address["CityType"]);
	var townType = service.getShortName("4", address["TownType"]);
	var streetType = service.getShortName("5", address["StreetType"]);

	var houseType = service.gRB("house");
	var housingType = service.gRB("housing");
	var buildingType = service.gRB("building");
	var flatType = service.gRB("flat");

	if (!service.isRussianAddress(id)) {
		regionType = "";
		districtType = "";
		cityType = "";
		townType = "";
		streetType = "";
		houseType = "";
		housingType = "";
		buildingType = "";
		flatType = "";
	}
	var fullAddress = "";

	if (nvl(address["Country"], "") != "") {
		fullAddress += nvl(address["Country"], "") + ", "
	}
	if (nvl(address["PostalCode"], "") != "") {
		fullAddress += nvl(address["PostalCode"], "") + ", "
	}
	if (nvl(address["Region"], "") != "") {
		fullAddress += ((nvl(address["Region"], "") != "") ? ((regionType != "") ? (regionType) : "") : "");
		fullAddress += (nvl(address["Region"], "") != "") ? " " + address["Region"] : "";
		fullAddress += ", ";
	}
	if (nvl(address["District"], "") != "") {
		fullAddress += ((nvl(address["District"], "") != "") ? ((districtType != "") ? (districtType) : "") : "");
		fullAddress += (nvl(address["District"], "") != "") ? " " + address["District"] : ""
		fullAddress += ", ";
	}
	if (nvl(address["City"], "") != "") {
		fullAddress += (nvl(address["City"], "") != "") ? ((cityType != "") ? (cityType) : "") : "";
		fullAddress += (nvl(address["City"], "") != "") ? " " + address["City"] : "";
		fullAddress += ", ";
	}
	if (nvl(address["Town"], "") != "") {
		fullAddress += (nvl(address["Town"], "") != "") ? ((townType != "") ? (townType) : "") : "";
		fullAddress += (nvl(address["Town"], "") != "") ? " " + address["Town"] : "";
		fullAddress += ", ";
	}
	//service.println("streetType=" + streetType);
	if (nvl(address["Street"], "") != "") {
		fullAddress += (nvl(address["Street"], "") != "") ? ((streetType != "") ? (streetType) : "") : "";
		fullAddress += (nvl(address["Street"], "") != "") ? " " + address["Street"] : "";
		fullAddress += ", ";
	}
	if (nvl(address["House"], "") != "") {
		fullAddress += (nvl(address["House"], "") != "") ? houseType + " " + address["House"] : "";
		fullAddress += ", ";
	}
	if (nvl(address["Building"], "") != "") {
		fullAddress += ((nvl(address["Building"], "") != "") ? housingType + " " + address["Building"] : "");
		fullAddress += ", ";
	}
	if (nvl(address["Housing"], "") != "") {
		fullAddress += (nvl(address["Housing"], "") != "") ? buildingType + " " + address["Housing"] : "";
		fullAddress += ", ";
	}
	if (nvl(address["Flat"], "") != "") {
		fullAddress += (nvl(address["Flat"], "") != "") ? flatType + " " + address["Flat"] : "";
	}
	return fullAddress;
};

////////////////////////////////////////////////////////////////////////////////
service.getShortName=function(level, name){
	var result = "";
	if (name != null && name != "") {
		var kladrList = service.getNewList();
		if (level == "1")
			kladrList = service.getInputParams("kladrList1");
		else if (level == "2")
			kladrList = service.getInputParams("kladrList2");
		else if (level == "3")
			kladrList = service.getInputParams("kladrList3");
		else if (level == "4")
			kladrList = service.getInputParams("kladrList4");
		else if (level == "5")
			kladrList = service.getInputParams("kladrList5");
		if (kladrList == null || kladrList == "")
			kladrList = getNewList();

		for (var i = 0; i < kladrList.length; i++) {
			if (service.trim(name) == service.trim(kladrList[i]["FULLNAME"].toString())) {
				result = kladrList[i]["SHORTNAME"];
				break;
			}
		}
	}
	return result;
};

service.isRussianAddress=function(id){
	var countryValue = form[id].getValue()['Country'].toUpperCase();
	return countryValue === "РОССИЯ"
};

////////////////////////////////////////////////////////////////////////////////
service.formKladrString = function (id){
	var address = form[id].getValue();
	var regionType = service.getShortName("1", address["RegionType"]);
	var districtType = service.getShortName("2", address["DistrictType"]);
	var cityType = service.getShortName("3", address["CityType"]);
	var townType = service.getShortName("4", address["TownType"]);
	var streetType = service.getShortName("5", address["StreetType"]);

	var houseType = service.gRB("house");
	var housingType = service.gRB("housing");
	var buildingType = service.gRB("building");
	var flatType = service.gRB("flat");

	if (!service.isRussianAddress(id)) {
		regionType = "";
		districtType = "";
		cityType = "";
		townType = "";
		streetType = "";
		houseType = "";
		housingType = "";
		buildingType = "";
		flatType = "";
	}

	var fullAddress = "";

	fullAddress += (address["Country"] != null) ? address["Country"] : "";
	fullAddress += ", ";
	fullAddress += (address["PostalCode"] != null) ? address["PostalCode"] : "";
	fullAddress += ", ";
	fullAddress += ((address["Region"] != "" && address["Region"] != null) ? ((regionType != "") ? (regionType) : "") : "");
	fullAddress += (address["Region"] != null) ? " " + address["Region"] : "";
	fullAddress += ", ";
	fullAddress += ((address["District"] != "" && address["District"] != null) ? ((districtType != "") ? (districtType) : "") : "");
	fullAddress += (address["District"] != null) ? " " + address["District"] : ""
	fullAddress += ", ";
	fullAddress += (address["City"] != "" && address["City"] != null) ? ((cityType != "") ? (cityType) : "") : "";
	fullAddress += (address["City"] != null) ? " " + address["City"] : "";
	fullAddress += ", ";
	fullAddress += (address["Town"] != "" && address["Town"] != null) ? ((townType != "") ? (townType) : "") : "";
	fullAddress += (address["Town"] != null) ? " " + address["Town"] : "";
	fullAddress += ", ";
	fullAddress += (address["Street"] != "" && address["Street"] != null) ? ((streetType != "") ? (streetType) : "") : "";
	fullAddress += (address["Street"] != null) ? " " + address["Street"] : "";
	fullAddress += ", ";
	fullAddress += (address["House"] != null) ? address["House"] : "";
	fullAddress += ", ";
	fullAddress += ((address["Building"] != null) ? address["Building"] : "");
	fullAddress += ", ";
	fullAddress += (address["Housing"] != null) ? address["Housing"] : "";
	fullAddress += ", ";
	fullAddress += (address["Flat"] != null) ? address["Flat"] : "";

	return fullAddress;
};


