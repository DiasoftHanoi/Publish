template.formParams = template.data;
template.editingMode = template.formParams.editingMode; //
template.showConditionFulfilled = template.formParams.showConditionFulfilled; //

template.tabSuspensiveObj = (function (grId) {
    var gridId = grId;
    var options = {
        editingMode: template.editingMode,
        showConditionFulfilled: template.showConditionFulfilled,
        changeOnlyConditionFulfilled: false,
        btnApplyCaption:'',
        SuspensiveConditionParams: {
            ReferenceSysName: 'suspensiveConditions',
            ORDERBY: 'ReferenceItemID'
        },
        cmDateCondition_items: [{
            value: form.getResourceBundle('suspensiveCondition.BeforeSigningTheLoanAgreement'),
            text: (form.getResourceBundle('suspensiveCondition.BeforeSigningTheLoanAgreement'))
        }, {
            value: form.getResourceBundle('suspensiveCondition.PriorToTheIssuanceOfCredit'),
            text: (form.getResourceBundle('suspensiveCondition.PriorToTheIssuanceOfCredit'))
        }
        ],
        fieldsCaption: {},
        cancel: function () {
            template[gridId].hideEditor();
            if (template['addButtonSuspensive'])
                template.addButtonSuspensive.enable();
            options.changeOnlyConditionFulfilled = false;
        },
        save: function () {
            var selectedRow = template.tabSuspensiveCondition.getSelectedRow()[0];
            var newRow = {
                SuspensiveCondition: options.SuspensiveCondition,
                SuspensiveConditionText: template.cmbSuspensiveCondition.getText(),
                cmDateCondition: options.cmDateCondition,
                ConditionFulfilled: options.ConditionFulfilled,
                DescriptionCondition: options.DescriptionCondition,
            };
            if (selectedRow['id']) {
                newRow['id'] = selectedRow['id'];
                template[gridId].hideEditor();
                template[gridId].updateRow(newRow['id'], newRow);
            } else {
                newRow['id'] = new Date().getTime();
                template[gridId].hideEditor();
                template[gridId].addRow(newRow);
            }
            template[gridId].refresh();
            if (template['addButtonSuspensive'])
                template.addButtonSuspensive.enable();
            options.changeOnlyConditionFulfilled = false;
        },
        clearFields: function () {
            delete options.SuspensiveCondition;
            delete options.cmDateCondition;
            delete options.ConditionFulfilled;
            delete options.DescriptionCondition;
        },
        edit: function () {
            options.clearFields();
            options.btnApplyCaption = form.getResourceBundle('some.Edit');
            var selectedRow = template.tabSuspensiveCondition.getSelectedRow()[0];
            template[gridId].showEditor('edit');
            options.SuspensiveCondition = selectedRow['SuspensiveCondition'];
            options.cmDateCondition = selectedRow['cmDateCondition'];
            options.ConditionFulfilled = selectedRow['ConditionFulfilled'];
            options.DescriptionCondition = selectedRow['DescriptionCondition'];
            if (template['addButtonSuspensive'])
                template.addButtonSuspensive.disable();
        },
        delete: function () {
            var selectedRow = template.tabSuspensiveCondition.getSelectedRow()[0];
            if (selectedRow) {
                template.tabSuspensiveCondition.deleteRow(selectedRow['id']);
                template[gridId].refresh();
            }
            if (template['addButtonSuspensive'])
                template.addButtonSuspensive.enable();
        }
    };

    var obj = {
        gridId: grId,
        refresh: function () {
            template[gridId].refresh();
        },
        onChangeItems: function () {

        },
        addNewConditionRow: function () {
            template[gridId].showEditor('add');
            options.clearFields();
            options.btnApplyCaption = form.getResourceBundle('some.AddNew');
            if (template['addButtonSuspensive'])
                template.addButtonSuspensive.disable();
        },
        setItems: function (items) {
            template[gridId].setItems(items);
        },
        getItems: function () {
            return template[gridId].getItems();
        },
        onSelectRow: function () {
            var selRow = template[gridId].getSelectedRow()[0] || {};
            options.items = [];

            if (template.editingMode == 'changeOnlyConditionFulfilled' || selRow.readOnly){
                options.changeOnlyConditionFulfilled = true;
            }
            else{
                options.changeOnlyConditionFulfilled = false;
            }

            if (!selRow.readOnly) {
                if (template.editingMode == 'changeOnlyConditionFulfilled'){
                    options.items = [
                        {caption: form.getResourceBundle('suspensiveCondition.btnEdit'), click: template.tabSuspensiveCondition.options.edit}
                    ];
                }else{
                    options.items = [
                        {caption: form.getResourceBundle('suspensiveCondition.btnEdit'), click: template.tabSuspensiveCondition.options.edit},
                        {caption: form.getResourceBundle('suspensiveCondition.btnDel'), click: template.tabSuspensiveCondition.options.delete}
                    ];
                }
            }else{
                options.items = [
                    {caption: form.getResourceBundle('suspensiveCondition.btnEdit'), click: template.tabSuspensiveCondition.options.edit}
                ];
            }
        }
    };

    obj.options = options;
    return obj;
})('tabSuspensiveCondition');
