/*DSMETA version = "5.10.01-23103102" hash = "0c3604c4d84a0fb461237d33d9f588b0261e5ef7"*/
/* global form */

function registerMethod(initService) {
    var service = {};
    for (var ar in initService) {
        if (initService.hasOwnProperty(ar)) {
            if (ar.indexOf('Service') > -1 || typeof (initService[ar]) != 'function') {
                service[ar] = initService[ar];
            } else {
                var fn = initService[ar].toString();
                var sIdx = fn.search(/\(/) + 1;
                var eIdx = fn.search(/\)\{/);
                var args = fn.substring(sIdx, eIdx);
                eval("service." + ar + "=function(" + args + ")" + fn.substring(eIdx + 1, fn.length));
            }
        }
    }
    return service;
}
service = registerMethod(service);

var convertDate = service.convertDate;
var getTableContent = service.getTableContent;
var gRB = service.gRB;

form.isLastWizForm = service.isLastWizForm(form);
form.isFirstWizForm = service.isFirstWizForm(form);

form.isFormEditMode = form.inputParams.EDITMODE || false;

var inputParams = form.inputParams;
var outputParams = form.outputParams;

form.formParams = inputParams.formParams || {};
outputParams.formParams = form.formParams;

form.isApprovalState = inputParams.STATE == "Approval Result Notification";

form.settings = {
    cmbCollateralCurrencyComboBoxParams: {
        ReferenceSysName: 'currencyLOS',
        ORDERBY: 'ReferenceItemID'
    },
    requiredElements : [
        "edValuationAmount",
        "cmbCollateralCurrency",
        "edLiquidityFactor",
        "edStandardCreditFactor",
        "edRealCollateralValue",
        "edControlMethodCollateral",
        "edAppraisalReportNo",
        "edCurrentUsageState",
        "edOwnershipTransferAbility",
        "edClassification",
        "edCollateralDescription"
    ]
};

form.onShow = function () {
    service.wizFormNavigatorCommand({
        context: form,
        event: 'CURPAGE_MSG'
    });
};

var sendMessage = function (message) {
    var PROCESS_RIGHT_LIST = getInputParams("PROCESS_RIGHT_LIST");
    if (PROCESS_RIGHT_LIST) {
        for (var ar in PROCESS_RIGHT_LIST) {
            form.commandRight(ar, message);
        }
    }
};

form.executeCommand = function (message) {
    if (message.event == "FAB_NAVIGATOR_NAVIGATE") {
        form.outputParams.NEXTPAGE = message.params.step;
        form.action("DIRECT");
    }
};

form.curDate = service.convertDate(new Date());

form.yesFunc = function() {
    form.outputParams.TRANSTYPE = 'SAVEDRAFT';
    if (form.verifyForm()) {
        form.sendForm('GO', false);
    }
};

form.action = function (tag) {
    outputParams.TRANSTYPE = tag;

    if (tag === 'CLOSE' && form.isFormEditMode) {
        service.showDialogCancelConfirm(
            form,
            form.yesFunc
        )
    }
    else {
        if (tag === 'NEXT' && !form.verifyForm(true)) {
            return;
        } else {
            form.verifyForm(false);
        }
        form.sendForm('GO', false);
    }
};

form.verifyForm = function (showFlag) {
    var verified = true;
    var buttonNextSave = (form.isLastWizForm) ? "btnSave" : "btnNext";
    try {
        if ((form.validateControlsByIds(form.settings.requiredElements.join(','), showFlag === true ? buttonNextSave : undefined).isShowFormErrors)) {
            throw {
                type: 'fields',
                msg: ''
            };
        }
    } catch (e) {
        if (showFlag && (e.type === 'logic')) {
            form.showErrorDialog(e.msg, function () {}, [{
                caption: gRB('dialog.ok')
            }]);
        }
        verified = false;
    }
    form.outputParams.VERIFIED = verified;
    return verified;
};